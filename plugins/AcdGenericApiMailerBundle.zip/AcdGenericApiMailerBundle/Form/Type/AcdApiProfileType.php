<?php

declare(strict_types=1);

namespace MauticPlugin\AcdGenericApiMailerBundle\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\UrlType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\Length;
use Symfony\Component\Validator\Constraints\Range;

class AcdApiProfileType extends AbstractType
{
    private const DEFAULT_MAPPING = '{
  "from": "{{from}}",
  "to": "{{to}}",
  "cc": "{{cc}}",
  "bcc": "{{bcc}}",
  "reply_to": "{{reply_to}}",
  "subject": "{{subject}}",
  "html": "{{html}}",
  "text": "{{text}}",
  "headers": "{{headers}}",
  "attachments": "{{attachments}}"
}';

    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder->add('name', TextType::class, [
            'label' => 'Nome do perfil',
            'required' => false,
            'constraints' => [new Length(max: 80)],
        ]);
        $builder->add('adapter', ChoiceType::class, [
            'label' => 'Provedor ou adaptador',
            'choices' => [
                'SNDR' => 'sndr',
                'HTTP com JSON (genérico)' => 'generic_json',
            ],
            'placeholder' => 'Selecione um adaptador',
            'required' => false,
            'empty_data' => 'sndr',
        ]);
        $builder->add('endpoint', UrlType::class, [
            'label' => 'Endereço HTTPS para envio',
            'required' => false,
            'default_protocol' => 'https',
            'attr' => ['placeholder' => 'https://api.sndr.sh/v1/send'],
            'help' => 'No SNDR, use https://api.sndr.sh/v1/send. Para outros provedores, informe o endereço POST próprio.',
        ]);
        $builder->add('auth_type', ChoiceType::class, [
            'label' => 'Tipo de autenticação',
            'choices' => [
                'Token Bearer' => 'bearer',
                'Autenticação básica HTTP' => 'basic',
                'Chave de API em cabeçalho' => 'api_key',
                'Sem autenticação' => 'none',
            ],
            'placeholder' => 'Selecione o tipo de autenticação',
            'required' => false,
            'empty_data' => 'bearer',
        ]);
        $builder->add('api_key_header', TextType::class, [
            'label' => 'Nome do cabeçalho da chave de API',
            'required' => false,
            'empty_data' => 'X-API-Key',
            'attr' => ['placeholder' => 'X-API-Key'],
            'help' => 'Usado quando a autenticação for por chave de API em cabeçalho.',
        ]);
        $builder->add('timeout', IntegerType::class, [
            'label' => 'Tempo limite da requisição (segundos)',
            'required' => false,
            'empty_data' => '30',
            'constraints' => [new Range(min: 1, max: 120)],
            'help' => 'Informe um valor entre 1 e 120 segundos.',
        ]);
        $builder->add('headers_json', TextareaType::class, [
            'label' => 'Cabeçalhos adicionais (JSON)',
            'required' => false,
            'empty_data' => '{}',
            'attr' => ['rows' => 4, 'placeholder' => '{"X-Workspace": "marketing"}'],
            'help' => 'Use somente cabeçalhos sem segredos. Authorization e chaves de API usam os campos de autenticação.',
        ]);
        $builder->add('payload_mapping_json', TextareaType::class, [
            'label' => 'Mapeamento dos dados enviados (JSON)',
            'required' => false,
            'empty_data' => self::DEFAULT_MAPPING,
            'attr' => ['rows' => 12],
            'help' => 'Usado pelo adaptador HTTP com JSON genérico. Marcadores: {{from}}, {{to}}, {{cc}}, {{bcc}}, {{reply_to}}, {{subject}}, {{html}}, {{text}}, {{headers}} e {{attachments}}.',
        ]);
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'label' => false,
        ]);
    }
}
