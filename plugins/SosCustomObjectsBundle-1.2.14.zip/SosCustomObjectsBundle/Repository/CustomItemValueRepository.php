<?php

declare(strict_types=1);

namespace MauticPlugin\SosCustomObjectsBundle\Repository;

use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;
use MauticPlugin\SosCustomObjectsBundle\Entity\CustomItem;
use MauticPlugin\SosCustomObjectsBundle\Entity\CustomItemValue;
use MauticPlugin\SosCustomObjectsBundle\Entity\CustomObject;

final class CustomItemValueRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, CustomItemValue::class);
    }

    /** @return CustomItemValue[] */
    public function findByItem(CustomItem $item): array
    {
        return $this->createQueryBuilder('v')
            ->andWhere('v.item = :item')->setParameter('item', $item)
            ->getQuery()
            ->getResult();
    }

    public function findOneByItemAndField(CustomItem $item, int $fieldId): ?CustomItemValue
    {
        return $this->createQueryBuilder('v')
            ->join('v.field', 'f')
            ->andWhere('v.item = :item')->setParameter('item', $item)
            ->andWhere('f.id = :fid')->setParameter('fid', $fieldId)
            ->getQuery()->getOneOrNullResult();
    }

    /** @return CustomItemValue[] */
    public function acdFindByObject(CustomObject $object): array
    {
        return $this->createQueryBuilder('v')
            ->addSelect('f')
            ->innerJoin('v.field', 'f')
            ->innerJoin('v.item', 'i')
            ->andWhere('i.object = :object')
            ->setParameter('object', $object)
            ->getQuery()
            ->getResult();
    }

    /** @param list<int> $itemIds
     *  @return CustomItemValue[]
     */
    public function acdFindByObjectAndItemIds(CustomObject $object, array $itemIds): array
    {
        $itemIds = array_values(array_unique(array_filter(
            array_map('intval', $itemIds),
            static fn (int $itemId): bool => $itemId > 0
        )));

        if ([] === $itemIds) {
            return [];
        }

        return $this->createQueryBuilder('v')
            ->addSelect('f', 'i')
            ->innerJoin('v.field', 'f')
            ->innerJoin('v.item', 'i')
            ->andWhere('i.object = :object')
            ->andWhere('i.id IN (:itemIds)')
            ->setParameter('object', $object)
            ->setParameter('itemIds', $itemIds)
            ->orderBy('i.id', 'DESC')
            ->addOrderBy('f.id', 'ASC')
            ->getQuery()
            ->getResult();
    }
}
