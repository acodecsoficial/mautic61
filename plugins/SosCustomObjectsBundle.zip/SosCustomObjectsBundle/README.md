# SoSystems Custom Objects (Mautic 6)

Plugin criado do zero para Mautic 6, inspirado no conceito de "Custom Objects".

## v1.2.2
- Correção de ParseError em CustomItemService (linkContact)

## v1.2.0
- Aba/gerenciamento de vínculos no contato
- Campaign actions/conditions
- Permissões por role
- (best-effort) Segment filters

## v1.1.0
- Custom Objects (CRUD)
- Custom Fields por objeto (CRUD) - tipos: text, number, date, bool, select
- Custom Items por objeto (CRUD) + valores (EAV em tabela `sos_custom_item_value`)
- API REST básica para Objects/Fields/Items
- Link item -> contact (por contact_id) via API

## Instalação
1. Extraia em `/plugins/SosCustomObjectsBundle`
2. Rode:
   - `php bin/console cache:clear`
   - `php bin/console mautic:plugins:reload`
   - `php bin/console mautic:plugins:install`
