<?php

declare(strict_types=1);

namespace MauticPlugin\SosCustomObjectsBundle\EventListener;

use Mautic\CoreBundle\CoreEvents;
use Mautic\CoreBundle\Event\CustomContentEvent;
use Mautic\LeadBundle\Entity\Lead;
use MauticPlugin\SosCustomObjectsBundle\Service\CustomItemContactUiService;
use MauticPlugin\SosCustomObjectsBundle\Service\CustomFieldService;
use MauticPlugin\SosCustomObjectsBundle\Service\CustomObjectService;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

final class ContactTabSubscriber implements EventSubscriberInterface
{
    public function __construct(
        private CustomObjectService $customObjectService,
        private CustomItemContactUiService $customItemContactUiService,
        private CustomFieldService $customFieldService,
    ) {
    }

    public static function getSubscribedEvents(): array
    {
        return [
            CoreEvents::VIEW_INJECT_CUSTOM_CONTENT => ['injectTabs', 0],
        ];
    }

    public function injectTabs(CustomContentEvent $event): void
    {
        // Mautic 6 contact view template.
        $template = '@MauticLead/Lead/lead.html.twig';

        $objects = [];
        try {
            $objects = $this->customObjectService->list();
        } catch (\Throwable) {
            $objects = [];
        }

        if ($event->checkContext($template, 'tabs')) {
            $leadId = $this->extractLeadIdFromVars($event->getVars());
            $counts = $leadId ? $this->customItemContactUiService->countLinkedByObject($leadId) : [];

            foreach ($objects as $object) {
                $objectId = $object->getId();
                if (null === $objectId) {
                    continue;
                }

                $event->addTemplate('@SosCustomObjectsBundle/SubscribedEvents/Tab/link.html.twig', [
                    'title' => $object->getName(),
                    'count' => (int) ($counts[$objectId] ?? 0),
                    'tabId' => "custom-object-{$objectId}",
                ]);
            }
        }

        if ($event->checkContext($template, 'tabs.content')) {
            $leadId = $this->extractLeadIdFromVars($event->getVars());
            if (!$leadId) {
                return;
            }

            foreach ($objects as $object) {
                $objectId = $object->getId();
                if (null === $objectId) {
                    continue;
                }

                $items = $this->customItemContactUiService->getLinkedItemsWithAttributesForObject($leadId, $objectId);
                $customFields = [];
                foreach ($this->customFieldService->list($object) as $field) {
                    $alias = $field->getAlias();
                    if ($alias === '') {
                        continue;
                    }
                    $customFields[] = [
                        'alias' => $alias,
                        'label' => $field->getLabel(),
                    ];
                }

                $event->addTemplate('@SosCustomObjectsBundle/SubscribedEvents/Tab/content.html.twig', [
                    'title'    => $object->getName(),
                    'tabId'    => "custom-object-{$objectId}",
                    'objectId' => $objectId,
                    'items'    => $items,
                    'customFields' => $customFields,
                ]);
            }
        }
    }

    /**
     * @param array<string, mixed> $vars
     */
    private function extractLeadIdFromVars(array $vars): ?int
    {
        $lead = $vars['lead'] ?? null;

        if ($lead instanceof Lead) {
            $id = $lead->getId();

            return $id ? (int) $id : null;
        }

        if (is_array($lead) && isset($lead['id'])) {
            $id = (int) $lead['id'];

            return $id > 0 ? $id : null;
        }

        if (is_object($lead) && method_exists($lead, 'getId')) {
            $id = (int) $lead->getId();

            return $id > 0 ? $id : null;
        }

        return null;
    }
}
