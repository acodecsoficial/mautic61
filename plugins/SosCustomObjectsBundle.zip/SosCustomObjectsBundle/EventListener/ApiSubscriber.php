<?php

declare(strict_types=1);

namespace MauticPlugin\SosCustomObjectsBundle\EventListener;

use InvalidArgumentException;
use Mautic\ApiBundle\ApiEvents;
use Mautic\ApiBundle\Event\ApiEntityEvent;
use Mautic\LeadBundle\Controller\Api\LeadApiController;
use Mautic\LeadBundle\Entity\Lead;
use MauticPlugin\SosCustomObjectsBundle\Entity\CustomObject;
use MauticPlugin\SosCustomObjectsBundle\Service\CustomItemService;
use MauticPlugin\SosCustomObjectsBundle\Service\CustomObjectService;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

final class ApiSubscriber implements EventSubscriberInterface
{
    public function __construct(
        private CustomObjectService $customObjectService,
        private CustomItemService $customItemService,
    ) {
    }

    public static function getSubscribedEvents(): array
    {
        return [
            ApiEvents::API_ON_ENTITY_PRE_SAVE  => 'validateCustomObjectsInContactRequest',
            ApiEvents::API_ON_ENTITY_POST_SAVE => 'saveCustomObjectsInContactRequest',
        ];
    }

    public function validateCustomObjectsInContactRequest(ApiEntityEvent $event): void
    {
        $this->saveCustomItems($event, true);
    }

    public function saveCustomObjectsInContactRequest(ApiEntityEvent $event): void
    {
        $this->saveCustomItems($event, false);
    }

    private function saveCustomItems(ApiEntityEvent $event, bool $dryRun): void
    {
        try {
            $customObjectsPayload = $this->getCustomObjectsFromContactRequest(
                $event->getEntityRequestParameters(),
                $event->getRequest()
            );
        } catch (InvalidArgumentException) {
            return;
        }

        $contact = $event->getEntity();
        if (!$contact instanceof Lead) {
            return;
        }

        foreach ($customObjectsPayload['data'] as $customObjectData) {
            if (empty($customObjectData['data']) || !is_array($customObjectData['data'])) {
                continue;
            }

            $customObject = $this->getCustomObject($customObjectData);
            $this->validateCustomItemsPayload($customObject, $customObjectData['data']);

            if ($dryRun) {
                continue;
            }

            $contactId = $contact->getId();
            if (null === $contactId) {
                continue;
            }

            foreach ($customObjectData['data'] as $customItemData) {
                if (!is_array($customItemData)) {
                    continue;
                }

                $label = null;
                if (isset($customItemData['name'])) {
                    $label = is_scalar($customItemData['name']) ? (string) $customItemData['name'] : null;
                } elseif (isset($customItemData['label'])) {
                    $label = is_scalar($customItemData['label']) ? (string) $customItemData['label'] : null;
                }

                $attributes = [];
                if (isset($customItemData['attributes']) && is_array($customItemData['attributes'])) {
                    $attributes = $customItemData['attributes'];
                }

                $item = null;
                if (!empty($customItemData['id'])) {
                    $item = $this->customItemService->get((int) $customItemData['id']);
                    if (null === $item || $item->getObject()->getId() !== $customObject->getId()) {
                        throw new InvalidArgumentException('Custom item not found.', Response::HTTP_BAD_REQUEST);
                    }

                    $item = $this->customItemService->update($item, $label, $attributes);
                } else {
                    $item = $this->customItemService->create($customObject, $label, $attributes);
                }

                $this->customItemService->linkContact($item, (int) $contactId);
            }
        }
    }

    /**
     * @param array<string, mixed> $entityRequestParameters
     *
     * @return array{data: array<int, mixed>}
     */
    private function getCustomObjectsFromContactRequest(array $entityRequestParameters, Request $request): array
    {
        $controller = (string) $request->attributes->get('_controller', '');

        if (1 !== preg_match('~^'.preg_quote(LeadApiController::class, '~').'::(new|edit)(Entity|Entities)Action$~i', $controller)) {
            throw new InvalidArgumentException('Not a contact API request we care about.');
        }

        if (empty($entityRequestParameters['customObjects']['data']) || !is_array($entityRequestParameters['customObjects']['data'])) {
            throw new InvalidArgumentException('No customObjects payload.');
        }

        return $entityRequestParameters['customObjects'];
    }

    /**
     * @param array<string, mixed> $customObjectData
     */
    private function getCustomObject(array $customObjectData): CustomObject
    {
        if (isset($customObjectData['id'])) {
            $obj = $this->customObjectService->get((int) $customObjectData['id']);
            if (null === $obj) {
                throw new InvalidArgumentException('Custom object not found.', Response::HTTP_BAD_REQUEST);
            }

            return $obj;
        }

        if (isset($customObjectData['alias'])) {
            $obj = $this->customObjectService->getByAlias((string) $customObjectData['alias']);
            if (null === $obj) {
                throw new InvalidArgumentException('Custom object not found.', Response::HTTP_BAD_REQUEST);
            }

            return $obj;
        }

        throw new InvalidArgumentException('customObjects.data[].id or customObjects.data[].alias must be provided.', Response::HTTP_BAD_REQUEST);
    }

    /**
     * @param array<int, mixed> $customItemsData
     */
    private function validateCustomItemsPayload(CustomObject $customObject, array $customItemsData): void
    {
        $allowedAliases = [];
        foreach ($this->customItemService->fields($customObject) as $field) {
            $allowedAliases[$field->getAlias()] = true;
        }

        foreach ($customItemsData as $customItemData) {
            if (!is_array($customItemData)) {
                continue;
            }

            if (empty($customItemData['attributes']) || !is_array($customItemData['attributes'])) {
                continue;
            }

            foreach (array_keys($customItemData['attributes']) as $alias) {
                if (!is_string($alias) || $alias === '') {
                    continue;
                }

                if (!isset($allowedAliases[$alias])) {
                    throw new InvalidArgumentException(
                        sprintf('Unknown custom field alias "%s" for custom object "%s".', $alias, $customObject->getAlias()),
                        Response::HTTP_BAD_REQUEST
                    );
                }
            }
        }
    }
}

