<?php

declare(strict_types=1);

namespace MauticPlugin\SosCustomObjectsBundle\Service;

use Doctrine\DBAL\Connection;
use Doctrine\DBAL\Exception as DbalException;
use Doctrine\ORM\EntityManagerInterface;
use MauticPlugin\SosCustomObjectsBundle\Entity\CustomField;
use MauticPlugin\SosCustomObjectsBundle\Entity\CustomItem;
use MauticPlugin\SosCustomObjectsBundle\Entity\CustomItemValue;
use MauticPlugin\SosCustomObjectsBundle\Entity\CustomObject;
use MauticPlugin\SosCustomObjectsBundle\Repository\CustomFieldRepository;
use MauticPlugin\SosCustomObjectsBundle\Repository\CustomItemRepository;
use MauticPlugin\SosCustomObjectsBundle\Repository\CustomItemValueRepository;

final class CustomItemService
{
    public function __construct(
        private EntityManagerInterface $em,
        private Connection $db,
        private CustomItemRepository $itemRepo,
        private CustomFieldRepository $fieldRepo,
        private CustomItemValueRepository $valueRepo,
    ) {}

    /** @return CustomItem[] */
    public function list(CustomObject $object): array
    {
        return $this->itemRepo->findByObject($object);
    }

    public function get(int $id): ?CustomItem
    {
        return $this->itemRepo->find($id);
    }

    /** @return CustomField[] */
    public function fields(CustomObject $object): array
    {
        return $this->fieldRepo->findByObject($object);
    }

    /**
     * @return array<int, mixed> map fieldId => normalized value
     */
    public function getItemValues(CustomItem $item): array
    {
        $values = [];
        foreach ($this->valueRepo->findByItem($item) as $v) {
            $f = $v->getField();
            $values[$f->getId()] = $this->valueToScalar($f, $v);
        }
        return $values;
    }

    /**
     * @param array<string, mixed> $input map fieldAlias => raw value
     */
    public function create(CustomObject $object, ?string $label, array $input): CustomItem
    {
        $item = new CustomItem($object);
        $item->setLabel($label ? trim($label) : null);

        $this->em->persist($item);
        $this->em->flush();

        $this->saveValues($item, $input);
        return $item;
    }

    /**
     * @param array<string, mixed> $input
     */
    public function update(CustomItem $item, ?string $label, array $input): CustomItem
    {
        $item->setLabel($label ? trim($label) : null);
        $item->touch();
        $this->em->flush();

        $this->saveValues($item, $input);
        return $item;
    }

    public function delete(CustomItem $item): void
    {
        $this->em->remove($item);
        $this->em->flush();
    }

    /**
     * Links an item to a contact by ID.
     */
    public function linkContact(CustomItem $item, int $contactId): void
    {
        $params = $this->db->getParams();
        $prefixStr = $params['table_prefix'] ?? '';
        $joinTable = $prefixStr.'sos_custom_item_contact';

        if (!$this->linkTableReady($joinTable)) {
            throw new \RuntimeException(sprintf(
                'Tabela "%s" nÃ£o existe. Rode as migrations do plugin (mautic:plugins:reload / doctrine:migrations:migrate) e tente novamente.',
                $joinTable
            ));
        }

        $platform = strtolower((string) $this->db->getDatabasePlatform()->getName());

        try {
            if (in_array($platform, ['mysql', 'mariadb'], true)) {
                // MySQL/MariaDB: avoid duplicates via INSERT IGNORE
                $this->db->executeStatement(
                    "INSERT IGNORE INTO `$joinTable` (`custom_item_id`,`contact_id`) VALUES (:iid,:cid)",
                    ['iid' => $item->getId(), 'cid' => $contactId]
                );
            } else {
                // Generic: try insert, ignore unique constraint violation if it already exists
                $this->db->executeStatement(
                    "INSERT INTO `$joinTable` (`custom_item_id`,`contact_id`) VALUES (:iid,:cid)",
                    ['iid' => $item->getId(), 'cid' => $contactId]
                );
            }
        } catch (\Doctrine\DBAL\Exception\UniqueConstraintViolationException $e) {
            // already linked
        }
    }


    public function unlinkContact(CustomItem $item, int $contactId): void
    {
        $params = $this->db->getParams();
        $prefixStr = $params['table_prefix'] ?? '';
        $joinTable = $prefixStr.'sos_custom_item_contact';

        if (!$this->linkTableReady($joinTable)) {
            throw new \RuntimeException(sprintf(
                'Tabela "%s" nÃ£o existe. Rode as migrations do plugin (mautic:plugins:reload / doctrine:migrations:migrate) e tente novamente.',
                $joinTable
            ));
        }

        $this->db->executeStatement(
            "DELETE FROM `$joinTable` WHERE `custom_item_id` = :iid AND `contact_id` = :cid",
            ['iid' => $item->getId(), 'cid' => $contactId]
        );
    }

    /**
     * @param array<string, mixed> $input (fieldAlias => value)
     */
    private function saveValues(CustomItem $item, array $input): void
    {
        $fields = $this->fieldRepo->findByObject($item->getObject());

        foreach ($fields as $field) {
            $alias = $field->getAlias();
            $raw = $input[$alias] ?? null;

            $value = $this->valueRepo->findOneByItemAndField($item, (int)$field->getId());
            if (!$value) {
                $value = new CustomItemValue($item, $field);
                $this->em->persist($value);
            }

            $this->applyValue($field, $value, $raw);
        }

        $this->em->flush();
    }

    private function applyValue(CustomField $field, CustomItemValue $value, mixed $raw): void
    {
        // reset
        $value->setValueText(null)->setValueNumber(null)->setValueDate(null)->setValueBool(null);

        if ($raw === null || $raw === '') {
            return;
        }

        switch ($field->getType()) {
            case CustomField::TYPE_NUMBER:
                $num = is_numeric($raw) ? (float) $raw : null;
                $value->setValueNumber($num);
                break;

            case CustomField::TYPE_BOOL:
                $bool = filter_var($raw, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
                if ($bool === null) {
                    $bool = ((string)$raw === '1');
                }
                $value->setValueBool($bool);
                break;

            case CustomField::TYPE_DATE:
                try {
                    $dt = new \DateTime((string)$raw);
                    $value->setValueDate($dt);
                    $value->setValueText($dt->format('Y-m-d'));
                } catch (\Throwable) {
                    // ignore invalid date
                }
                break;

            case CustomField::TYPE_SELECT:
                $opts = $field->getOptions() ?: [];
                $v = (string) $raw;
                if ($opts && !in_array($v, $opts, true)) {
                    // allow but keep value anyway
                }
                $value->setValueText($v);
                break;

            case CustomField::TYPE_TEXT:
            default:
                $value->setValueText((string)$raw);
                break;
        }
    }

    private function valueToScalar(CustomField $field, CustomItemValue $v): mixed
    {
        return match ($field->getType()) {
            CustomField::TYPE_NUMBER => $v->getValueNumber(),
            CustomField::TYPE_BOOL => $v->getValueBool(),
            CustomField::TYPE_DATE => $v->getValueDate()?->format(DATE_ATOM),
            CustomField::TYPE_SELECT,
            CustomField::TYPE_TEXT => $v->getValueText(),
            default => $v->getValueText(),
        };
    }

    private function linkTableReady(string $tableName): bool
    {
        try {
            return $this->db->createSchemaManager()->tablesExist([$tableName]);
        } catch (DbalException|\Throwable) {
            return false;
        }
    }
}
