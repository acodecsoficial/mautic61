<?php

declare(strict_types=1);

namespace MauticPlugin\SosCustomObjectsBundle;

use Mautic\IntegrationsBundle\Bundle\AbstractPluginBundle;
use MauticPlugin\SosCustomObjectsBundle\DependencyInjection\Compiler\TwigPathPass;
use Symfony\Component\DependencyInjection\ContainerBuilder;

final class SosCustomObjectsBundle extends AbstractPluginBundle
{
    public function build(ContainerBuilder $container): void
    {
        parent::build($container);

        $container->addCompilerPass(new TwigPathPass());
    }
}
