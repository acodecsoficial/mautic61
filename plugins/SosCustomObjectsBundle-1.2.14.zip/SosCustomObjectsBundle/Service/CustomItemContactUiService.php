<?php

declare(strict_types=1);

namespace MauticPlugin\SosCustomObjectsBundle\Service;

use Doctrine\DBAL\Connection;
use Doctrine\DBAL\Exception as DbalException;
use MauticPlugin\SosCustomObjectsBundle\Repository\CustomItemRepository;
use MauticPlugin\SosCustomObjectsBundle\Repository\CustomObjectRepository;

final class CustomItemContactUiService
{
    private ?string $cachedTextValueColumn = null;
    /** @var array<string, string>|null */
    private ?array $cachedValueColumns = null;

    public function __construct(
        private Connection $db,
        private CustomItemRepository $itemRepo,
        private CustomObjectRepository $objectRepo,
        private CustomItemService $itemService,
    ) {}

    public function link(int $contactId, int $itemId): void
    {
        $item = $this->itemRepo->find($itemId);
        if (!$item) {
            throw new \RuntimeException('Item não encontrado.');
        }
        $this->itemService->linkContact($item, $contactId);
    }

    public function unlink(int $contactId, int $itemId): void
    {
        $item = $this->itemRepo->find($itemId);
        if (!$item) {
            throw new \RuntimeException('Item não encontrado.');
        }
        $this->itemService->unlinkContact($item, $contactId);
    }

    /**
     * @return array<string, array<int, array<string, mixed>>>
     */
    public function getLinkedItemsGrouped(int $contactId): array
    {
        if (!$this->tablesReady()) {
            return [];
        }

        $params = $this->db->getParams();
        $prefix = $params['table_prefix'] ?? '';

        $nameExpr = $this->textValueExpr((string) $prefix, 'v').' as name';

        $sql = "SELECT i.id, i.custom_object_id as object_id, {$nameExpr}
                FROM {$prefix}sos_custom_item_contact c
                INNER JOIN {$prefix}sos_custom_item i ON i.id = c.custom_item_id
                LEFT JOIN {$prefix}sos_custom_item_value v
                    ON v.custom_item_id = i.id
                LEFT JOIN {$prefix}sos_custom_field f
                    ON f.id = v.custom_field_id AND f.alias = 'name'
                WHERE c.contact_id = :cid
                ORDER BY i.custom_object_id ASC, i.id ASC";

        $rows = $this->db->fetchAllAssociative($sql, ['cid' => $contactId]);

        $objects = $this->objectRepo->findAll();
        $objectNames = [];
        foreach ($objects as $o) {
            $objectNames[$o->getId()] = $o->getName();
        }

        $out = [];
        foreach ($rows as $r) {
            $objId = (int) $r['object_id'];
            $objName = $objectNames[$objId] ?? ('Objeto #'.$objId);
            $out[$objName][] = [
                'id'        => (int) $r['id'],
                'object_id' => $objId,
                'name'      => $r['name'],
            ];
        }

        return $out;
    }

    /**
     * @return array<int, int> map objectId => count
     */
    public function countLinkedByObject(int $contactId): array
    {
        if (!$this->tablesReady()) {
            return [];
        }

        $params = $this->db->getParams();
        $prefix = $params['table_prefix'] ?? '';

        $sql = "SELECT i.custom_object_id as object_id, COUNT(*) as cnt
                FROM {$prefix}sos_custom_item_contact c
                INNER JOIN {$prefix}sos_custom_item i ON i.id = c.custom_item_id
                WHERE c.contact_id = :cid
                GROUP BY i.custom_object_id";

        $rows = $this->db->fetchAllAssociative($sql, ['cid' => $contactId]);

        $out = [];
        foreach ($rows as $r) {
            $out[(int) $r['object_id']] = (int) $r['cnt'];
        }

        return $out;
    }

    public function acdCountLinkedItems(int $contactId): int
    {
        if (!$this->tablesReady()) {
            return 0;
        }

        $params = $this->db->getParams();
        $prefix = (string) ($params['table_prefix'] ?? '');
        $sql = "SELECT COUNT(*)
                FROM {$prefix}sos_custom_item_contact c
                INNER JOIN {$prefix}sos_custom_item i ON i.id = c.custom_item_id
                WHERE c.contact_id = :cid";

        return (int) $this->db->fetchOne($sql, ['cid' => $contactId]);
    }

    public function acdCountLinkedItemsForObject(int $contactId, int $objectId): int
    {
        if (!$this->tablesReady() || $objectId < 1) {
            return 0;
        }

        $params = $this->db->getParams();
        $prefix = (string) ($params['table_prefix'] ?? '');
        $sql = "SELECT COUNT(*)
                FROM {$prefix}sos_custom_item_contact c
                INNER JOIN {$prefix}sos_custom_item i ON i.id = c.custom_item_id
                WHERE c.contact_id = :cid AND i.custom_object_id = :oid";

        return (int) $this->db->fetchOne($sql, ['cid' => $contactId, 'oid' => $objectId]);
    }

    /**
     * @return array<string, array<int, array{id:int,object_id:int,name:?string}>>
     */
    public function acdGetLinkedItemsGroupedPage(int $contactId, int $limit, int $offset): array
    {
        if (!$this->tablesReady()) {
            return [];
        }

        $params = $this->db->getParams();
        $prefix = (string) ($params['table_prefix'] ?? '');
        $sql = "SELECT i.id, i.custom_object_id as object_id
                FROM {$prefix}sos_custom_item_contact c
                INNER JOIN {$prefix}sos_custom_item i ON i.id = c.custom_item_id
                WHERE c.contact_id = :cid
                ORDER BY i.custom_object_id ASC, i.id ASC
                LIMIT ".max(1, $limit).' OFFSET '.max(0, $offset);
        $rows = $this->db->fetchAllAssociative($sql, ['cid' => $contactId]);
        if ([] === $rows) {
            return [];
        }

        $itemIds = array_map(static fn (array $row): int => (int) $row['id'], $rows);
        $itemNames = $this->acdGetItemNamesByIds($itemIds, $prefix);
        $objects = $this->objectRepo->findAll();
        $objectNames = [];
        foreach ($objects as $object) {
            $objectNames[$object->getId()] = $object->getName();
        }

        $grouped = [];
        foreach ($rows as $row) {
            $itemId = (int) $row['id'];
            $objectId = (int) $row['object_id'];
            $objectName = $objectNames[$objectId] ?? ('Objeto #'.$objectId);
            $grouped[$objectName][] = [
                'id' => $itemId,
                'object_id' => $objectId,
                'name' => $itemNames[$itemId] ?? null,
            ];
        }

        return $grouped;
    }

    public function acdCountItemsForObject(int $objectId): int
    {
        if (!$this->tablesReady() || $objectId < 1) {
            return 0;
        }

        $params = $this->db->getParams();
        $prefix = (string) ($params['table_prefix'] ?? '');
        $sql = "SELECT COUNT(*) FROM {$prefix}sos_custom_item i WHERE i.custom_object_id = :oid";

        return (int) $this->db->fetchOne($sql, ['oid' => $objectId]);
    }

    /**
     * @return array<int, array{id:int,name:?string}>
     */
    public function acdGetItemOptionsPage(int $objectId, int $limit, int $offset): array
    {
        if (!$this->tablesReady() || $objectId < 1) {
            return [];
        }

        $params = $this->db->getParams();
        $prefix = (string) ($params['table_prefix'] ?? '');
        $sql = "SELECT i.id
                FROM {$prefix}sos_custom_item i
                WHERE i.custom_object_id = :oid
                ORDER BY i.id DESC
                LIMIT ".max(1, $limit).' OFFSET '.max(0, $offset);
        $rows = $this->db->fetchAllAssociative($sql, ['oid' => $objectId]);
        if ([] === $rows) {
            return [];
        }

        $itemIds = array_map(static fn (array $row): int => (int) $row['id'], $rows);
        $itemNames = $this->acdGetItemNamesByIds($itemIds, $prefix);
        $items = [];
        foreach ($itemIds as $itemId) {
            $items[] = ['id' => $itemId, 'name' => $itemNames[$itemId] ?? null];
        }

        return $items;
    }

    /**
     * @return array<int, array{id:int,name:?string}>
     */
    public function getLinkedItemsForObject(int $contactId, int $objectId): array
    {
        if (!$this->tablesReady()) {
            return [];
        }

        $params = $this->db->getParams();
        $prefix = $params['table_prefix'] ?? '';

        $nameExpr = $this->textValueExpr((string) $prefix, 'v').' as name';

        $sql = "SELECT i.id, {$nameExpr}
                FROM {$prefix}sos_custom_item_contact c
                INNER JOIN {$prefix}sos_custom_item i ON i.id = c.custom_item_id
                LEFT JOIN {$prefix}sos_custom_item_value v
                    ON v.custom_item_id = i.id
                LEFT JOIN {$prefix}sos_custom_field f
                    ON f.id = v.custom_field_id AND f.alias = 'name'
                WHERE c.contact_id = :cid AND i.custom_object_id = :oid
                ORDER BY i.id ASC";

        $rows = $this->db->fetchAllAssociative($sql, ['cid' => $contactId, 'oid' => $objectId]);

        $out = [];
        foreach ($rows as $r) {
            $out[] = ['id' => (int) $r['id'], 'name' => $r['name']];
        }

        return $out;
    }

    /**
     * @return array<int, array{id:int,name:string}>
     */
    public function getObjects(): array
    {
        $objs = $this->objectRepo->findAll();
        $out  = [];
        foreach ($objs as $o) {
            $out[] = ['id' => $o->getId(), 'name' => $o->getName()];
        }
        return $out;
    }

    /**
     * @return array<string, array<int, array{id:int,name:?string}>>
     */
    public function getItemsByObject(): array
    {
        if (!$this->tablesReady()) {
            return [];
        }

        $params = $this->db->getParams();
        $prefix = $params['table_prefix'] ?? '';

        // bring item names if there is a field alias 'name'
        $nameExpr = $this->textValueExpr((string) $prefix, 'v').' as name';

        $sql = "SELECT i.id, i.custom_object_id as object_id, {$nameExpr}
                FROM {$prefix}sos_custom_item i
                LEFT JOIN {$prefix}sos_custom_item_value v
                    ON v.custom_item_id = i.id
                LEFT JOIN {$prefix}sos_custom_field f
                    ON f.id = v.custom_field_id AND f.alias = 'name'
                ORDER BY i.custom_object_id ASC, i.id ASC";

        $rows = $this->db->fetchAllAssociative($sql);

        $out = [];
        foreach ($rows as $r) {
            $oid = (string) ((int) $r['object_id']);
            $out[$oid][] = ['id' => (int)$r['id'], 'name' => $r['name']];
        }
        return $out;
    }

    /**
     * @return array<int, array{id:int,label:?string,attributes:array<string,mixed>}>
     */
    public function getLinkedItemsWithAttributesForObject(int $contactId, int $objectId): array
    {
        return $this->acdGetLinkedItemsWithAttributes($contactId, $objectId, null, 0);
    }

    /**
     * @return array<int, array{id:int,label:?string,attributes:array<string,mixed>}>
     */
    public function acdGetLinkedItemsWithAttributesPage(int $contactId, int $objectId, int $limit, int $offset): array
    {
        return $this->acdGetLinkedItemsWithAttributes($contactId, $objectId, max(1, $limit), max(0, $offset));
    }

    /**
     * @return array<int, array{id:int,label:?string,attributes:array<string,mixed>}>
     */
    private function acdGetLinkedItemsWithAttributes(int $contactId, int $objectId, ?int $limit, int $offset): array
    {
        if (!$this->tablesReady()) {
            return [];
        }

        $params = $this->db->getParams();
        $prefix = (string) ($params['table_prefix'] ?? '');

        $itemTable  = $prefix.'sos_custom_item';
        $valueTable = $prefix.'sos_custom_item_value';
        $fieldTable = $prefix.'sos_custom_field';
        $linkTable  = $prefix.'sos_custom_item_contact';

        $itemIdsSql = "SELECT i.id
                       FROM {$linkTable} c
                       INNER JOIN {$itemTable} i ON i.id = c.custom_item_id
                       WHERE c.contact_id = :cid AND i.custom_object_id = :oid
                       ORDER BY i.id ASC";
        if (null !== $limit) {
            $itemIdsSql .= ' LIMIT '.max(1, $limit).' OFFSET '.max(0, $offset);
        }

        $itemIdRows = $this->db->fetchAllAssociative($itemIdsSql, ['cid' => $contactId, 'oid' => $objectId]);
        if ([] === $itemIdRows) {
            return [];
        }

        $itemIds = array_map(static fn (array $row): int => (int) $row['id'], $itemIdRows);
        [$idPlaceholders, $idParameters] = $this->acdCreateItemIdPlaceholders($itemIds);

        $textCol = $this->textValueSelect((string) $prefix, 'v', 'value_text');
        $numCol  = $this->valueSelectFromCandidates((string) $prefix, 'v', 'value_number', ['value_number', 'valueNumber']);
        $dateCol = $this->valueSelectFromCandidates((string) $prefix, 'v', 'value_date', ['value_date', 'valueDate']);
        $boolCol = $this->valueSelectFromCandidates((string) $prefix, 'v', 'value_bool', ['value_bool', 'valueBool']);

        $sql = "SELECT
                    i.id as item_id,
                    i.label as item_label,
                    f.alias as field_alias,
                    f.type as field_type,
                    {$textCol},
                    {$numCol},
                    {$dateCol},
                    {$boolCol}
                FROM {$linkTable} c
                INNER JOIN {$itemTable} i ON i.id = c.custom_item_id
                LEFT JOIN {$valueTable} v ON v.custom_item_id = i.id
                LEFT JOIN {$fieldTable} f ON f.id = v.custom_field_id
                WHERE c.contact_id = :cid AND i.custom_object_id = :oid
                    AND i.id IN (".implode(', ', $idPlaceholders).")
                ORDER BY i.id ASC";

        $rows = $this->db->fetchAllAssociative($sql, array_merge(['cid' => $contactId, 'oid' => $objectId], $idParameters));

        $items = [];
        foreach ($rows as $r) {
            $itemId = (int) $r['item_id'];
            if (!isset($items[$itemId])) {
                $items[$itemId] = [
                    'id'         => $itemId,
                    'label'      => $r['item_label'],
                    'attributes' => [],
                ];
            }

            $alias = $r['field_alias'];
            if (!is_string($alias) || $alias === '') {
                continue;
            }

            $items[$itemId]['attributes'][$alias] = $this->normalizeValueRow($r);
        }

        return array_values($items);
    }

    /**
     * @param int[] $itemIds
     * @return array{0:list<string>,1:array<string,int>}
     */
    private function acdCreateItemIdPlaceholders(array $itemIds): array
    {
        $placeholders = [];
        $parameters = [];
        foreach (array_values(array_unique(array_filter($itemIds, static fn (int $itemId): bool => $itemId > 0))) as $index => $itemId) {
            $key = 'item_'.$index;
            $placeholders[] = ':'.$key;
            $parameters[$key] = $itemId;
        }

        return [$placeholders, $parameters];
    }

    /**
     * @param int[] $itemIds
     * @return array<int, string|null>
     */
    private function acdGetItemNamesByIds(array $itemIds, string $prefix): array
    {
        [$placeholders, $parameters] = $this->acdCreateItemIdPlaceholders($itemIds);
        if ([] === $placeholders) {
            return [];
        }

        $nameExpression = $this->textValueExpr($prefix, 'v');
        $sql = "SELECT i.id, {$nameExpression} as name
                FROM {$prefix}sos_custom_item i
                LEFT JOIN {$prefix}sos_custom_field f
                    ON f.custom_object_id = i.custom_object_id AND f.alias = 'name'
                LEFT JOIN {$prefix}sos_custom_item_value v
                    ON v.custom_item_id = i.id AND v.custom_field_id = f.id
                WHERE i.id IN (".implode(', ', $placeholders).')';

        $names = [];
        foreach ($this->db->fetchAllAssociative($sql, $parameters) as $row) {
            $names[(int) $row['id']] = null === $row['name'] ? null : (string) $row['name'];
        }

        return $names;
    }

    private function tablesReady(): bool
    {
        try {
            $params = $this->db->getParams();
            $prefix = (string) ($params['table_prefix'] ?? '');

            $schema = $this->db->createSchemaManager();

            return $schema->tablesExist([
                $prefix.'sos_custom_item_contact',
                $prefix.'sos_custom_item',
                $prefix.'sos_custom_object',
                $prefix.'sos_custom_item_value',
                $prefix.'sos_custom_field',
            ]);
        } catch (DbalException|\Throwable) {
            return false;
        }
    }

    /**
     * @param array<string, mixed> $row
     */
    private function normalizeValueRow(array $row): mixed
    {
        $type = (string) ($row['field_type'] ?? '');

        return match ($type) {
            'number' => isset($row['value_number']) ? (float) $row['value_number'] : null,
            'bool' => isset($row['value_bool']) ? (bool) $row['value_bool'] : null,
            'date',
            'datetime' => $row['value_date'] ? (new \DateTime((string) $row['value_date']))->format(DATE_ATOM) : null,
            default => $row['value_text'] ?? null,
        };
    }

    private function textValueExpr(string $prefix, string $alias): string
    {
        $col = $this->getTextValueColumn($prefix);
        if (null === $col) {
            return 'NULL';
        }

        return $alias.'.'.$col;
    }

    private function textValueSelect(string $prefix, string $alias, string $as): string
    {
        $expr = $this->textValueExpr($prefix, $alias);

        return $expr.' as '.$as;
    }

    private function valueSelect(string $prefix, string $alias, string $col): string
    {
        if (!$this->hasValueColumn($prefix, $col)) {
            return 'NULL as '.$col;
        }

        return $alias.'.'.$this->getActualValueColumn($prefix, $col).' as '.$col;
    }

    /**
     * @param string[] $candidates
     */
    private function valueSelectFromCandidates(string $prefix, string $alias, string $as, array $candidates): string
    {
        foreach ($candidates as $col) {
            if ($this->hasValueColumn($prefix, $col)) {
                return $alias.'.'.$this->getActualValueColumn($prefix, $col).' as '.$as;
            }
        }

        return 'NULL as '.$as;
    }

    private function getTextValueColumn(string $prefix): ?string
    {
        if (null !== $this->cachedTextValueColumn) {
            return $this->cachedTextValueColumn;
        }

        if ($this->hasValueColumn($prefix, 'value_text')) {
            $this->cachedTextValueColumn = $this->getActualValueColumn($prefix, 'value_text');
            return $this->cachedTextValueColumn;
        }

        if ($this->hasValueColumn($prefix, 'valueText')) {
            $this->cachedTextValueColumn = $this->getActualValueColumn($prefix, 'valueText');
            return $this->cachedTextValueColumn;
        }

        if ($this->hasValueColumn($prefix, 'value')) {
            $this->cachedTextValueColumn = $this->getActualValueColumn($prefix, 'value');
            return $this->cachedTextValueColumn;
        }

        $this->cachedTextValueColumn = null;

        return null;
    }

    private function hasValueColumn(string $prefix, string $column): bool
    {
        if (null === $this->cachedValueColumns) {
            try {
                $schema = $this->db->createSchemaManager();
                $cols = $schema->listTableColumns($prefix.'sos_custom_item_value');

                $this->cachedValueColumns = [];
                foreach ($cols as $name => $_col) {
                    $lower = strtolower((string) $name);
                    $this->cachedValueColumns[$lower] = (string) $name;
                }
            } catch (DbalException|\Throwable) {
                $this->cachedValueColumns = [];
            }
        }

        return isset($this->cachedValueColumns[strtolower($column)]);
    }

    private function getActualValueColumn(string $prefix, string $column): string
    {
        // Ensure cache is warm
        $this->hasValueColumn($prefix, $column);

        return $this->cachedValueColumns[strtolower($column)] ?? $column;
    }
}
