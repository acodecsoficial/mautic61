<?php

namespace MauticPlugin\AcodecsWhitelabelBundle;

use Mautic\PluginBundle\Bundle\PluginBundleBase;

class AcodecsWhitelabelBundle extends PluginBundleBase
{
}
