<?php

declare(strict_types=1);

namespace MauticPlugin\MauticSmsapiBundle\Migrations;

use Doctrine\DBAL\Schema\Schema;
use Mautic\IntegrationsBundle\Migration\AbstractMigration;

final class Version_1_0_0 extends AbstractMigration
{
    protected function isApplicable(Schema $schema): bool
    {
        $companiesTable = $this->concatPrefix('companies');

        if (!$schema->hasTable($companiesTable)) {
            return false;
        }

        return !$schema->getTable($companiesTable)->hasColumn('sms_client_name');
    }

    protected function up(): void
    {
        $companiesTable  = $this->concatPrefix('companies');
        $leadFieldsTable = $this->concatPrefix('lead_fields');

        $this->addSql("ALTER TABLE `{$companiesTable}` ADD COLUMN `sms_client_name` VARCHAR(255) DEFAULT NULL");

        $this->addSql("
            INSERT INTO `{$leadFieldsTable}`
                (is_published, label, alias, type, field_group, object,
                 is_required, is_fixed, is_visible, is_short_visible,
                 is_listable, is_publicly_updatable, is_unique_identifer,
                 is_index, column_is_not_created, column_is_not_removed,
                 original_is_published_value, field_order, properties)
            SELECT
                1, 'SMS Nome do Cliente', 'sms_client_name', 'text', 'core', 'company',
                0, 0, 1, 0,
                1, 0, 0,
                0, 0, 0,
                1,
                COALESCE((SELECT MAX(f2.field_order) FROM `{$leadFieldsTable}` f2 WHERE f2.object = 'company'), 0) + 1,
                'a:0:{}'
            WHERE NOT EXISTS (
                SELECT 1 FROM `{$leadFieldsTable}`
                WHERE alias = 'sms_client_name' AND object = 'company'
            )
        ");
    }
}
