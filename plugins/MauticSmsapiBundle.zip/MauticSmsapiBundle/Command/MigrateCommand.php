<?php

declare(strict_types=1);

namespace MauticPlugin\MauticSmsapiBundle\Command;

use Doctrine\ORM\EntityManagerInterface;
use Mautic\IntegrationsBundle\Migration\Engine;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class MigrateCommand extends Command
{
    protected static $defaultName = 'mautic:smsapi:migrate';

    public function __construct(private EntityManagerInterface $em)
    {
        parent::__construct();
    }

    protected function configure(): void
    {
        $this->setDescription('Runs MauticSmsapiBundle database migrations');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $tablePrefix = (string) (defined('MAUTIC_TABLE_PREFIX') ? MAUTIC_TABLE_PREFIX : '');

        $engine = new Engine(
            $this->em,
            $tablePrefix,
            __DIR__ . '/..',
            'MauticSmsapiBundle'
        );

        $engine->up();

        $output->writeln('<info>MauticSmsapiBundle migrations executed successfully.</info>');

        return Command::SUCCESS;
    }
}
