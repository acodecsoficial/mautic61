<?php

declare(strict_types=1);

namespace MauticPlugin\AcdGenericApiMailerBundle\Integration;

use Mautic\IntegrationsBundle\Integration\BasicIntegration;

class AcdGenericApiMailerIntegration extends BasicIntegration
{
    public const NAME = 'AcdGenericApiMailer';

    public function getName(): string
    {
        return self::NAME;
    }

    public function getDisplayName(): string
    {
        return 'Acodecs API Mailer';
    }

    public function getIcon(): string
    {
        return 'plugins/AcdGenericApiMailerBundle/Assets/img/acd-mail-api.svg';
    }
}