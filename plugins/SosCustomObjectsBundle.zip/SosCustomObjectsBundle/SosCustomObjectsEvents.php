<?php

declare(strict_types=1);

namespace MauticPlugin\SosCustomObjectsBundle;

final class SosCustomObjectsEvents
{
    public const EXECUTE_CAMPAIGN_ACTION    = 'sos_custom_objects.execute_campaign_action';
    public const EVALUATE_CAMPAIGN_CONDITION = 'sos_custom_objects.evaluate_campaign_condition';
}
