<?php

declare(strict_types=1);

namespace MauticPlugin\SosCustomObjectsBundle\Migrations;

use Doctrine\DBAL\Schema\Schema;
use Mautic\IntegrationsBundle\Migration\AbstractMigration;

final class Version_1_1_0 extends AbstractMigration
{
    protected function isApplicable(Schema $schema): bool
    {
        return !$schema->hasTable($this->concatPrefix('sos_custom_item_contact'));
    }

    protected function up(): void
    {
        $objTable   = $this->concatPrefix('sos_custom_object');
        $fieldTable = $this->concatPrefix('sos_custom_field');
        $itemTable  = $this->concatPrefix('sos_custom_item');
        $valTable   = $this->concatPrefix('sos_custom_item_value');
        $linkTable  = $this->concatPrefix('sos_custom_item_contact');

        // Fields
        $this->addSql("
            CREATE TABLE `$fieldTable` (
              `id` INT AUTO_INCREMENT NOT NULL,
              `custom_object_id` INT NOT NULL,
              `label` VARCHAR(191) NOT NULL,
              `alias` VARCHAR(191) NOT NULL,
              `type` VARCHAR(20) NOT NULL,
              `is_required` TINYINT(1) NOT NULL DEFAULT 0,
              `options` JSON DEFAULT NULL,
              `date_added` DATETIME NOT NULL,
              `date_modified` DATETIME DEFAULT NULL,
              UNIQUE KEY `uniq_sos_custom_field_object_alias` (`custom_object_id`,`alias`),
              INDEX `idx_sos_custom_field_object` (`custom_object_id`),
              PRIMARY KEY(`id`),
              CONSTRAINT `fk_sos_custom_field_object` FOREIGN KEY (`custom_object_id`) REFERENCES `$objTable` (`id`) ON DELETE CASCADE
            ) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB
        ");

        // Items
        $this->addSql("
            CREATE TABLE `$itemTable` (
              `id` INT AUTO_INCREMENT NOT NULL,
              `custom_object_id` INT NOT NULL,
              `label` VARCHAR(191) DEFAULT NULL,
              `date_added` DATETIME NOT NULL,
              `date_modified` DATETIME DEFAULT NULL,
              INDEX `idx_sos_custom_item_object` (`custom_object_id`),
              PRIMARY KEY(`id`),
              CONSTRAINT `fk_sos_custom_item_object` FOREIGN KEY (`custom_object_id`) REFERENCES `$objTable` (`id`) ON DELETE CASCADE
            ) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB
        ");

        // Values (EAV)
        $this->addSql("
            CREATE TABLE `$valTable` (
              `id` INT AUTO_INCREMENT NOT NULL,
              `custom_item_id` INT NOT NULL,
              `custom_field_id` INT NOT NULL,
              `valueText` LONGTEXT DEFAULT NULL,
              `valueNumber` DOUBLE DEFAULT NULL,
              `valueDate` DATETIME DEFAULT NULL,
              `valueBool` TINYINT(1) DEFAULT NULL,
              UNIQUE KEY `uniq_sos_item_field` (`custom_item_id`,`custom_field_id`),
              INDEX `idx_sos_value_item` (`custom_item_id`),
              INDEX `idx_sos_value_field` (`custom_field_id`),
              PRIMARY KEY(`id`),
              CONSTRAINT `fk_sos_value_item` FOREIGN KEY (`custom_item_id`) REFERENCES `$itemTable` (`id`) ON DELETE CASCADE,
              CONSTRAINT `fk_sos_value_field` FOREIGN KEY (`custom_field_id`) REFERENCES `$fieldTable` (`id`) ON DELETE CASCADE
            ) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB
        ");

        // Item <-> Contact links (by contact_id)
        $this->addSql("
            CREATE TABLE `$linkTable` (
              `custom_item_id` INT NOT NULL,
              `contact_id` INT NOT NULL,
              INDEX `idx_sos_item_contact_item` (`custom_item_id`),
              INDEX `idx_sos_item_contact_contact` (`contact_id`),
              UNIQUE KEY `uniq_sos_item_contact` (`custom_item_id`,`contact_id`),
              CONSTRAINT `fk_sos_item_contact_item` FOREIGN KEY (`custom_item_id`) REFERENCES `$itemTable` (`id`) ON DELETE CASCADE
            ) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB
        ");
    }
}
