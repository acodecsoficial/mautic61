# Acodecs Generic API Mailer para Mautic 6

Plugin independente para enviar e-mails do Mautic por APIs HTTP/HTTPS usando o Symfony Mailer. O DSN do Mautic permanece fixo em `generic-api://default`; provedores, endereços de envio e credenciais ficam na configuração da integração do plugin.

## Requisitos

- Mautic 6.x.
- PHP 8.1 ou superior, conforme os requisitos do Mautic 6.
- Acesso HTTPS do processo web e dos processos de fila do Mautic ao endereço configurado.
- Um token SNDR com escopo `send` e domínio remetente verificado para o perfil SNDR.

## Instalação

1. Copie a pasta `AcdGenericApiMailerBundle` para `docroot/plugins` da instalação Mautic. O caminho final deve ser `docroot/plugins/AcdGenericApiMailerBundle`.
2. Na raiz do Mautic, execute:

   ```bash
   runuser -u www-data -- php bin/console cache:clear --env=prod
   runuser -u www-data -- php bin/console mautic:plugins:reload --env=prod
   ```

3. A integração **Acodecs API Mailer** aparecerá na configuração de plugins/integrações do Mautic. Ative-a antes de testar.
4. Em Configurações > Configuração do sistema > E-mail, informe `generic-api://default` no campo **Email DSN** e salve.
5. Instale os mesmos arquivos do plugin em cada instância/contêiner que inicializa Mautic, inclusive nos processos de fila de e-mail.

Os comandos mostrados acima são nativos do Mautic. O plugin não adiciona comandos próprios ao console.

Execute o bloco acima como root na raiz do Mautic. O cache deve pertencer ao usuário do servidor web; se necessário, ajuste antes com `chown -R www-data:www-data var/cache var/logs`. Quando já estiver conectado como www-data, execute os comandos PHP diretamente, sem runuser.

Este pacote mantém a versão de registro 1.0.0 e inclui as correções da herança da configuração, dos identificadores dos serviços e da opção integration no formulário de autenticação. Essa revisão substitui os arquivos da instalação 1.0.0 sem migrations. No ambiente em que a tentativa de atualizar para 1.0.1 falhou com PluginUpdateEvent recebendo metadados nulos, manter a versão registrada evita esse caminho defeituoso do atualizador do Mautic. Isso não corrige o atualizador do core; aumentos futuros de versão ainda exigem resolver essa incompatibilidade.

As configurações de perfis são lidas do registro da integração no banco em cada envio. Salvar a tela atualiza o perfil usado pelos próximos e-mails. `cache:clear` é necessário após instalar ou alterar arquivos do plugin; não é necessário para cada troca de credencial ou perfil.

## Configurar SNDR

1. No painel do SNDR, crie uma chave de API com escopo `send` e confirme que o domínio do remetente está verificado.
2. Abra a integração **Acodecs API Mailer**, selecione a aba de autenticação e informe o token no campo **Perfil 1: token Bearer ou chave de API**. O campo é mascarado; o Mautic criptografa a chave ao salvá-la. Depois de salvar, o valor não é exibido novamente. Para trocar a chave, informe a nova. Para removê-la, marque **Remover as credenciais do perfil 1**.
3. Na aba de configuração do perfil, selecione:
   - Perfil ativo: `Perfil 1`.
   - Nome: `SNDR` ou outro nome reconhecível.
   - Provedor ou adaptador: `SNDR`.
   - Endereço HTTPS para envio: `https://api.sndr.sh/v1/send`.
   - Tipo de autenticação: `Token Bearer`.
   - Tempo limite da requisição: entre 1 e 120 segundos.
4. Salve a integração.
5. Em Configurações > Configuração do sistema > E-mail, mantenha o DSN `generic-api://default`, informe um endereço remetente do domínio verificado e use **Enviar e-mail de teste**.

A API oficial do SNDR recebe `POST https://api.sndr.sh/v1/send`, com `Authorization: Bearer ...`, JSON e uma lista de destinatários. `GET /v1/emails` é a rota de consulta e não é usada para enviar. O adaptador trata respostas 2xx, incluindo `202 Accepted`, como aceite para processamento.

## Validar segmentos, campanhas e fila

1. Crie um contato interno de teste cujo endereço você possa acessar.
2. Envie primeiro um e-mail simples para esse contato, validando remetente, destinatário, assunto, HTML e texto.
3. Para uma campanha, adicione o contato de teste ao segmento usado pela campanha, publique a campanha e atualize os contatos/execuções:

   ```bash
   php bin/console mautic:segments:update
   php bin/console mautic:campaigns:update
   php bin/console mautic:campaigns:trigger
   ```

4. Se a fila de e-mails estiver habilitada, mantenha um consumidor ativo em outro processo:

   ```bash
   php bin/console messenger:consume email -vv
   ```

5. Para um disparo de segmento, use um e-mail de broadcast destinado apenas ao segmento de teste e processe a fila conforme a configuração do ambiente.
6. Confirme o aceite e o status no painel/log de mensagens do SNDR. No Mautic, confira `var/logs/prod-YYYY-MM-DD.php` ou o log do ambiente configurado.

O comando `mautic:campaigns:trigger` existe no Mautic 6. Para campanhas com fila, o consumidor `messenger:consume email` precisa processar as mensagens depois do disparo. O fluxo de segmentos também depende do agendamento de envios em massa configurado na instância.

## Perfis de API adicionais

A tela oferece três perfis independentes. Cada um pode escolher `SNDR` ou `HTTP com JSON (genérico)`, um endereço HTTPS, o tipo de autenticação, o tempo limite, cabeçalhos adicionais e o mapeamento dos dados em JSON. Os tokens, usuários e senhas dos três perfis ficam nos campos de autenticação do Mautic e são criptografados ao salvar.

Autenticações disponíveis no adaptador genérico:

- Token Bearer.
- Autenticação básica HTTP.
- Chave de API em cabeçalho configurável.
- Sem autenticação.

Exemplo de mapeamento JSON genérico:

```json
{
  "sender": "{{from}}",
  "recipients": "{{to}}",
  "subject": "{{subject}}",
  "html_body": "{{html}}",
  "text_body": "{{text}}"
}
```

Marcadores disponíveis: `{{from}}`, `{{to}}`, `{{cc}}`, `{{bcc}}`, `{{reply_to}}`, `{{subject}}`, `{{html}}`, `{{text}}`, `{{headers}}` e `{{attachments}}`. Para inserir listas ou objetos, use o marcador como valor JSON completo, como em `"recipients": "{{to}}"`.

Cabeçalhos adicionais devem ser um objeto JSON com valores de texto. Cabeçalhos de autenticação e transporte, incluindo `Authorization`, `Content-Type`, `Host` e `Idempotency-Key`, são reservados e não podem ser definidos ali.

## Segurança e falhas

- Tokens e credenciais usam a aba criptografada de autenticação do Mautic; o formulário mascara os valores salvos.
- O endereço de envio precisa usar HTTPS e não pode incluir credenciais ou parâmetros na URL. Hosts locais e endereços IP literais privados ou reservados são bloqueados; use somente serviços públicos confiáveis.
- Redirecionamentos HTTP são desabilitados para impedir o encaminhamento de credenciais a outro host.
- Logs registram perfil, código HTTP, código de erro e identificador de requisição quando fornecidos pela API. Tokens, corpo e destinatários não são registrados.
- Respostas fora de 2xx, tempos limite e falhas de rede lançam exceções do Symfony Mailer. Com Messenger, as novas tentativas seguem a política configurada no Mautic.
- Para SNDR, o plugin envia `Idempotency-Key` derivado do identificador da mensagem para tornar retries seguros.
- O transporte faz uma requisição por mensagem; não implementa envio em lote, notificações de devolução nem atualização automática da lista de contatos bloqueados.
- O transporte limita anexos a 10 arquivos e 10 MiB no total, conforme o limite documentado pelo SNDR. Imagens inseridas no corpo por `cid:` não fazem parte do corpo de envio suportado pela API documentada e são rejeitadas.

## Verificações locais

O teste autônomo em `Tests/run.php` valida a conversão da mensagem para SNDR, o mapeamento JSON genérico, os anexos comuns e erros de marcadores. Ele pode ser executado sem instalar Mautic:

```bash
php Tests/run.php
```

O teste não realiza requisições ao SNDR. Para validar entrega real, configure uma chave válida em uma instância Mautic 6 e execute os passos acima.
