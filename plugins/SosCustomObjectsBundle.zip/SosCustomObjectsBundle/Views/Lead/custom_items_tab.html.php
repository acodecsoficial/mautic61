<?php
/**
 * This template is injected into the Contact view via CoreEvents::VIEW_INJECT_CUSTOM_CONTENT.
 */

$lead = $view['lead'] ?? null;
$leadId = null;
if (is_array($lead) && isset($lead['id'])) {
    $leadId = (int) $lead['id'];
} elseif (is_object($lead) && method_exists($lead, 'getId')) {
    $leadId = (int) $lead->getId();
}
if (!$leadId) {
    return;
}

$url = $view['router']->path('sos_contact_custom_items_manage', ['leadId' => $leadId]);
$linked = $sosCustomObjectsLinked ?? [];
?>
<div class="panel panel-default" style="margin-top: 15px;">
    <div class="panel-heading">
        <div class="panel-title">Custom Items</div>
    </div>
    <div class="panel-body">
        <p>Custom Objects vinculados a este contato:</p>

        <?php if (!empty($linked) && is_array($linked)): ?>
            <?php foreach ($linked as $objectName => $items): ?>
                <div style="margin-bottom: 10px;">
                    <strong><?= htmlspecialchars((string) $objectName, ENT_QUOTES, 'UTF-8') ?></strong>
                    <ul style="margin-top: 5px;">
                        <?php foreach ($items as $item): ?>
                            <li>
                                #<?= (int) ($item['id'] ?? 0) ?>
                                <?= htmlspecialchars((string) ($item['name'] ?? ''), ENT_QUOTES, 'UTF-8') ?>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p><em>Nenhum item vinculado.</em></p>
        <?php endif; ?>

        <hr style="margin: 10px 0;" />
        <p>Gerencie os vínculos de Custom Items para este contato.</p>
        <a class="btn btn-primary btn-sm" href="<?= $url ?>">Abrir gerenciamento</a>
    </div>
</div>

<div class="modal fade" id="sos-custom-items-modal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Custom Items</h4>
      </div>
      <div class="modal-body">
        <p><a class="btn btn-primary" href="<?= $url ?>">Abrir gerenciamento</a></p>
      </div>
    </div>
  </div>
</div>

