<?php

declare(strict_types=1);

namespace MauticPlugin\AcdGenericApiMailerBundle;

use Mautic\PluginBundle\Bundle\PluginBundleBase;

class AcdGenericApiMailerBundle extends PluginBundleBase
{
}