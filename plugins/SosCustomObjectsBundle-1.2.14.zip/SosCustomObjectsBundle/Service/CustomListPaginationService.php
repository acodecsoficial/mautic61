<?php

declare(strict_types=1);

namespace MauticPlugin\SosCustomObjectsBundle\Service;

final class CustomListPaginationService
{
    public const ACD_PAGE_SIZE = 50;

    /**
     * @return array{currentPage:int,pageSize:int,offset:int,totalItems:int,totalPages:int,firstItem:int,lastItem:int,pages:list<int>}
     */
    public function acdBuild(int $requestedPage, int $totalItems): array
    {
        $totalItems = max(0, $totalItems);
        $totalPages = max(1, (int) ceil($totalItems / self::ACD_PAGE_SIZE));
        $currentPage = min(max(1, $requestedPage), $totalPages);
        $firstPage = max(1, min($currentPage - 2, $totalPages - 4));
        $lastPage = min($totalPages, $firstPage + 4);

        return [
            'currentPage' => $currentPage,
            'pageSize' => self::ACD_PAGE_SIZE,
            'offset' => ($currentPage - 1) * self::ACD_PAGE_SIZE,
            'totalItems' => $totalItems,
            'totalPages' => $totalPages,
            'firstItem' => 0 === $totalItems ? 0 : (($currentPage - 1) * self::ACD_PAGE_SIZE) + 1,
            'lastItem' => min($totalItems, $currentPage * self::ACD_PAGE_SIZE),
            'pages' => range($firstPage, $lastPage),
        ];
    }
}
