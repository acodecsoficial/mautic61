<?php

declare(strict_types=1);

namespace MauticPlugin\SosCustomObjectsBundle\Controller;

use Doctrine\Persistence\ManagerRegistry;
use Mautic\CoreBundle\Controller\CommonController;
use Mautic\CoreBundle\Factory\ModelFactory;
use Mautic\CoreBundle\Helper\CoreParametersHelper;
use Mautic\CoreBundle\Helper\InputHelper;
use Mautic\CoreBundle\Helper\UserHelper;
use Mautic\CoreBundle\Security\Permissions\CorePermissions;
use Mautic\CoreBundle\Service\FlashBag;
use Mautic\CoreBundle\Translation\Translator;
use MauticPlugin\SosCustomObjectsBundle\Entity\CustomField;
use MauticPlugin\SosCustomObjectsBundle\Service\CustomFieldService;
use MauticPlugin\SosCustomObjectsBundle\Service\CustomObjectService;
use Symfony\Component\EventDispatcher\EventDispatcherInterface;
use Symfony\Component\HttpFoundation\RequestStack;
use Symfony\Component\HttpFoundation\Response;

final class CustomFieldController extends CommonController
{
    public function __construct(
        ManagerRegistry $doctrine,
        ModelFactory $modelFactory,
        UserHelper $userHelper,
        CoreParametersHelper $coreParametersHelper,
        EventDispatcherInterface $dispatcher,
        Translator $translator,
        FlashBag $flashBag,
        RequestStack $requestStack,
        CorePermissions $security,
        private CustomObjectService $objectService,
        private CustomFieldService $fieldService,
    ) {
        parent::__construct(
            $doctrine,
            $modelFactory,
            $userHelper,
            $coreParametersHelper,
            $dispatcher,
            $translator,
            $flashBag,
            $requestStack,
            $security
        );
    }

    public function listAction(int $objectId): Response
    {
        $object = $this->objectService->get($objectId);
        if (!$object) {
            return $this->notFound('Custom Object não encontrado.');
        }

        return $this->delegateView([
            'viewParameters' => [
                'object' => $object,
                'items'  => $this->fieldService->list($object),
            ],
            'contentTemplate' => '@SosCustomObjectsBundle/CustomField/list.html.twig',
            'passthroughVars' => [
                'mauticContent' => 'sosCustomFields',
                'route'         => $this->generateUrl('sos_custom_fields_list', ['objectId' => $objectId]),
            ],
        ]);
    }

    public function newAction(int $objectId): Response
    {
        $request = $this->getCurrentRequest();
        $object = $this->objectService->get($objectId);
        if (!$object) {
            return $this->notFound('Custom Object não encontrado.');
        }

        if ($request->isMethod('POST')) {
            $label = InputHelper::clean($request->request->get('label', ''));
            $alias = InputHelper::clean($request->request->get('alias', ''));
            $type  = InputHelper::clean($request->request->get('type', CustomField::TYPE_TEXT));
            $isRequired = (bool) $request->request->get('isRequired', false);

            $optionsRaw = (string) $request->request->get('options', '');
            $options = null;
            if (trim($optionsRaw) !== '') {
                $options = array_values(array_filter(array_map('trim', preg_split('/\r?\n/', $optionsRaw))));
            }

            try {
                $this->fieldService->create($object, $label, $alias, $type, $isRequired, $options);
                $this->addFlashMessage('Campo criado com sucesso.');
                return $this->redirectToRoute('sos_custom_fields_list', ['objectId' => $objectId]);
            } catch (\Throwable $e) {
                $this->addFlashMessage('Erro: '.$e->getMessage(), [], FlashBag::LEVEL_ERROR);
            }
        }

        return $this->delegateView([
            'viewParameters' => [
                'mode'   => 'new',
                'object' => $object,
                'item'   => null,
            ],
            'contentTemplate' => '@SosCustomObjectsBundle/CustomField/form.html.twig',
            'passthroughVars' => [
                'mauticContent' => 'sosCustomFields',
                'route'         => $this->generateUrl('sos_custom_fields_new', ['objectId' => $objectId]),
            ],
        ]);
    }

    public function editAction(int $objectId, int $id): Response
    {
        $request = $this->getCurrentRequest();
        $object = $this->objectService->get($objectId);
        if (!$object) {
            return $this->notFound('Custom Object não encontrado.');
        }

        $field = $this->fieldService->get($id);
        if (!$field || $field->getObject()->getId() !== $objectId) {
            return $this->notFound('Campo não encontrado.');
        }

        if ($request->isMethod('POST')) {
            $label = InputHelper::clean($request->request->get('label', ''));
            $alias = InputHelper::clean($request->request->get('alias', ''));
            $type  = InputHelper::clean($request->request->get('type', CustomField::TYPE_TEXT));
            $isRequired = (bool) $request->request->get('isRequired', false);

            $optionsRaw = (string) $request->request->get('options', '');
            $options = null;
            if (trim($optionsRaw) !== '') {
                $options = array_values(array_filter(array_map('trim', preg_split('/\r?\n/', $optionsRaw))));
            }

            try {
                $this->fieldService->update($field, $label, $alias, $type, $isRequired, $options);
                $this->addFlashMessage('Campo atualizado com sucesso.');
                return $this->redirectToRoute('sos_custom_fields_list', ['objectId' => $objectId]);
            } catch (\Throwable $e) {
                $this->addFlashMessage('Erro: '.$e->getMessage(), [], FlashBag::LEVEL_ERROR);
            }
        }

        return $this->delegateView([
            'viewParameters' => [
                'mode'   => 'edit',
                'object' => $object,
                'item'   => $field,
            ],
            'contentTemplate' => '@SosCustomObjectsBundle/CustomField/form.html.twig',
            'passthroughVars' => [
                'mauticContent' => 'sosCustomFields',
                'route'         => $this->generateUrl('sos_custom_fields_edit', ['objectId' => $objectId, 'id' => $id]),
            ],
        ]);
    }

    public function deleteAction(int $objectId, int $id): Response
    {
        $request = $this->getCurrentRequest();
        if (!$request->isMethod('POST')) {
            return $this->accessDenied();
        }

        $object = $this->objectService->get($objectId);
        if (!$object) {
            return $this->notFound('Custom Object não encontrado.');
        }

        $field = $this->fieldService->get($id);
        if (!$field || $field->getObject()->getId() !== $objectId) {
            return $this->notFound('Campo não encontrado.');
        }

        $this->fieldService->delete($field);
        $this->addFlashMessage('Campo removido.');
        return $this->redirectToRoute('sos_custom_fields_list', ['objectId' => $objectId]);
    }
}
