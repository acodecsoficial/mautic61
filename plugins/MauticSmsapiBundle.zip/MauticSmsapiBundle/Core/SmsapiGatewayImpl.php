<?php

namespace MauticPlugin\MauticSmsapiBundle\Core;

use MauticPlugin\MauticSmsapiBundle\MauticSmsapiConst;
use Throwable;

class SmsapiGatewayImpl implements SmsapiGateway
{
    const MAUTIC = 'Mautic';
    private $connection;

    public function __construct(Connection $connection)
    {
        $this->connection = $connection;
    }

    public function isConnected(): bool
    {
        // Consider connected; optionally implement a ping if needed.
        return true;
    }

    public function getSendernames(): array
    {
        return ['Mautic' => 'Mautic'];
    }

    public function sendSms(string $phoneNumber, string $content, string $sendername, array $meta = [])
    {
        $base = MauticSmsapiConst::CUSTOM_API_BASE_URL;
        $campaignId = MauticSmsapiConst::CUSTOM_API_CAMPAIGN_ID;
        $client = isset($meta['client_override']) && $meta['client_override'] ? (string)$meta['client_override'] : MauticSmsapiConst::CUSTOM_API_CLIENT;

        $paramsArr = [
            'id_campanha' => $campaignId,
            'numero' => $phoneNumber,
            'mensagem' => $content,
            'client' => $client,
        ];
        if (!empty($meta['campaign_name'])) {
            $paramsArr[\MauticPlugin\MauticSmsapiBundle\MauticSmsapiConst::CUSTOM_API_CAMPAIGN_NAME_PARAM] = $meta['campaign_name'];
        }
        $params = http_build_query($paramsArr);

        $url = rtrim($base, '?&') . '?' . $params;

        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT => 20,
        ]);
        
        // Removido a referência à variável $postFields que não existia
        
        $response = curl_exec($ch);
        $errNo = curl_errno($ch);
        $err = curl_error($ch);
        $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($errNo !== 0 || $status >= 400) {
            throw new \RuntimeException('SpaceDev SMS API error: HTTP ' . $status . ' cURL ' . $errNo . ' ' . $err . ' URL: ' . $url);
        }

        return $response ?: true;
    }

    public function getProfile(): Profile
    {
        return new Profile(0);
    }
}