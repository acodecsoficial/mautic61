<?php

namespace MauticPlugin\MauticSmsapiBundle\Api;

use Doctrine\ORM\EntityManagerInterface;
use Mautic\LeadBundle\Entity\Lead;
use Mautic\SmsBundle\Sms\TransportInterface;
use MauticPlugin\MauticSmsapiBundle\Core\SmsapiGateway;
use MauticPlugin\MauticSmsapiBundle\Core\SmsapiPluginInterface;
use MauticPlugin\MauticSmsapiBundle\MauticSmsapiConst;
use Monolog\Logger;

class SmsapiApi implements TransportInterface
{
    private $logger;
    private $smsApiGateway;
    private $smsApiPlugin;
    private $em;

    public function __construct(
        Logger $logger,
        SmsapiGateway $smsApiGateway,
        SmsapiPluginInterface $smsApiPlugin,
        EntityManagerInterface $em
    ) {
        $this->logger = $logger;
        $this->smsApiGateway = $smsApiGateway;
        $this->smsApiPlugin = $smsApiPlugin;
        $this->em = $em;
    }

    public function sendSms(Lead $lead, $content)
    {
        $phoneNumber = $lead->getLeadPhoneNumber();
        if (!$phoneNumber) {
            return 'Contact without phone number';
        }

        $campaign = $this->guessRecentCampaignInfoForLead($lead);
        $campaignName = $campaign['name'] ?? null;
        $campaignIdMeta = $campaign['id'] ?? null;

        if ($campaignName && MauticSmsapiConst::CUSTOM_DEBUG_APPEND_CAMPAIGN_TO_MESSAGE) {
            $content = sprintf('[Campanha: %s] %s', $campaignName, (string)$content);
        }

        
        $content = (string) $content;
        $content = $this->resolveMauticRedirectsInText($content);
        

        $meta = [];
        if (!empty($campaignIdMeta)) {
            $meta['campaign_id'] = (string)$campaignIdMeta;
        }
        if (!empty($campaignName)) {
            $meta['campaign_name'] = $campaignName;
        }

        $sendername = method_exists($this->smsApiPlugin, 'getSendername')
            ? (string)$this->smsApiPlugin->getSendername()
            : 'Mautic';

        
        $clientName = $this->getCompanySmsClient($lead);

        
        if (empty($clientName)) {
            $clientName = method_exists($this->smsApiPlugin, 'getClient')
                ? (string)$this->smsApiPlugin->getClient()
                : '';
        }

        
        if (!empty($clientName)) {
            $meta['client_override'] = $clientName;
        }

        try {
            $this->smsApiGateway->sendSms($phoneNumber, (string)$content, $sendername, $meta);
            $this->logger->notice('Send SMS to ' . $lead->getName() . ' on number ' . $phoneNumber . ' (campanha=' . ($campaignName ?: '-') . ', id=' . ($campaignIdMeta ?: '-') . ')');
        } catch (\Throwable $e) {
            $this->logger->error('Send SMS failed for ' . $lead->getName() . ': ' . $e->getMessage());
            return $e->getMessage();
        }

        return true;
    }

    private function guessRecentCampaignInfoForLead(Lead $lead): ?array
    {
        try {
            $qb = $this->em->createQueryBuilder();
            $qb->select('c.id AS cid, c.name AS cname')
               ->from('MauticCampaignBundle:LeadEventLog', 'l')
               ->join('l.event', 'e')
               ->join('e.campaign', 'c')
               ->where('l.lead = :lead')
               ->orderBy('l.dateTriggered', 'DESC')
               ->setMaxResults(1)
               ->setParameter('lead', $lead->getId());
            $row = $qb->getQuery()->getOneOrNullResult();
            if ($row && (isset($row['cid']) || isset($row['cname']))) {
                return ['id' => $row['cid'] ?? null, 'name' => $row['cname'] ?? null];
            }
        } catch (\Throwable $e) {
            
        }
        return null;
    }

    
    private function getCompanySmsClient(Lead $lead): string
    {
        try {
            $conn = $this->em->getConnection();
            $row  = $conn->fetchAssociative(
                'SELECT c.sms_client_name
                 FROM companies c
                 INNER JOIN companies_leads cl ON cl.company_id = c.id
                 WHERE cl.lead_id = ? AND cl.is_primary = 1
                 LIMIT 1',
                [$lead->getId()]
            );

            return (string) ($row['sms_client_name'] ?? '');
        } catch (\Throwable $e) {
            return '';
        }
    }

    private function resolveMauticRedirectsInText(string $text): string
    {
        
        $pattern = '#https?://[^/\s]+/r/[^?\s]+(?:\?[^ \r\n]+)?#i';

        return preg_replace_callback($pattern, function ($m) {
            $trackedUrl = $m[0];

            // Preferência: cURL
            if (function_exists('curl_init')) {
                $ch = curl_init($trackedUrl);
                curl_setopt_array($ch, [
                    CURLOPT_NOBODY         => true,   // HEAD
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_MAXREDIRS      => 5,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_TIMEOUT        => 6,
                    CURLOPT_USERAGENT      => 'MauticSMS/1.0',
                ]);
                curl_exec($ch);
                $final = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
                $http  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                curl_close($ch);

                if (is_string($final) && preg_match('#^https?://#i', $final) && $http >= 200) {
                    return $final;
                }

                
                return $trackedUrl;
            }

            
            $opts = [
                'http' => [
                    'method'  => 'HEAD',
                    'timeout' => 6,
                    'ignore_errors' => true,
                    'follow_location' => 1, 
                    'header'  => "User-Agent: MauticSMS/1.0\r\n",
                ],
            ];
            $context = stream_context_create($opts);
            @file_get_contents($trackedUrl, false, $context);

            // procura cabeçalho Location
            if (!empty($http_response_header)) {
                foreach ($http_response_header as $h) {
                    if (stripos($h, 'Location:') === 0) {
                        $final = trim(substr($h, 9));
                        if (preg_match('#^https?://#i', $final)) {
                            return $final;
                        }
                    }
                }
            }

            return $trackedUrl;
        }, $text);
    }
}
