<?php

declare(strict_types=1);

namespace MauticPlugin\SosCustomObjectsBundle\Segment\Query\Filter;

use Doctrine\DBAL\Query\Expression\CompositeExpression;
use Doctrine\DBAL\Exception as DbalException;
use Mautic\LeadBundle\Segment\ContactSegmentFilter;
use Mautic\LeadBundle\Segment\Query\Filter\BaseFilterQueryBuilder;
use Mautic\LeadBundle\Segment\Query\QueryBuilder;
use MauticPlugin\SosCustomObjectsBundle\Entity\CustomField;
use MauticPlugin\SosCustomObjectsBundle\Repository\CustomFieldRepository;
use Symfony\Component\HttpFoundation\Response;

final class CustomFieldFilterQueryBuilder extends BaseFilterQueryBuilder
{
    /** @var array<string, string>|null */
    private ?array $valueTableColumns = null;

    public function __construct(
        \Mautic\LeadBundle\Segment\RandomParameterName $parameterNameGenerator,
        \Symfony\Component\EventDispatcher\EventDispatcherInterface $dispatcher,
        private CustomFieldRepository $customFieldRepository,
    ) {
        parent::__construct($parameterNameGenerator, $dispatcher);
    }

    public static function getServiceId(): string
    {
        return 'sos_custom_objects.segment.query_builder.custom_field';
    }

    public function applyQuery(QueryBuilder $queryBuilder, ContactSegmentFilter $filter): QueryBuilder
    {
        $sourceField = (string) ($filter->contactSegmentFilterCrate->getArray()['field'] ?? '');
        $customFieldId = $this->extractCustomFieldId($sourceField);
        if (null === $customFieldId) {
            // If this isn't one of our filters, do nothing.
            return $queryBuilder;
        }

        $customField = $this->customFieldRepository->find($customFieldId);
        if (!$customField) {
            throw new \InvalidArgumentException('Custom field not found.', Response::HTTP_BAD_REQUEST);
        }

        if (!$this->tablesReady()) {
            // Plugin tables not migrated yet; don't break segmentation UI.
            return $queryBuilder;
        }

        $valueColumn = $this->getValueColumnForField($customField);

        $leadsTableAlias = $queryBuilder->getTableAlias(MAUTIC_TABLE_PREFIX.'leads');
        if (!$leadsTableAlias) {
            $leadsTableAlias = 'l';
        }

        $filterOperator = (string) $filter->getOperator();
        $filterParameters = $filter->getParameterValue();

        if (is_array($filterParameters)) {
            $parameters = [];
            foreach ($filterParameters as $_) {
                $parameters[] = $this->generateRandomParameterName();
            }
        } else {
            $parameters = $this->generateRandomParameterName();
        }

        $filterParametersHolder = $filter->getParameterHolder($parameters);

        $c = $this->generateRandomParameterName();
        $i = $this->generateRandomParameterName();
        $v = $this->generateRandomParameterName();

        $linkTable  = MAUTIC_TABLE_PREFIX.'sos_custom_item_contact';
        $itemTable  = MAUTIC_TABLE_PREFIX.'sos_custom_item';
        $valueTable = MAUTIC_TABLE_PREFIX.'sos_custom_item_value';

        $objectId = $customField->getObject()->getId();

        $baseSubQuery = static function (QueryBuilder $subQueryBuilder) use (
            $linkTable,
            $itemTable,
            $valueTable,
            $c,
            $i,
            $v,
            $customFieldId,
            $objectId
        ): QueryBuilder {
            $subQueryBuilder
                ->from($linkTable, $c)
                ->innerJoin($c, $itemTable, $i, $i.'.id = '.$c.'.custom_item_id');

            if (null !== $objectId) {
                $subQueryBuilder->andWhere($i.'.custom_object_id = '.(int) $objectId);
            }

            // Use LEFT JOIN so "empty" can include contacts with linked items but missing value row.
            $subQueryBuilder
                ->leftJoin(
                    $i,
                    $valueTable,
                    $v,
                    $v.'.custom_item_id = '.$i.'.id AND '.$v.'.custom_field_id = '.(int) $customFieldId
                );

            return $subQueryBuilder;
        };

        $subQueryBuilder = $queryBuilder->createQueryBuilder();
        $baseSubQuery($subQueryBuilder);

        $contactIdExpr = $c.'.contact_id';
        $valueExpr     = $v.'.'.$valueColumn;

        switch ($filterOperator) {
            case 'empty':
                // Contacts without any matching value row (or only NULL/empty values).
                $subQueryBuilder->select($contactIdExpr);
                $subQueryBuilder->andWhere($this->notEmptyExpression($subQueryBuilder, $valueExpr, $customField));
                $queryBuilder->addLogic($queryBuilder->expr()->notIn($leadsTableAlias.'.id', $subQueryBuilder->getSQL()), $filter->getGlue());
                break;

            case 'notEmpty':
                $subQueryBuilder->select($contactIdExpr);
                $subQueryBuilder->andWhere($this->notEmptyExpression($subQueryBuilder, $valueExpr, $customField));
                $queryBuilder->addLogic($queryBuilder->expr()->in($leadsTableAlias.'.id', $subQueryBuilder->getSQL()), $filter->getGlue());
                break;

            case 'notIn':
                // NOT EXISTS match
                $exists = $queryBuilder->createQueryBuilder();
                $baseSubQuery($exists);
                $exists->select('NULL')->andWhere($contactIdExpr.' = '.$leadsTableAlias.'.id');

                $expr = $exists->expr()->in($valueExpr, $filterParametersHolder);
                $exists->andWhere($this->andNotEmptyExpression($exists, $valueExpr, $customField, $expr));
                $queryBuilder->addLogic($queryBuilder->expr()->notExists($exists->getSQL()), $filter->getGlue());
                break;

            case 'neq':
                $exists = $queryBuilder->createQueryBuilder();
                $baseSubQuery($exists);
                $exists->select('NULL')->andWhere($contactIdExpr.' = '.$leadsTableAlias.'.id');

                $expr = $exists->expr()->eq($valueExpr, $filterParametersHolder);
                $exists->andWhere($this->andNotEmptyExpression($exists, $valueExpr, $customField, $expr));
                $queryBuilder->addLogic($queryBuilder->expr()->notExists($exists->getSQL()), $filter->getGlue());
                break;

            case 'notLike':
                $exists = $queryBuilder->createQueryBuilder();
                $baseSubQuery($exists);
                $exists->select('NULL')->andWhere($contactIdExpr.' = '.$leadsTableAlias.'.id');

                $expr = $exists->expr()->like($valueExpr, $filterParametersHolder);
                $exists->andWhere($this->andNotEmptyExpression($exists, $valueExpr, $customField, $expr));
                $queryBuilder->addLogic($queryBuilder->expr()->notExists($exists->getSQL()), $filter->getGlue());
                break;

            case 'regexp':
            case 'notRegexp':
                $subQueryBuilder->select($contactIdExpr);
                $not = ('notRegexp' === $filterOperator) ? ' NOT' : '';
                $expression = $valueExpr.$not.' REGEXP '.$filterParametersHolder;
                $subQueryBuilder->andWhere($this->andNotEmptyExpression($subQueryBuilder, $valueExpr, $customField, $expression));
                $queryBuilder->addLogic($queryBuilder->expr()->in($leadsTableAlias.'.id', $subQueryBuilder->getSQL()), $filter->getGlue());
                break;

            default:
                // eq, like, gt, gte, lt, lte, in, etc.
                $subQueryBuilder->select($contactIdExpr);
                $expr = $subQueryBuilder->expr()->$filterOperator($valueExpr, $filterParametersHolder);
                $subQueryBuilder->andWhere($this->andNotEmptyExpression($subQueryBuilder, $valueExpr, $customField, $expr));
                $queryBuilder->addLogic($queryBuilder->expr()->in($leadsTableAlias.'.id', $subQueryBuilder->getSQL()), $filter->getGlue());
        }

        $queryBuilder->setParametersPairs($parameters, $filterParameters);

        return $queryBuilder;
    }

    private function tablesReady(): bool
    {
        try {
            // QueryBuilder extends DBAL QueryBuilder and holds a connection.
            $em = $this->customFieldRepository->getEntityManager();
            $conn = $em->getConnection();
            $params = $conn->getParams();
            $prefix = (string) ($params['table_prefix'] ?? '');
            $schema = $conn->createSchemaManager();

            return $schema->tablesExist([
                $prefix.'sos_custom_item_contact',
                $prefix.'sos_custom_item',
                $prefix.'sos_custom_item_value',
                $prefix.'sos_custom_object',
                $prefix.'sos_custom_field',
            ]);
        } catch (DbalException|\Throwable) {
            return false;
        }
    }

    private function extractCustomFieldId(string $sourceField): ?int
    {
        if (1 !== preg_match('/^sos_cmf_(\\d+)$/', $sourceField, $m)) {
            return null;
        }

        return (int) $m[1];
    }

    private function getValueColumnForField(CustomField $field): string
    {
        // Backward compatibility: some installs might have only a legacy `value` column.
        return match ($field->getType()) {
            CustomField::TYPE_NUMBER => $this->pickExistingValueColumn(['value_number', 'valueNumber', 'value_text', 'valueText', 'value']),
            CustomField::TYPE_DATE => $this->pickExistingValueColumn(['value_date', 'valueDate', 'value_text', 'valueText', 'value']),
            CustomField::TYPE_BOOL => $this->pickExistingValueColumn(['value_bool', 'valueBool', 'value_text', 'valueText', 'value']),
            default => $this->pickExistingValueColumn(['value_text', 'valueText', 'value']),
        };
    }

    /**
     * @param string[] $candidates
     */
    private function pickExistingValueColumn(array $candidates): string
    {
        $cols = $this->getValueTableColumns();
        foreach ($candidates as $col) {
            $key = strtolower($col);
            if (isset($cols[$key])) {
                return $cols[$key];
            }
        }

        // Default to value_text for forward schema.
        return 'valueText';
    }

    /**
     * @return array<string, bool>
     */
    private function getValueTableColumns(): array
    {
        if (null !== $this->valueTableColumns) {
            return $this->valueTableColumns;
        }

        $this->valueTableColumns = [];

        try {
            $em     = $this->customFieldRepository->getEntityManager();
            $conn   = $em->getConnection();
            $params = $conn->getParams();
            $prefix = (string) ($params['table_prefix'] ?? '');
            $schema = $conn->createSchemaManager();

            foreach ($schema->listTableColumns($prefix.'sos_custom_item_value') as $name => $_col) {
                $this->valueTableColumns[strtolower((string) $name)] = (string) $name;
            }
        } catch (DbalException|\Throwable) {
            $this->valueTableColumns = [];
        }

        return $this->valueTableColumns;
    }

    private function notEmptyExpression(QueryBuilder $qb, string $valueExpr, CustomField $field): string|CompositeExpression
    {
        if ($field->getType() === CustomField::TYPE_TEXT || $field->getType() === CustomField::TYPE_SELECT) {
            return $qb->expr()->and(
                $qb->expr()->isNotNull($valueExpr),
                $qb->expr()->neq($valueExpr, $qb->expr()->literal(''))
            );
        }

        return $qb->expr()->isNotNull($valueExpr);
    }

    private function andNotEmptyExpression(QueryBuilder $qb, string $valueExpr, CustomField $field, string|CompositeExpression $expr): CompositeExpression
    {
        return $qb->expr()->and(
            $this->notEmptyExpression($qb, $valueExpr, $field),
            $expr
        );
    }
}
