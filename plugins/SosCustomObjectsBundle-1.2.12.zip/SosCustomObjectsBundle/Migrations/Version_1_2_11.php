<?php

declare(strict_types=1);

namespace MauticPlugin\SosCustomObjectsBundle\Migrations;

use Doctrine\DBAL\Schema\Schema;
use Mautic\IntegrationsBundle\Migration\AbstractMigration;

final class Version_1_2_11 extends AbstractMigration
{
    protected function isApplicable(Schema $schema): bool
    {
        $itemTable = $this->concatPrefix('sos_custom_item');
        $linkTable = $this->concatPrefix('sos_custom_item_contact');

        return $schema->hasTable($itemTable) && !$schema->hasTable($linkTable);
    }

    protected function up(): void
    {
        $itemTable = $this->concatPrefix('sos_custom_item');
        $linkTable = $this->concatPrefix('sos_custom_item_contact');

        $this->addSql("
            CREATE TABLE IF NOT EXISTS `$linkTable` (
              `custom_item_id` INT NOT NULL,
              `contact_id` INT NOT NULL,
              INDEX `idx_sos_item_contact_item` (`custom_item_id`),
              INDEX `idx_sos_item_contact_contact` (`contact_id`),
              UNIQUE KEY `uniq_sos_item_contact` (`custom_item_id`,`contact_id`),
              CONSTRAINT `fk_sos_item_contact_item` FOREIGN KEY (`custom_item_id`) REFERENCES `$itemTable` (`id`) ON DELETE CASCADE
            ) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB
        ");
    }
}
