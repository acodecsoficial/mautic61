<?php

declare(strict_types=1);

return [
    'name'        => 'SoSystems Custom Objects',
    'description' => 'Custom Objects (Objects + Fields + Items) for Mautic 6 - built from scratch',
    'version'     => '1.2.10',
    'author'      => 'SoSystems Desenvolvimento Web',


'permissions' => [
    'sosCustomObjects' => [
        'customObjects' => [
            'view'   => 1,
            'create' => 2,
            'edit'   => 4,
            'delete' => 8,
        ],
        'customItems' => [
            'view'   => 1,
            'create' => 2,
            'edit'   => 4,
            'delete' => 8,        ],
    ],
],

    'routes' => [
        'main' => [
// Contact -> Custom Items (manage)
'sos_contact_custom_items_manage' => [
    // Avoid route conflicts with core `/contacts/{objectAction}/{objectId}`.
    'path'       => '/sos-custom-items/contact/{leadId}',
    'controller' => MauticPlugin\SosCustomObjectsBundle\Controller\ContactCustomItemController::class.'::manageAction',
    'method'     => 'GET|POST',
    'requirements' => [
        'leadId' => '\\d+',
    ],
],

            // Objects
            'sos_custom_objects_list' => [
                'path'       => '/sos-custom-objects',
                'controller' => MauticPlugin\SosCustomObjectsBundle\Controller\CustomObjectController::class.'::listAction',
                'method'     => 'GET',
            ],
            'sos_custom_objects_new' => [
                'path'       => '/sos-custom-objects/new',
                'controller' => MauticPlugin\SosCustomObjectsBundle\Controller\CustomObjectController::class.'::newAction',
                'method'     => 'GET|POST',
            ],
            'sos_custom_objects_edit' => [
                'path'       => '/sos-custom-objects/edit/{id}',
                'controller' => MauticPlugin\SosCustomObjectsBundle\Controller\CustomObjectController::class.'::editAction',
                'method'     => 'GET|POST',
            ],
            'sos_custom_objects_delete' => [
                'path'       => '/sos-custom-objects/delete/{id}',
                'controller' => MauticPlugin\SosCustomObjectsBundle\Controller\CustomObjectController::class.'::deleteAction',
                'method'     => 'POST',
            ],

            // Fields
            'sos_custom_fields_list' => [
                'path'       => '/sos-custom-objects/{objectId}/fields',
                'controller' => MauticPlugin\SosCustomObjectsBundle\Controller\CustomFieldController::class.'::listAction',
                'method'     => 'GET',
            ],
            'sos_custom_fields_new' => [
                'path'       => '/sos-custom-objects/{objectId}/fields/new',
                'controller' => MauticPlugin\SosCustomObjectsBundle\Controller\CustomFieldController::class.'::newAction',
                'method'     => 'GET|POST',
            ],
            'sos_custom_fields_edit' => [
                'path'       => '/sos-custom-objects/{objectId}/fields/edit/{id}',
                'controller' => MauticPlugin\SosCustomObjectsBundle\Controller\CustomFieldController::class.'::editAction',
                'method'     => 'GET|POST',
            ],
            'sos_custom_fields_delete' => [
                'path'       => '/sos-custom-objects/{objectId}/fields/delete/{id}',
                'controller' => MauticPlugin\SosCustomObjectsBundle\Controller\CustomFieldController::class.'::deleteAction',
                'method'     => 'POST',
            ],

            // Items
            'sos_custom_items_list' => [
                'path'       => '/sos-custom-objects/{objectId}/items',
                'controller' => MauticPlugin\SosCustomObjectsBundle\Controller\CustomItemController::class.'::listAction',
                'method'     => 'GET',
            ],
            'sos_custom_items_new' => [
                'path'       => '/sos-custom-objects/{objectId}/items/new',
                'controller' => MauticPlugin\SosCustomObjectsBundle\Controller\CustomItemController::class.'::newAction',
                'method'     => 'GET|POST',
            ],
            'sos_custom_items_new_for_contact' => [
                'path'       => '/sos-custom-objects/{objectId}/items/new/contact/{contactId}',
                'controller' => MauticPlugin\SosCustomObjectsBundle\Controller\CustomItemController::class.'::newForContactAction',
                'method'     => 'GET|POST',
                'requirements' => [
                    'objectId'  => '\\d+',
                    'contactId' => '\\d+',
                ],
            ],
            'sos_custom_items_edit' => [
                'path'       => '/sos-custom-objects/{objectId}/items/edit/{id}',
                'controller' => MauticPlugin\SosCustomObjectsBundle\Controller\CustomItemController::class.'::editAction',
                'method'     => 'GET|POST',
            ],
            'sos_custom_items_delete' => [
                'path'       => '/sos-custom-objects/{objectId}/items/delete/{id}',
                'controller' => MauticPlugin\SosCustomObjectsBundle\Controller\CustomItemController::class.'::deleteAction',
                'method'     => 'POST',
            ],
        ],
        'api' => [
            // Objects
            'sos_api_custom_objects_list' => [
                'path'       => '/custom-objects',
                'controller' => MauticPlugin\SosCustomObjectsBundle\Controller\Api\CustomObjectApiController::class.'::listAction',
                'method'     => 'GET',
            ],
            'sos_api_custom_objects_get' => [
                'path'       => '/custom-objects/{id}',
                'controller' => MauticPlugin\SosCustomObjectsBundle\Controller\Api\CustomObjectApiController::class.'::getAction',
                'method'     => 'GET',
            ],
            'sos_api_custom_objects_create' => [
                'path'       => '/custom-objects',
                'controller' => MauticPlugin\SosCustomObjectsBundle\Controller\Api\CustomObjectApiController::class.'::createAction',
                'method'     => 'POST',
            ],
            'sos_api_custom_objects_update' => [
                'path'       => '/custom-objects/{id}',
                'controller' => MauticPlugin\SosCustomObjectsBundle\Controller\Api\CustomObjectApiController::class.'::updateAction',
                'method'     => 'PUT|PATCH',
            ],
            'sos_api_custom_objects_delete' => [
                'path'       => '/custom-objects/{id}',
                'controller' => MauticPlugin\SosCustomObjectsBundle\Controller\Api\CustomObjectApiController::class.'::deleteAction',
                'method'     => 'DELETE',
            ],

            // Fields
            'sos_api_custom_fields_list' => [
                'path'       => '/custom-objects/{objectId}/fields',
                'controller' => MauticPlugin\SosCustomObjectsBundle\Controller\Api\CustomFieldApiController::class.'::listAction',
                'method'     => 'GET',
            ],
            'sos_api_custom_fields_create' => [
                'path'       => '/custom-objects/{objectId}/fields',
                'controller' => MauticPlugin\SosCustomObjectsBundle\Controller\Api\CustomFieldApiController::class.'::createAction',
                'method'     => 'POST',
            ],
            'sos_api_custom_fields_update' => [
                'path'       => '/custom-objects/{objectId}/fields/{id}',
                'controller' => MauticPlugin\SosCustomObjectsBundle\Controller\Api\CustomFieldApiController::class.'::updateAction',
                'method'     => 'PUT|PATCH',
            ],
            'sos_api_custom_fields_delete' => [
                'path'       => '/custom-objects/{objectId}/fields/{id}',
                'controller' => MauticPlugin\SosCustomObjectsBundle\Controller\Api\CustomFieldApiController::class.'::deleteAction',
                'method'     => 'DELETE',
            ],

            // Items
            'sos_api_custom_items_list' => [
                'path'       => '/custom-objects/{objectId}/items',
                'controller' => MauticPlugin\SosCustomObjectsBundle\Controller\Api\CustomItemApiController::class.'::listAction',
                'method'     => 'GET',
            ],
            'sos_api_custom_items_get' => [
                'path'       => '/custom-objects/{objectId}/items/{id}',
                'controller' => MauticPlugin\SosCustomObjectsBundle\Controller\Api\CustomItemApiController::class.'::getAction',
                'method'     => 'GET',
            ],
            'sos_api_custom_items_create' => [
                'path'       => '/custom-objects/{objectId}/items',
                'controller' => MauticPlugin\SosCustomObjectsBundle\Controller\Api\CustomItemApiController::class.'::createAction',
                'method'     => 'POST',
            ],
            'sos_api_custom_items_update' => [
                'path'       => '/custom-objects/{objectId}/items/{id}',
                'controller' => MauticPlugin\SosCustomObjectsBundle\Controller\Api\CustomItemApiController::class.'::updateAction',
                'method'     => 'PUT|PATCH',
            ],
            'sos_api_custom_items_delete' => [
                'path'       => '/custom-objects/{objectId}/items/{id}',
                'controller' => MauticPlugin\SosCustomObjectsBundle\Controller\Api\CustomItemApiController::class.'::deleteAction',
                'method'     => 'DELETE',
            ],

            // Link items to contacts
            'sos_api_custom_items_link_contact' => [
                'path'       => '/custom-objects/{objectId}/items/{id}/link-contact/{contactId}',
                'controller' => MauticPlugin\SosCustomObjectsBundle\Controller\Api\CustomItemApiController::class.'::linkContactAction',
                'method'     => 'POST',
            ],
            'sos_api_custom_items_unlink_contact' => [
                'path'       => '/custom-objects/{objectId}/items/{id}/unlink-contact/{contactId}',
                'controller' => MauticPlugin\SosCustomObjectsBundle\Controller\Api\CustomItemApiController::class.'::unlinkContactAction',
                'method'     => 'POST',
            ],
        ],
    ],
];
