<?php

declare(strict_types=1);

namespace MauticPlugin\SosCustomObjectsBundle\EventListener;

use Mautic\LeadBundle\Event\LeadListFiltersChoicesEvent;
use Mautic\LeadBundle\LeadEvents;
use Mautic\LeadBundle\Provider\TypeOperatorProviderInterface;
use MauticPlugin\SosCustomObjectsBundle\Entity\CustomField;
use MauticPlugin\SosCustomObjectsBundle\Repository\CustomFieldRepository;
use MauticPlugin\SosCustomObjectsBundle\Repository\CustomObjectRepository;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

final class SegmentFiltersChoicesGenerateSubscriber implements EventSubscriberInterface
{
    public function __construct(
        private CustomObjectRepository $customObjectRepository,
        private CustomFieldRepository $customFieldRepository,
        private TypeOperatorProviderInterface $typeOperatorProvider,
    ) {
    }

    public static function getSubscribedEvents(): array
    {
        return [LeadEvents::LIST_FILTERS_CHOICES_ON_GENERATE => 'onGenerateSegmentFilters'];
    }

    public function onGenerateSegmentFilters(LeadListFiltersChoicesEvent $event): void
    {
        // Keep the same group for segments/dynamic content/etc.
        $group = 'sos_custom_objects';

        foreach ($this->customObjectRepository->findAllOrdered() as $customObject) {
            foreach ($this->customFieldRepository->findByObject($customObject) as $customField) {
                $fieldId = $customField->getId();
                if (null === $fieldId) {
                    continue;
                }

                $event->addChoice(
                    $group,
                    'sos_cmf_'.$fieldId,
                    [
                        'label'      => $customObject->getName().' : '.$customField->getLabel(),
                        'properties' => $this->getFieldProperties($customField),
                        'operators'  => $this->typeOperatorProvider->getOperatorsForFieldType($this->mapTypeForOperators($customField)),
                        'object'     => $group,
                    ]
                );
            }
        }
    }

    /**
     * @return array<string, mixed>
     */
    private function getFieldProperties(CustomField $customField): array
    {
        $type = $customField->getType();

        $properties = [
            'type' => match ($type) {
                CustomField::TYPE_BOOL => 'boolean',
                default => $type,
            },
        ];

        if ($type === CustomField::TYPE_SELECT) {
            $list = [];
            foreach (($customField->getOptions() ?: []) as $opt) {
                if (!is_string($opt) || $opt === '') {
                    continue;
                }
                $list[$opt] = $opt;
            }
            $properties['list'] = $list;
        }

        if ($type === CustomField::TYPE_BOOL) {
            $properties['list'] = [
                'No'  => 0,
                'Yes' => 1,
            ];
        }

        return $properties;
    }

    private function mapTypeForOperators(CustomField $customField): string
    {
        return match ($customField->getType()) {
            CustomField::TYPE_BOOL => 'bool',
            default => $customField->getType(),
        };
    }
}

