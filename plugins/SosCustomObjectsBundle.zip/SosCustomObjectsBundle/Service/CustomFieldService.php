<?php

declare(strict_types=1);

namespace MauticPlugin\SosCustomObjectsBundle\Service;

use Doctrine\ORM\EntityManagerInterface;
use MauticPlugin\SosCustomObjectsBundle\Entity\CustomField;
use MauticPlugin\SosCustomObjectsBundle\Entity\CustomObject;
use MauticPlugin\SosCustomObjectsBundle\Repository\CustomFieldRepository;

final class CustomFieldService
{
    public function __construct(
        private EntityManagerInterface $em,
        private CustomFieldRepository $repo,
    ) {}

    /** @return CustomField[] */
    public function list(CustomObject $object): array
    {
        return $this->repo->findByObject($object);
    }

    public function get(int $id): ?CustomField
    {
        return $this->repo->find($id);
    }

    public function create(CustomObject $object, string $label, string $alias, string $type, bool $isRequired, ?array $options): CustomField
    {
        $alias = trim($alias);
        if ($alias === '') {
            throw new \InvalidArgumentException('Alias é obrigatório.');
        }

        $existing = $this->repo->findOneByObjectAndAlias($object, $alias);
        if ($existing) {
            throw new \InvalidArgumentException('Alias já existe neste objeto: '.$alias);
        }

        $f = new CustomField($object);
        $f->setLabel(trim($label) ?: $alias);
        $f->setAlias($alias);
        $f->setType($this->normalizeType($type));
        $f->setIsRequired($isRequired);
        $f->setOptions($f->getType() === CustomField::TYPE_SELECT ? ($options ?: []) : null);

        $this->em->persist($f);
        $this->em->flush();

        return $f;
    }

    public function update(CustomField $f, string $label, string $alias, string $type, bool $isRequired, ?array $options): CustomField
    {
        $alias = trim($alias);
        if ($alias === '') {
            throw new \InvalidArgumentException('Alias é obrigatório.');
        }

        $object = $f->getObject();
        $existing = $this->repo->findOneByObjectAndAlias($object, $alias);
        if ($existing && $existing->getId() !== $f->getId()) {
            throw new \InvalidArgumentException('Alias já existe neste objeto: '.$alias);
        }

        $f->setLabel(trim($label) ?: $alias);
        $f->setAlias($alias);
        $f->setType($this->normalizeType($type));
        $f->setIsRequired($isRequired);
        $f->setOptions($f->getType() === CustomField::TYPE_SELECT ? ($options ?: []) : null);
        $f->touch();

        $this->em->flush();

        return $f;
    }

    public function delete(CustomField $f): void
    {
        $this->em->remove($f);
        $this->em->flush();
    }

    private function normalizeType(string $type): string
    {
        $type = strtolower(trim($type));
        return match ($type) {
            CustomField::TYPE_NUMBER,
            CustomField::TYPE_DATE,
            CustomField::TYPE_BOOL,
            CustomField::TYPE_SELECT,
            CustomField::TYPE_TEXT => $type,
            default => CustomField::TYPE_TEXT,
        };
    }
}
