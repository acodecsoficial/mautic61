<?php

$view->extend('MauticCoreBundle:Default:content.html.php');

$object = $view['data']->get('object');
$items  = $view['data']->get('items', []);
$pagination = $view['data']->get('pagination', []);

$view['slots']->set('headerTitle', 'Campos - '.$view->escape($object->getName()));
?>

<div class="box-layout">
  <div class="col-md-12">
    <div class="toolbar mb-md">
      <a class="btn btn-default" href="<?php echo $view['router']->path('sos_custom_objects_list'); ?>">
        <i class="fa fa-arrow-left"></i> Voltar
      </a>
      <a class="btn btn-primary" href="<?php echo $view['router']->path('sos_custom_fields_new', ['objectId' => $object->getId()]); ?>">
        <i class="fa fa-plus"></i> Novo Campo
      </a>
      <a class="btn btn-default" href="<?php echo $view['router']->path('sos_custom_items_list', ['objectId' => $object->getId()]); ?>">
        <i class="fa fa-database"></i> Itens
      </a>
    </div>

    <div class="panel panel-default">
      <div class="panel-heading"><h4 class="panel-title">Campos</h4></div>
      <div class="panel-body">
        <?php if (!$items): ?>
          <p>Nenhum campo cadastrado ainda.</p>
        <?php else: ?>
          <div class="table-responsive">
          <table class="table table-hover table-striped">
            <thead>
              <tr>
                <th>ID</th>
                <th>Label</th>
                <th>Alias</th>
                <th>Tipo</th>
                <th>Obrigatório</th>
                <th style="width: 220px;">Ações</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($items as $f): ?>
                <tr>
                  <td><?php echo (int) $f->getId(); ?></td>
                  <td><?php echo $view->escape($f->getLabel()); ?></td>
                  <td><code><?php echo $view->escape($f->getAlias()); ?></code></td>
                  <td><?php echo $view->escape($f->getType()); ?></td>
                  <td><?php echo $f->isRequired() ? 'Sim' : 'Não'; ?></td>
                  <td>
                    <a class="btn btn-default btn-sm" href="<?php echo $view['router']->path('sos_custom_fields_edit', ['objectId' => $object->getId(), 'id' => $f->getId()]); ?>">
                      <i class="fa fa-pencil"></i> Editar
                    </a>
                    <form method="post" action="<?php echo $view['router']->path('sos_custom_fields_delete', ['objectId' => $object->getId(), 'id' => $f->getId()]); ?>" style="display:inline;">
                      <button class="btn btn-danger btn-sm" onclick="return confirm('Remover este campo?');">
                        <i class="fa fa-trash"></i> Remover
                      </button>
                    </form>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
          </div>
        <?php endif; ?>
        <?php if (!empty($pagination) && $pagination['totalItems'] > 0): ?>
          <div class="row">
            <div class="col-sm-6"><p class="text-muted">Exibindo <?php echo (int) $pagination['firstItem']; ?> a <?php echo (int) $pagination['lastItem']; ?> de <?php echo (int) $pagination['totalItems']; ?> registros</p></div>
            <?php if ($pagination['totalPages'] > 1): ?>
              <div class="col-sm-6 text-right"><nav aria-label="Paginacao"><ul class="pagination pagination-sm">
                <?php $previousPage = $pagination['currentPage'] - 1; ?>
                <li class="<?php echo $pagination['currentPage'] <= 1 ? 'disabled' : ''; ?>"><?php if ($pagination['currentPage'] > 1): ?><a href="<?php echo $view['router']->path('sos_custom_fields_list', ['objectId' => $object->getId(), 'page' => $previousPage]); ?>">Anterior</a><?php else: ?><span>Anterior</span><?php endif; ?></li>
                <?php foreach ($pagination['pages'] as $pageNumber): ?>
                  <li class="<?php echo $pageNumber === $pagination['currentPage'] ? 'active' : ''; ?>"><?php if ($pageNumber === $pagination['currentPage']): ?><span aria-current="page"><?php echo (int) $pageNumber; ?></span><?php else: ?><a href="<?php echo $view['router']->path('sos_custom_fields_list', ['objectId' => $object->getId(), 'page' => $pageNumber]); ?>"><?php echo (int) $pageNumber; ?></a><?php endif; ?></li>
                <?php endforeach; ?>
                <?php $nextPage = $pagination['currentPage'] + 1; ?>
                <li class="<?php echo $pagination['currentPage'] >= $pagination['totalPages'] ? 'disabled' : ''; ?>"><?php if ($pagination['currentPage'] < $pagination['totalPages']): ?><a href="<?php echo $view['router']->path('sos_custom_fields_list', ['objectId' => $object->getId(), 'page' => $nextPage]); ?>">Proxima</a><?php else: ?><span>Proxima</span><?php endif; ?></li>
              </ul></nav></div>
            <?php endif; ?>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>
