<?php

declare(strict_types=1);

namespace MauticPlugin\SosCustomObjectsBundle\EventListener;

use Mautic\CampaignBundle\CampaignEvents;
use Mautic\CampaignBundle\Event\CampaignBuilderEvent;
use MauticPlugin\SosCustomObjectsBundle\Form\Type\Campaign\CustomItemConditionType;
use MauticPlugin\SosCustomObjectsBundle\Form\Type\Campaign\CustomItemLinkType;
use MauticPlugin\SosCustomObjectsBundle\SosCustomObjectsEvents;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

final class CampaignSubscriber implements EventSubscriberInterface
{
    public const ACTION_TYPE    = 'sos.custom_objects.action.link_item';
    public const CONDITION_TYPE = 'sos.custom_objects.condition.item_field_compare';

    public static function getSubscribedEvents(): array
    {
        return [
            CampaignEvents::CAMPAIGN_ON_BUILD => ['onCampaignBuild', 0],
        ];
    }

    public function onCampaignBuild(CampaignBuilderEvent $event): void
    {
        $event->addAction(self::ACTION_TYPE, [
            'label'          => 'sos.custom_objects.campaign.action.link_item',
            'description'    => 'Vincula/Desvincula um Custom Item ao contato.',
            'batchEventName' => SosCustomObjectsEvents::EXECUTE_CAMPAIGN_ACTION,
            'formType'       => CustomItemLinkType::class,
        ]);

        $event->addCondition(self::CONDITION_TYPE, [
            'label'       => 'sos.custom_objects.campaign.condition.item_field_compare',
            'description' => 'Se o contato tem um item com campo comparável (ex: campo > 10).',
            'eventName'   => SosCustomObjectsEvents::EVALUATE_CAMPAIGN_CONDITION,
            'formType'    => CustomItemConditionType::class,
        ]);
    }
}
