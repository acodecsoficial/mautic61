<?php

namespace MauticPlugin\MauticSmsapiBundle\Core;

class Connection
{
    public function __construct(SmsapiPluginInterface $integrationHelper)
    {
        // Minimal: no external SDK.
    }
}
