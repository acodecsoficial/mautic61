<?php

namespace MauticPlugin\MauticSmsapiBundle\Integration;

use Doctrine\ORM\EntityManagerInterface;
use Mautic\CoreBundle\Helper\CacheStorageHelper;
use Mautic\CoreBundle\Helper\EncryptionHelper;
use Mautic\CoreBundle\Helper\PathsHelper;
use Mautic\CoreBundle\Model\NotificationModel;
use Mautic\IntegrationsBundle\Integration\ConfigurationTrait;
use Mautic\IntegrationsBundle\Integration\Interfaces\ConfigFormInterface;
use Mautic\LeadBundle\Field\FieldsWithUniqueIdentifier;
use Mautic\LeadBundle\Model\CompanyModel;
use Mautic\LeadBundle\Model\DoNotContact as DoNotContactModel;
use Mautic\LeadBundle\Model\FieldModel;
use Mautic\LeadBundle\Model\LeadModel;
use Mautic\PluginBundle\Integration\AbstractIntegration;
use Mautic\PluginBundle\Model\IntegrationEntityModel;
use MauticPlugin\MauticSmsapiBundle\Core\SmsapiGateway;
use MauticPlugin\MauticSmsapiBundle\Core\SmsapiPluginInterface;
use MauticPlugin\MauticSmsapiBundle\MauticSmsapiConst;
use Psr\Log\LoggerInterface;
use Symfony\Component\EventDispatcher\EventDispatcherInterface;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\HttpFoundation\RequestStack;
use Symfony\Component\Routing\RouterInterface;
use Symfony\Contracts\Translation\TranslatorInterface;

class SmsapiIntegration extends AbstractIntegration implements ConfigFormInterface
{
    use ConfigurationTrait;

    private SmsapiGateway $gateway;

    public function __construct(
        EventDispatcherInterface $eventDispatcher,
        CacheStorageHelper $cacheStorageHelper,
        EntityManagerInterface $entityManager,
        RequestStack $requestStack,
        RouterInterface $router,
        TranslatorInterface $translator,
        LoggerInterface $logger,
        EncryptionHelper $encryptionHelper,
        LeadModel $leadModel,
        CompanyModel $companyModel,
        PathsHelper $pathsHelper,
        NotificationModel $notificationModel,
        FieldModel $fieldModel,
        IntegrationEntityModel $integrationEntityModel,
        DoNotContactModel $doNotContact,
        FieldsWithUniqueIdentifier $fieldsWithUniqueIdentifier,
        SmsapiGateway $gateway
    ) {
        parent::__construct(
            $eventDispatcher,
            $cacheStorageHelper,
            $entityManager,
            $requestStack,
            $router,
            $translator,
            $logger,
            $encryptionHelper,
            $leadModel,
            $companyModel,
            $pathsHelper,
            $notificationModel,
            $fieldModel,
            $integrationEntityModel,
            $doNotContact,
            $fieldsWithUniqueIdentifier
        );

        $this->gateway = $gateway;
    }

    public function getName(): string
    {
        return MauticSmsapiConst::SMSAPI_INTEGRATION_NAME;
    }

    public function getDisplayName(): string
    {
        return 'Space SMS API';
    }

    public function getIcon(): string
    {
        return 'plugins/MauticSmsapiBundle/Assets/img/smsapi.png';
    }

    public function adapter(): SmsapiPluginInterface
    {
        return $this->factory->get('mautic.sms.smsapi.plugin');
    }

    public function getBearerToken($inAuthorization = false)
    {
        return false;
    }

    public function getClientName(): string
    {
        if (isset($this->keys['client_name']) && $this->keys['client_name']) {
            return (string) $this->keys['client_name'];
        }

        return '';
    }

    public function getFormSettings(): array
    {
        return [
            'requires_callback'      => false,
            'requires_authorization' => false,
        ];
    }

    public function getRequiredKeyFields(): array
    {
        return [];
    }

    public function getSecretKeys(): array
    {
        return [
            'API-Token',
        ];
    }

    public function getAuthenticationType(): string
    {
        return 'none';
    }

    public function appendToForm(&$builder, $data, $formArea): void
    {
        $isConnected = $this->gateway->isConnected();

        if ($formArea === 'keys') {
            $builder->add(
                'client_name',
                TextType::class,
                [
                    'label'      => 'Client (SpaceDev)',
                    'label_attr' => ['class' => 'control-label'],
                    'required'   => false,
                    'attr'       => [
                        'class'       => 'form-control',
                        'placeholder' => 'ex.: copapix',
                    ],
                    'data' => $data['client_name'] ?? ($this->keys['client_name'] ?? ''),
                ]
            );
        }

        if (!$isConnected) {
            return;
        }

        $sendernames = $this->gateway->getSendernames();
        $profile     = $this->gateway->getProfile();

        if ($formArea === 'features') {
            $builder->add(
                'available_points',
                TextType::class,
                [
                    'label'      => 'mautic.sms.config.form.sms.smsapi.available_points',
                    'label_attr' => ['class' => 'control-label'],
                    'disabled'   => true,
                    'required'   => false,
                    'attr'       => [
                        'class' => 'form-control',
                    ],
                    'data' => $profile->points,
                ]
            );

            $builder->add(
                'sendername',
                ChoiceType::class,
                [
                    'label'      => 'mautic.sms.config.form.sms.smsapi.sendername',
                    'label_attr' => ['class' => 'control-label'],
                    'required'   => false,
                    'attr'       => [
                        'class' => 'form-control',
                    ],
                    'choices' => $sendernames,
                ]
            );
        }
    }

    public function getConfigFormName(): ?string
    {
        return null;
    }

    public function getConfigFormContentTemplate(): ?string
    {
        return null;
    }
}