<?php

declare(strict_types=1);

namespace MauticPlugin\SosCustomObjectsBundle\DependencyInjection\Compiler;

use Symfony\Component\DependencyInjection\Compiler\CompilerPassInterface;
use Symfony\Component\DependencyInjection\ContainerBuilder;

final class TwigPathPass implements CompilerPassInterface
{
    public function process(ContainerBuilder $container): void
    {
        if (!$container->hasDefinition('twig.loader.native_filesystem')) {
            return;
        }

        $twigFilesystemLoaderDefinition = $container->getDefinition('twig.loader.native_filesystem');
        
        $path = dirname(__DIR__, 2) . '/Resources/views';
        
        if (is_dir($path)) {
            $twigFilesystemLoaderDefinition->addMethodCall('addPath', [$path, 'SosCustomObjectsBundle']);
        }
    }
}
