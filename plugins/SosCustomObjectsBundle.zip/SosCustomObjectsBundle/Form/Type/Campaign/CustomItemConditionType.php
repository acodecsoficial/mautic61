<?php

declare(strict_types=1);

namespace MauticPlugin\SosCustomObjectsBundle\Form\Type\Campaign;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;

final class CustomItemConditionType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder
            ->add('object_id', IntegerType::class, [
                'label'    => 'ID do Objeto',
                'required' => false,
            ])
            ->add('field_alias', TextType::class, [
                'label'    => 'Alias do Campo (ex: score)',
                'required' => true,
            ])
            ->add('operator', ChoiceType::class, [
                'label'   => 'Operador',
                'choices' => [
                    '='  => '=',
                    '!=' => '!=',
                    '>'  => '>',
                    '>=' => '>=',
                    '<'  => '<',
                    '<=' => '<=',
                    'contém' => 'LIKE',
                ],
                'required' => true,
            ])
            ->add('value', TextType::class, [
                'label'    => 'Valor',
                'required' => true,
            ]);
    }
}
