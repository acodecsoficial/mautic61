<?php

declare(strict_types=1);

namespace MauticPlugin\SosCustomObjectsBundle\EventListener;

use Doctrine\DBAL\Connection;
use JMS\Serializer\EventDispatcher\Events;
use JMS\Serializer\EventDispatcher\EventSubscriberInterface;
use JMS\Serializer\EventDispatcher\ObjectEvent;
use JMS\Serializer\JsonSerializationVisitor;
use JMS\Serializer\Metadata\StaticPropertyMetadata;
use Mautic\LeadBundle\Entity\Lead;
use Symfony\Component\HttpFoundation\RequestStack;
use Doctrine\DBAL\Exception as DbalException;

final class SerializerSubscriber implements EventSubscriberInterface
{
    public function __construct(
        private Connection $db,
        private RequestStack $requestStack,
    ) {
    }

    /**
     * @return array<int, array<string, string>>
     */
    public static function getSubscribedEvents(): array
    {
        return [
            [
                'event'  => Events::POST_SERIALIZE,
                'method' => 'addCustomObjectsIntoContactResponse',
            ],
        ];
    }

    public function addCustomObjectsIntoContactResponse(ObjectEvent $event): void
    {
        $request = $this->requestStack->getCurrentRequest();
        if (null === $request) {
            return;
        }

        // Match the reference plugin behavior: only include if explicitly asked.
        if (!$request->get('includeCustomObjects', false)) {
            return;
        }

        $contact = $event->getObject();
        if (!$contact instanceof Lead) {
            return;
        }

        $visitor = $event->getContext()->getVisitor();
        if (!$visitor instanceof JsonSerializationVisitor) {
            return;
        }

        $contactId = $contact->getId();
        if (null === $contactId) {
            return;
        }

        $payload = $this->buildCustomObjectsPayload((int) $contactId);
        if (empty($payload['data'])) {
            return;
        }

        $visitor->visitProperty(new StaticPropertyMetadata('', 'customObjects', $payload), $payload);
    }

    /**
     * @return array{data: array<int, mixed>, meta: array<string, mixed>}
     */
    private function buildCustomObjectsPayload(int $contactId): array
    {
        $params = $this->db->getParams();
        $prefix = (string) ($params['table_prefix'] ?? '');

        try {
            $schema = $this->db->createSchemaManager();
            if (
                !$schema->tablesExist([
                    $prefix.'sos_custom_item_contact',
                    $prefix.'sos_custom_item',
                    $prefix.'sos_custom_object',
                ])
            ) {
                return [
                    'data' => [],
                    'meta' => ['page' => ['number' => 1, 'size' => 0], 'sort' => '-dateAdded'],
                ];
            }
        } catch (DbalException|\Throwable) {
            return [
                'data' => [],
                'meta' => ['page' => ['number' => 1, 'size' => 0], 'sort' => '-dateAdded'],
            ];
        }

        $objectTable = $prefix.'sos_custom_object';
        $itemTable   = $prefix.'sos_custom_item';
        $fieldTable  = $prefix.'sos_custom_field';
        $valueTable  = $prefix.'sos_custom_item_value';
        $linkTable   = $prefix.'sos_custom_item_contact';

        $valueSelect = $this->buildValueSelect($prefix, $valueTable, 'v');

        $sql = "
            SELECT
                o.id   AS object_id,
                o.alias AS object_alias,
                i.id   AS item_id,
                i.label AS item_label,
                f.alias AS field_alias,
                f.type  AS field_type,
                {$valueSelect}
            FROM {$linkTable} c
            INNER JOIN {$itemTable} i ON i.id = c.custom_item_id
            INNER JOIN {$objectTable} o ON o.id = i.custom_object_id
            LEFT JOIN {$valueTable} v ON v.custom_item_id = i.id
            LEFT JOIN {$fieldTable} f ON f.id = v.custom_field_id
            WHERE c.contact_id = :cid
            ORDER BY o.id ASC, i.id ASC
        ";

        $rows = $this->db->fetchAllAssociative($sql, ['cid' => $contactId]);

        $objects = [];
        foreach ($rows as $r) {
            $objectId = (int) $r['object_id'];
            $itemId   = (int) $r['item_id'];

            if (!isset($objects[$objectId])) {
                $objects[$objectId] = [
                    'id'    => $objectId,
                    'alias' => (string) $r['object_alias'],
                    'data'  => [],
                ];
            }

            if (!isset($objects[$objectId]['data'][$itemId])) {
                $objects[$objectId]['data'][$itemId] = [
                    'id'         => $itemId,
                    'name'       => $r['item_label'],
                    'attributes' => [],
                ];
            }

            $fieldAlias = $r['field_alias'];
            if (!is_string($fieldAlias) || $fieldAlias === '') {
                continue;
            }

            $objects[$objectId]['data'][$itemId]['attributes'][$fieldAlias] = $this->normalizeValueRow($r);
        }

        $data = [];
        foreach ($objects as $obj) {
            // normalize item array values (remove itemId keys)
            $obj['data'] = array_values($obj['data']);
            $data[]      = $obj;
        }

        return [
            'data' => $data,
            'meta' => [
                'page' => [
                    'number' => 1,
                    'size'   => 1000,
                ],
                'sort' => '-dateAdded',
            ],
        ];
    }

    /**
     * @param array<string, mixed> $row
     */
    private function normalizeValueRow(array $row): mixed
    {
        $type = (string) ($row['field_type'] ?? '');

        return match ($type) {
            'number' => isset($row['value_number']) ? (float) $row['value_number'] : null,
            'bool' => isset($row['value_bool']) ? (bool) $row['value_bool'] : null,
            'date' => $row['value_date'] ? (new \DateTime((string) $row['value_date']))->format(DATE_ATOM) : null,
            default => $row['value_text'] ?? null,
        };
    }

    private function buildValueSelect(string $prefix, string $valueTable, string $alias): string
    {
        $schema = $this->db->createSchemaManager();
        /** @var array<string, string> $cols */
        $cols   = [];
        try {
            foreach ($schema->listTableColumns($valueTable) as $name => $_col) {
                $cols[strtolower((string) $name)] = (string) $name;
            }
        } catch (DbalException|\Throwable) {
            $cols = [];
        }

        $textExpr = $this->pickColumnExpr($alias, $cols, ['value_text', 'valuetext', 'value']);
        $numberExpr = $this->pickColumnExpr($alias, $cols, ['value_number', 'valuenumber']);
        $dateExpr = $this->pickColumnExpr($alias, $cols, ['value_date', 'valuedate']);
        $boolExpr = $this->pickColumnExpr($alias, $cols, ['value_bool', 'valuebool']);

        return implode(",\n                ", [
            "{$textExpr} AS value_text",
            "{$numberExpr} AS value_number",
            "{$dateExpr} AS value_date",
            "{$boolExpr} AS value_bool",
        ]);
    }

    /**
     * @param array<string, string> $cols lower => actual
     * @param string[] $candidates
     */
    private function pickColumnExpr(string $alias, array $cols, array $candidates): string
    {
        foreach ($candidates as $candidate) {
            $key = strtolower($candidate);
            if (isset($cols[$key])) {
                return "{$alias}.{$cols[$key]}";
            }
        }

        return 'NULL';
    }
}
