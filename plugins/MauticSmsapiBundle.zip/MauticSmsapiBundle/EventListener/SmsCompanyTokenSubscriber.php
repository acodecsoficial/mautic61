<?php

namespace MauticPlugin\MauticSmsapiBundle\EventListener;

use Doctrine\ORM\EntityManagerInterface;
use Mautic\CoreBundle\Event\TokenReplacementEvent;
use Mautic\LeadBundle\Entity\Lead;
use Mautic\SmsBundle\SmsEvents;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
 * Substitui tokens {contactfield=companyXxx} com dados da empresa primária do contato.
 * Roda com prioridade 10 (antes do SmsSubscriber padrão com prioridade 0),
 * garantindo que funcione mesmo em versões antigas do Mautic que não usam PrimaryCompanyHelper.
 */
class SmsCompanyTokenSubscriber implements EventSubscriberInterface
{
    public function __construct(
        private EntityManagerInterface $em
    ) {
    }

    public static function getSubscribedEvents(): array
    {
        return [
            SmsEvents::TOKEN_REPLACEMENT => ['onTokenReplacement', 10],
        ];
    }

    public function onTokenReplacement(TokenReplacementEvent $event): void
    {
        /** @var Lead $lead */
        $lead    = $event->getLead();
        $content = $event->getContent();

        if (!$content || !$lead) {
            return;
        }

        $changed = false;

        // Substitui {contactfield=sms_link} diretamente do banco, antes do trackable processing
        if (str_contains($content, '{contactfield=sms_link}')) {
            $smsLink = $this->getLeadField($lead, 'sms_link');
            if ($smsLink !== null) {
                $content  = str_replace('{contactfield=sms_link}', $smsLink, $content);
                $changed  = true;
            }
        }

        // Substitui tokens {contactfield=companyXxx} com dados da empresa primária
        if (preg_match('/\{contactfield=company/i', $content)) {
            $company = $this->getPrimaryCompanyFields($lead);
            if (!empty($company)) {
                $content = preg_replace_callback(
                    '/\{contactfield=(company[^|}]+)(?:\|[^}]*)?\}/i',
                    function (array $m) use ($company): string {
                        $alias = strtolower($m[1]);
                        return isset($company[$alias]) ? (string) $company[$alias] : '';
                    },
                    $content
                );
                $changed = true;
            }
        }

        if ($changed) {
            $event->setContent($content);
        }
    }

    private function getLeadField(Lead $lead, string $alias): ?string
    {
        try {
            $conn = $this->em->getConnection();
            $row  = $conn->fetchAssociative(
                'SELECT ' . $alias . ' FROM leads WHERE id = ? LIMIT 1',
                [$lead->getId()]
            );
            return isset($row[$alias]) ? (string) $row[$alias] : null;
        } catch (\Throwable $e) {
            return null;
        }
    }

    private function getPrimaryCompanyFields(Lead $lead): array
    {
        try {
            $conn = $this->em->getConnection();
            $row  = $conn->fetchAssociative(
                'SELECT comp.*
                 FROM companies comp
                 INNER JOIN companies_leads cl ON cl.company_id = comp.id
                 WHERE cl.lead_id = ? AND cl.is_primary = 1
                 LIMIT 1',
                [$lead->getId()]
            );

            return $row ?: [];
        } catch (\Throwable $e) {
            return [];
        }
    }
}
