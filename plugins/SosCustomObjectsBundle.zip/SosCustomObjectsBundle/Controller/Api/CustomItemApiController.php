<?php

declare(strict_types=1);

namespace MauticPlugin\SosCustomObjectsBundle\Controller\Api;

use MauticPlugin\SosCustomObjectsBundle\Service\CustomItemService;
use MauticPlugin\SosCustomObjectsBundle\Service\CustomObjectService;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\RequestStack;
use Symfony\Component\HttpFoundation\Response;

final class CustomItemApiController
{
    public function __construct(
        private CustomObjectService $objectService,
        private CustomItemService $itemService,
        private RequestStack $requestStack,
    ) {}

    public function listAction(int $objectId): JsonResponse
    {
        $object = $this->objectService->get($objectId);
        if (!$object) {
            return new JsonResponse(['error' => 'Custom object not found'], Response::HTTP_NOT_FOUND);
        }

        $items = [];
        foreach ($this->itemService->list($object) as $item) {
            $items[] = $this->serialize($item, $this->itemService->getItemValues($item));
        }

        return new JsonResponse(['total' => count($items), 'items' => $items]);
    }

    public function getAction(int $objectId, int $id): JsonResponse
    {
        $object = $this->objectService->get($objectId);
        if (!$object) {
            return new JsonResponse(['error' => 'Custom object not found'], Response::HTTP_NOT_FOUND);
        }

        $item = $this->itemService->get($id);
        if (!$item || $item->getObject()->getId() !== $objectId) {
            return new JsonResponse(['error' => 'Item not found'], Response::HTTP_NOT_FOUND);
        }

        return new JsonResponse($this->serialize($item, $this->itemService->getItemValues($item)));
    }

    public function createAction(int $objectId): JsonResponse
    {
        $object = $this->objectService->get($objectId);
        if (!$object) {
            return new JsonResponse(['error' => 'Custom object not found'], Response::HTTP_NOT_FOUND);
        }

        $data = json_decode((string) $this->getCurrentRequest()->getContent(), true) ?: [];

        try {
            $item = $this->itemService->create(
                $object,
                isset($data['label']) ? (string)$data['label'] : null,
                is_array($data['values'] ?? null) ? $data['values'] : []
            );

            return new JsonResponse($this->serialize($item, $this->itemService->getItemValues($item)), Response::HTTP_CREATED);
        } catch (\Throwable $e) {
            return new JsonResponse(['error' => $e->getMessage()], Response::HTTP_BAD_REQUEST);
        }
    }

    public function updateAction(int $objectId, int $id): JsonResponse
    {
        $object = $this->objectService->get($objectId);
        if (!$object) {
            return new JsonResponse(['error' => 'Custom object not found'], Response::HTTP_NOT_FOUND);
        }

        $item = $this->itemService->get($id);
        if (!$item || $item->getObject()->getId() !== $objectId) {
            return new JsonResponse(['error' => 'Item not found'], Response::HTTP_NOT_FOUND);
        }

        $data = json_decode((string) $this->getCurrentRequest()->getContent(), true) ?: [];

        try {
            $item = $this->itemService->update(
                $item,
                array_key_exists('label', $data) ? (string)$data['label'] : $item->getLabel(),
                is_array($data['values'] ?? null) ? $data['values'] : []
            );

            return new JsonResponse($this->serialize($item, $this->itemService->getItemValues($item)));
        } catch (\Throwable $e) {
            return new JsonResponse(['error' => $e->getMessage()], Response::HTTP_BAD_REQUEST);
        }
    }

    public function deleteAction(int $objectId, int $id): JsonResponse
    {
        $object = $this->objectService->get($objectId);
        if (!$object) {
            return new JsonResponse(['error' => 'Custom object not found'], Response::HTTP_NOT_FOUND);
        }

        $item = $this->itemService->get($id);
        if (!$item || $item->getObject()->getId() !== $objectId) {
            return new JsonResponse(['error' => 'Item not found'], Response::HTTP_NOT_FOUND);
        }

        $this->itemService->delete($item);
        return new JsonResponse(null, Response::HTTP_NO_CONTENT);
    }

    public function linkContactAction(int $objectId, int $id, int $contactId): JsonResponse
    {
        $item = $this->itemService->get($id);
        if (!$item || $item->getObject()->getId() !== $objectId) {
            return new JsonResponse(['error' => 'Item not found'], Response::HTTP_NOT_FOUND);
        }

        $this->itemService->linkContact($item, $contactId);
        return new JsonResponse(['ok' => true]);
    }

    public function unlinkContactAction(int $objectId, int $id, int $contactId): JsonResponse
    {
        $item = $this->itemService->get($id);
        if (!$item || $item->getObject()->getId() !== $objectId) {
            return new JsonResponse(['error' => 'Item not found'], Response::HTTP_NOT_FOUND);
        }

        $this->itemService->unlinkContact($item, $contactId);
        return new JsonResponse(['ok' => true]);
    }

    private function getCurrentRequest(): Request
    {
        $request = $this->requestStack->getCurrentRequest();
        if (null === $request) {
            throw new \RuntimeException('Request is not set.');
        }
        return $request;
    }

    private function serialize($item, array $values): array
    {
        return [
            'id' => $item->getId(),
            'customObjectId' => $item->getObject()->getId(),
            'label' => $item->getLabel(),
            'dateAdded' => $item->getDateAdded()->format(DATE_ATOM),
            'dateModified' => $item->getDateModified()?->format(DATE_ATOM),
            'values' => $values,
        ];
    }
}
