<?php

use MauticPlugin\SosCustomObjectsBundle\Entity\CustomField;

$view->extend('MauticCoreBundle:Default:content.html.php');

$mode   = $view['data']->get('mode', 'new');
$object = $view['data']->get('object');
$item   = $view['data']->get('item');

$title = $mode === 'edit' ? 'Editar Campo' : 'Novo Campo';
$view['slots']->set('headerTitle', $title.' - '.$view->escape($object->getName()));

$label = $item ? $item->getLabel() : '';
$alias = $item ? $item->getAlias() : '';
$type  = $item ? $item->getType()  : CustomField::TYPE_TEXT;
$isRequired = $item ? (bool)$item->isRequired() : false;
$optionsArr = $item ? ($item->getOptions() ?: []) : [];
$optionsText = $optionsArr ? implode("\n", $optionsArr) : '';
?>

<div class="box-layout">
  <div class="col-md-8">
    <div class="toolbar mb-md">
      <a class="btn btn-default" href="<?php echo $view['router']->path('sos_custom_fields_list', ['objectId' => $object->getId()]); ?>">
        <i class="fa fa-arrow-left"></i> Voltar
      </a>
    </div>

    <div class="panel panel-default">
      <div class="panel-heading"><h4 class="panel-title"><?php echo $view->escape($title); ?></h4></div>
      <div class="panel-body">
        <form method="post">
          <div class="form-group">
            <label>Label</label>
            <input class="form-control" name="label" value="<?php echo $view->escape($label); ?>" required />
          </div>

          <div class="form-group">
            <label>Alias</label>
            <input class="form-control" name="alias" value="<?php echo $view->escape($alias); ?>" required />
            <small class="text-muted">Use apenas letras, números e underline.</small>
          </div>

          <div class="form-group">
            <label>Tipo</label>
            <select class="form-control" name="type">
              <?php foreach ([CustomField::TYPE_TEXT, CustomField::TYPE_NUMBER, CustomField::TYPE_DATE, CustomField::TYPE_BOOL, CustomField::TYPE_SELECT] as $t): ?>
                <option value="<?php echo $t; ?>" <?php echo $t === $type ? 'selected' : ''; ?>>
                  <?php echo $t; ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="form-group">
            <label>
              <input type="checkbox" name="isRequired" value="1" <?php echo $isRequired ? 'checked' : ''; ?> />
              Obrigatório
            </label>
          </div>

          <div class="form-group">
            <label>Opções (apenas para tipo <code>select</code>, uma por linha)</label>
            <textarea class="form-control" name="options" rows="6"><?php echo $view->escape($optionsText); ?></textarea>
          </div>

          <div class="form-group">
            <button class="btn btn-primary"><i class="fa fa-save"></i> Salvar</button>
            <a class="btn btn-default" href="<?php echo $view['router']->path('sos_custom_fields_list', ['objectId' => $object->getId()]); ?>">Cancelar</a>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
