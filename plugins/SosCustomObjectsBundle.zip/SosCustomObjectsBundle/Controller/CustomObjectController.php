<?php

declare(strict_types=1);

namespace MauticPlugin\SosCustomObjectsBundle\Controller;

use Doctrine\Persistence\ManagerRegistry;
use Mautic\CoreBundle\Controller\CommonController;
use Mautic\CoreBundle\Factory\ModelFactory;
use Mautic\CoreBundle\Helper\CoreParametersHelper;
use Mautic\CoreBundle\Helper\InputHelper;
use Mautic\CoreBundle\Helper\UserHelper;
use Mautic\CoreBundle\Security\Permissions\CorePermissions;
use Mautic\CoreBundle\Service\FlashBag;
use Mautic\CoreBundle\Translation\Translator;
use MauticPlugin\SosCustomObjectsBundle\Service\CustomObjectService;
use Symfony\Component\EventDispatcher\EventDispatcherInterface;
use Symfony\Component\HttpFoundation\RequestStack;
use Symfony\Component\HttpFoundation\Response;

final class CustomObjectController extends CommonController
{
    public function __construct(
        ManagerRegistry $doctrine,
        ModelFactory $modelFactory,
        UserHelper $userHelper,
        CoreParametersHelper $coreParametersHelper,
        EventDispatcherInterface $dispatcher,
        Translator $translator,
        FlashBag $flashBag,
        RequestStack $requestStack,
        CorePermissions $security,
        private CustomObjectService $customObjectService,
    ) {
        parent::__construct(
            $doctrine,
            $modelFactory,
            $userHelper,
            $coreParametersHelper,
            $dispatcher,
            $translator,
            $flashBag,
            $requestStack,
            $security
        );
    }

    public function listAction(): Response
    {
        return $this->delegateView([
            'viewParameters' => [
                'items' => $this->customObjectService->list(),
            ],
            'contentTemplate' => '@SosCustomObjectsBundle/CustomObject/list.html.twig',
            'passthroughVars' => [
                'mauticContent' => 'sosCustomObjects',
                'route'         => $this->generateUrl('sos_custom_objects_list'),
            ],
        ]);
    }

    public function newAction(): Response
    {
        $request = $this->getCurrentRequest();

        if ($request->isMethod('POST')) {
            $name = InputHelper::clean($request->request->get('name', ''));
            $alias = InputHelper::clean($request->request->get('alias', ''));
            $description = InputHelper::clean($request->request->get('description', ''), true);

            try {
                $this->customObjectService->create($name, $alias, $description ?: null);
                $this->addFlashMessage('Custom Object criado com sucesso.');
                return $this->redirectToRoute('sos_custom_objects_list');
            } catch (\Throwable $e) {
                $this->addFlashMessage('Erro: '.$e->getMessage(), [], FlashBag::LEVEL_ERROR);
            }
        }

        return $this->delegateView([
            'viewParameters' => [
                'mode' => 'new',
                'item' => null,
            ],
            'contentTemplate' => '@SosCustomObjectsBundle/CustomObject/form.html.twig',
            'passthroughVars' => [
                'mauticContent' => 'sosCustomObjects',
                'route'         => $this->generateUrl('sos_custom_objects_new'),
            ],
        ]);
    }

    public function editAction(int $id): Response
    {
        $request = $this->getCurrentRequest();
        $obj = $this->customObjectService->get($id);

        if (!$obj) {
            return $this->notFound('Custom Object não encontrado.');
        }

        if ($request->isMethod('POST')) {
            $name = InputHelper::clean($request->request->get('name', ''));
            $alias = InputHelper::clean($request->request->get('alias', ''));
            $description = InputHelper::clean($request->request->get('description', ''), true);

            try {
                $this->customObjectService->update($obj, $name, $alias, $description ?: null);
                $this->addFlashMessage('Custom Object atualizado com sucesso.');
                return $this->redirectToRoute('sos_custom_objects_list');
            } catch (\Throwable $e) {
                $this->addFlashMessage('Erro: '.$e->getMessage(), [], FlashBag::LEVEL_ERROR);
            }
        }

        return $this->delegateView([
            'viewParameters' => [
                'mode' => 'edit',
                'item' => $obj,
            ],
            'contentTemplate' => '@SosCustomObjectsBundle/CustomObject/form.html.twig',
            'passthroughVars' => [
                'mauticContent' => 'sosCustomObjects',
                'route'         => $this->generateUrl('sos_custom_objects_edit', ['id' => $id]),
            ],
        ]);
    }

    public function deleteAction(int $id): Response
    {
        $request = $this->getCurrentRequest();
        if (!$request->isMethod('POST')) {
            return $this->accessDenied();
        }

        $obj = $this->customObjectService->get($id);
        if (!$obj) {
            return $this->notFound('Custom Object não encontrado.');
        }

        $this->customObjectService->delete($obj);
        $this->addFlashMessage('Custom Object removido.');
        return $this->redirectToRoute('sos_custom_objects_list');
    }
}
