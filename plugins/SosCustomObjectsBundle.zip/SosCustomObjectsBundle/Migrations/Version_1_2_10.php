<?php

declare(strict_types=1);

namespace MauticPlugin\SosCustomObjectsBundle\Migrations;

use Doctrine\DBAL\Schema\Schema;
use Mautic\IntegrationsBundle\Migration\AbstractMigration;

/**
 * Normalize `sos_custom_item_value` columns across installs.
 *
 * Some early/legacy installs used a single `value` column. Newer schema uses
 * typed columns (`valueText`, `valueNumber`, `valueDate`, `valueBool`).
 */
final class Version_1_2_10 extends AbstractMigration
{
    protected function isApplicable(Schema $schema): bool
    {
        $valTable = $this->concatPrefix('sos_custom_item_value');
        if (!$schema->hasTable($valTable)) {
            return false;
        }

        $table   = $schema->getTable($valTable);
        $missing = !$table->hasColumn('valueText')
            || !$table->hasColumn('valueNumber')
            || !$table->hasColumn('valueDate')
            || !$table->hasColumn('valueBool');

        return $missing;
    }

    protected function up(): void
    {
        $valTable = $this->concatPrefix('sos_custom_item_value');

        $columns = [];
        try {
            $schemaManager = $this->connection->createSchemaManager();
            foreach ($schemaManager->listTableColumns($valTable) as $name => $_col) {
                $columns[strtolower((string) $name)] = true;
            }
        } catch (\Throwable) {
            // If we can't introspect, don't attempt risky DDL.
            return;
        }

        // Add missing typed columns.
        if (!isset($columns['valuetext'])) {
            $this->addSql("ALTER TABLE `$valTable` ADD COLUMN `valueText` LONGTEXT DEFAULT NULL");
        }
        if (!isset($columns['valuenumber'])) {
            $this->addSql("ALTER TABLE `$valTable` ADD COLUMN `valueNumber` DOUBLE DEFAULT NULL");
        }
        if (!isset($columns['valuedate'])) {
            $this->addSql("ALTER TABLE `$valTable` ADD COLUMN `valueDate` DATETIME DEFAULT NULL");
        }
        if (!isset($columns['valuebool'])) {
            $this->addSql("ALTER TABLE `$valTable` ADD COLUMN `valueBool` TINYINT(1) DEFAULT NULL");
        }

        // Backfill from legacy columns if they exist.
        if (isset($columns['value'])) {
            $this->addSql("UPDATE `$valTable` SET `valueText` = COALESCE(`valueText`, `value`) WHERE `valueText` IS NULL");
        }
        if (isset($columns['value_text'])) {
            $this->addSql("UPDATE `$valTable` SET `valueText` = COALESCE(`valueText`, `value_text`) WHERE `valueText` IS NULL");
        }
    }
}
