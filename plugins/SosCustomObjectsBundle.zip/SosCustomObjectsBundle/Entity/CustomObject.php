<?php

declare(strict_types=1);

namespace MauticPlugin\SosCustomObjectsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: \MauticPlugin\SosCustomObjectsBundle\Repository\CustomObjectRepository::class)]
#[ORM\Table(name: 'sos_custom_object')]
#[ORM\UniqueConstraint(name: 'uniq_sos_custom_object_alias', columns: ['alias'])]
class CustomObject
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private ?int $id = null;

    #[ORM\Column(type: 'string', length: 191)]
    private string $name = '';

    #[ORM\Column(type: 'string', length: 191)]
    private string $alias = '';

    #[ORM\Column(type: 'text', nullable: true)]
    private ?string $description = null;

    #[ORM\Column(name: 'date_added', type: 'datetime_immutable')]
    private \DateTimeImmutable $dateAdded;

    #[ORM\Column(name: 'date_modified', type: 'datetime_immutable', nullable: true)]
    private ?\DateTimeImmutable $dateModified = null;

    public function __construct()
    {
        $this->dateAdded = new \DateTimeImmutable('now');
    }

    public function getId(): ?int { return $this->id; }
    public function getName(): string { return $this->name; }
    public function setName(string $name): self { $this->name = $name; return $this; }

    public function getAlias(): string { return $this->alias; }
    public function setAlias(string $alias): self { $this->alias = $alias; return $this; }

    public function getDescription(): ?string { return $this->description; }
    public function setDescription(?string $description): self { $this->description = $description; return $this; }

    public function getDateAdded(): \DateTimeImmutable { return $this->dateAdded; }
    public function touch(): void { $this->dateModified = new \DateTimeImmutable('now'); }
    public function getDateModified(): ?\DateTimeImmutable { return $this->dateModified; }
}
