<?php

declare(strict_types=1);

namespace MauticPlugin\SosCustomObjectsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: \MauticPlugin\SosCustomObjectsBundle\Repository\CustomFieldRepository::class)]
#[ORM\Table(name: 'sos_custom_field')]
#[ORM\UniqueConstraint(name: 'uniq_sos_custom_field_object_alias', columns: ['custom_object_id','alias'])]
class CustomField
{
    public const TYPE_TEXT   = 'text';
    public const TYPE_NUMBER = 'number';
    public const TYPE_DATE   = 'date';
    public const TYPE_BOOL   = 'bool';
    public const TYPE_SELECT = 'select';

    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private ?int $id = null;

    #[ORM\ManyToOne(targetEntity: CustomObject::class)]
    #[ORM\JoinColumn(name: 'custom_object_id', referencedColumnName: 'id', nullable: false, onDelete: 'CASCADE')]
    private CustomObject $object;

    #[ORM\Column(type: 'string', length: 191)]
    private string $label = '';

    #[ORM\Column(type: 'string', length: 191)]
    private string $alias = '';

    #[ORM\Column(type: 'string', length: 20)]
    private string $type = self::TYPE_TEXT;

    #[ORM\Column(type: 'boolean')]
    private bool $isRequired = false;

    #[ORM\Column(type: 'json', nullable: true)]
    private ?array $options = null; // for select

    #[ORM\Column(name: 'date_added', type: 'datetime_immutable')]
    private \DateTimeImmutable $dateAdded;

    #[ORM\Column(name: 'date_modified', type: 'datetime_immutable', nullable: true)]
    private ?\DateTimeImmutable $dateModified = null;

    public function __construct(CustomObject $object)
    {
        $this->object = $object;
        $this->dateAdded = new \DateTimeImmutable('now');
    }

    public function getId(): ?int { return $this->id; }
    public function getObject(): CustomObject { return $this->object; }

    public function getLabel(): string { return $this->label; }
    public function setLabel(string $label): self { $this->label = $label; return $this; }

    public function getAlias(): string { return $this->alias; }
    public function setAlias(string $alias): self { $this->alias = $alias; return $this; }

    public function getType(): string { return $this->type; }
    public function setType(string $type): self { $this->type = $type; return $this; }

    public function isRequired(): bool { return $this->isRequired; }
    public function setIsRequired(bool $isRequired): self { $this->isRequired = $isRequired; return $this; }

    public function getOptions(): ?array { return $this->options; }
    public function setOptions(?array $options): self { $this->options = $options; return $this; }

    public function getDateAdded(): \DateTimeImmutable { return $this->dateAdded; }
    public function touch(): void { $this->dateModified = new \DateTimeImmutable('now'); }
    public function getDateModified(): ?\DateTimeImmutable { return $this->dateModified; }
}
