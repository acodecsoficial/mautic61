<?php

declare(strict_types=1);

namespace MauticPlugin\AcdGenericApiMailerBundle\Mailer\Transport;

use JsonException;
use MauticPlugin\AcdGenericApiMailerBundle\Exception\AcdGenericApiMailerConfigurationException;
use MauticPlugin\AcdGenericApiMailerBundle\Service\AcdIntegrationConfigurationProvider;
use MauticPlugin\AcdGenericApiMailerBundle\Service\AcdPayloadMappingService;
use Psr\Log\LoggerInterface;
use Symfony\Component\Mailer\Exception\TransportException;
use Symfony\Component\Mailer\SentMessage;
use Symfony\Component\Mailer\Transport\AbstractTransport;
use Symfony\Component\Mime\Email;
use Symfony\Contracts\EventDispatcher\EventDispatcherInterface;
use Symfony\Contracts\HttpClient\Exception\TransportExceptionInterface as HttpTransportExceptionInterface;
use Symfony\Contracts\HttpClient\HttpClientInterface;
use Throwable;

class AcdGenericApiMailerTransport extends AbstractTransport
{
    public function __construct(
        ?EventDispatcherInterface $dispatcher,
        private HttpClientInterface $client,
        private AcdIntegrationConfigurationProvider $configurationProvider,
        private AcdMessagePayloadFactory $payloadFactory,
        private AcdPayloadMappingService $payloadMappingService,
        private LoggerInterface $logger,
    ) {
        parent::__construct($dispatcher, $logger);
    }

    protected function doSend(SentMessage $message): void
    {
        try {
            $profile = $this->configurationProvider->acdGetActiveProfile();
            $originalMessage = $message->getOriginalMessage();
            if (!$originalMessage instanceof Email) {
                throw new AcdGenericApiMailerConfigurationException('O Symfony Mailer forneceu uma mensagem que não é compatível com o adaptador HTTP.');
            }

            $payload = $this->payloadFactory->acdBuildPayload($originalMessage, $profile);
            $headers = $this->acdBuildHeaders($profile, $originalMessage, $message->getMessageId());
        } catch (AcdGenericApiMailerConfigurationException $exception) {
            $this->logger->error('O transporte de e-mail por API não pode preparar a mensagem.', [
                'reason' => $exception->getMessage(),
            ]);
            throw new TransportException($exception->getMessage(), 0, $exception);
        } catch (Throwable $exception) {
            $this->logger->error('O transporte de e-mail por API encontrou uma falha ao preparar a mensagem.', [
                'exception' => get_debug_type($exception),
            ]);
            throw new TransportException('Não foi possível preparar a mensagem para o transporte por API.', 0, $exception);
        }

        try {
            $response = $this->client->request('POST', $profile['endpoint'], [
                'headers' => $headers,
                'json' => $payload,
                'timeout' => $profile['timeout'],
                'max_redirects' => 0,
            ]);
            $statusCode = $response->getStatusCode();
            $responseBody = $response->getContent(false);
        } catch (HttpTransportExceptionInterface $exception) {
            $this->logger->error('Falha de rede ao chamar a API de envio de e-mail.', [
                'profile' => $profile['name'],
                'exception' => get_debug_type($exception),
            ]);
            throw new TransportException('Falha de rede ou timeout no perfil '.$profile['name'].'.', 0, $exception);
        } catch (Throwable $exception) {
            $this->logger->error('Falha ao enviar a requisição para a API de e-mail.', [
                'profile' => $profile['name'],
                'exception' => get_debug_type($exception),
            ]);
            throw new TransportException('Falha ao enviar a requisição no perfil '.$profile['name'].'.', 0, $exception);
        }

        if ($statusCode < 200 || $statusCode >= 300) {
            $errorDetails = $this->acdExtractApiError($responseBody);
            $this->logger->error('A API de envio de e-mail recusou a mensagem.', [
                'profile' => $profile['name'],
                'status_code' => $statusCode,
                'error_code' => $errorDetails['code'],
                'request_id' => $errorDetails['request_id'],
            ]);

            $description = 'HTTP '.$statusCode;
            if (null !== $errorDetails['code']) {
                $description .= ', '.$errorDetails['code'];
            }
            if (null !== $errorDetails['request_id']) {
                $description .= ', requisição '.$errorDetails['request_id'];
            }

            throw new TransportException('A API recusou o envio no perfil '.$profile['name'].' ('.$description.').');
        }

        $providerMessageId = $this->acdExtractProviderMessageId($responseBody);
        $this->logger->info('A API aceitou a mensagem de e-mail.', [
            'profile' => $profile['name'],
            'status_code' => $statusCode,
            'provider_message_id' => $providerMessageId,
        ]);
    }

    public function __toString(): string
    {
        return $this->getName();
    }

    protected function getName(): string
    {
        return 'generic-api';
    }

    private function acdBuildHeaders(array $profile, Email $email, string $messageId = ''): array
    {
        $headers = [
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
        ];

        $authType = $profile['auth_type'];
        if ('bearer' === $authType) {
            $headers['Authorization'] = 'Bearer '.$profile['token'];
        } elseif ('basic' === $authType) {
            $headers['Authorization'] = 'Basic '.base64_encode($profile['username'].':'.$profile['password']);
        } elseif ('api_key' === $authType) {
            $headers[$profile['api_key_header']] = $profile['token'];
        }

        foreach ($this->acdParseAdditionalHeaders($profile['headers_json']) as $name => $value) {
            $headers[$name] = $value;
        }

        if ('sndr' === $profile['adapter']) {
            if ('' === $messageId) {
                $messageId = bin2hex(random_bytes(16));
            }
            $headers['Idempotency-Key'] = hash('sha256', $messageId);
        }

        return $headers;
    }

    private function acdParseAdditionalHeaders(string $headersJson): array
    {
        try {
            $headers = json_decode($headersJson, true, 512, JSON_THROW_ON_ERROR);
        } catch (JsonException $exception) {
            throw new AcdGenericApiMailerConfigurationException('Os cabeçalhos adicionais precisam conter JSON válido.', 0, $exception);
        }

        if (!is_array($headers) || ([] !== $headers && array_is_list($headers))) {
            throw new AcdGenericApiMailerConfigurationException('Os cabeçalhos adicionais precisam ser um objeto JSON.');
        }

        $reserved = ['authorization', 'proxy-authorization', 'content-type', 'content-length', 'host', 'x-api-key', 'api-key', 'x-auth-token', 'idempotency-key'];
        $result = [];
        foreach ($headers as $name => $value) {
            $name = (string) $name;
            if (!preg_match('/^[A-Za-z0-9-]{1,80}$/D', $name) || in_array(strtolower($name), $reserved, true)) {
                throw new AcdGenericApiMailerConfigurationException('Um cabeçalho adicional tem nome inválido ou reservado para credenciais.');
            }
            if (!is_string($value) || preg_match('/[\r\n]/', $value)) {
                throw new AcdGenericApiMailerConfigurationException('Os valores dos cabeçalhos adicionais devem ser textos sem quebra de linha.');
            }
            $result[$name] = $value;
        }

        return $result;
    }

    private function acdExtractApiError(string $responseBody): array
    {
        $code = null;
        $requestId = null;
        try {
            $decoded = json_decode($responseBody, true, 512, JSON_THROW_ON_ERROR);
            if (is_array($decoded) && isset($decoded['error']) && is_array($decoded['error'])) {
                $apiError = $decoded['error'];
                if (isset($apiError['code']) && is_string($apiError['code']) && preg_match('/^[A-Za-z0-9_-]{1,80}$/D', $apiError['code'])) {
                    $code = $apiError['code'];
                }
                if (isset($apiError['request_id']) && is_string($apiError['request_id']) && preg_match('/^[A-Za-z0-9_-]{1,100}$/D', $apiError['request_id'])) {
                    $requestId = $apiError['request_id'];
                }
            }
        } catch (JsonException) {
        }

        return ['code' => $code, 'request_id' => $requestId];
    }

    private function acdExtractProviderMessageId(string $responseBody): ?string
    {
        try {
            $decoded = json_decode($responseBody, true, 512, JSON_THROW_ON_ERROR);
            if (is_array($decoded) && isset($decoded['id']) && is_string($decoded['id']) && preg_match('/^[A-Za-z0-9_-]{1,100}$/D', $decoded['id'])) {
                return $decoded['id'];
            }
        } catch (JsonException) {
        }

        return null;
    }
}
