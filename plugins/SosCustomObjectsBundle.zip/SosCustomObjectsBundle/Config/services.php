<?php

declare(strict_types=1);

use Symfony\Component\DependencyInjection\Loader\Configurator\ContainerConfigurator;
use JMS\Serializer\EventDispatcher\Events as JmsEvents;

return static function (ContainerConfigurator $configurator): void {
    $services = $configurator->services()
        ->defaults()
        ->autowire()
        ->autoconfigure()
        ->public(false);

    // Autodiscover plugin classes, but exclude non-class PHP files (config arrays, templates, etc.)
    $services->load('MauticPlugin\\SosCustomObjectsBundle\\', __DIR__.'/../')
        ->exclude([
            __DIR__.'/../Entity/',
            __DIR__.'/../Migrations/',
            __DIR__.'/../Tests/',
            __DIR__.'/../Config/',                 // contains config.php (array), services.php itself
            __DIR__.'/../Views/',                  // PHP templates (not classes)
            __DIR__.'/../Resources/',              // Twig templates
            __DIR__.'/../Security/Permissions/',   // loaded by Mautic permission system, not DI autowire
            __DIR__.'/../DependencyInjection/',    // Extension and CompilerPass are not services
        ]);

    // Controllers must be public and tagged for Mautic routing
    $services->set(MauticPlugin\SosCustomObjectsBundle\Controller\CustomObjectController::class)
        ->public()->tag('mautic.controller');
    $services->set(MauticPlugin\SosCustomObjectsBundle\Controller\CustomFieldController::class)
        ->public()->tag('mautic.controller');
    $services->set(MauticPlugin\SosCustomObjectsBundle\Controller\CustomItemController::class)
        ->public()->tag('mautic.controller');
    $services->set(MauticPlugin\SosCustomObjectsBundle\Controller\ContactCustomItemController::class)
        ->public()->tag('mautic.controller');

    $services->set(MauticPlugin\SosCustomObjectsBundle\Controller\Api\CustomObjectApiController::class)
        ->public()->tag('mautic.controller');
    $services->set(MauticPlugin\SosCustomObjectsBundle\Controller\Api\CustomFieldApiController::class)
        ->public()->tag('mautic.controller');
    $services->set(MauticPlugin\SosCustomObjectsBundle\Controller\Api\CustomItemApiController::class)
        ->public()->tag('mautic.controller');

    // Segment Query Builder (custom service id used by Mautic segment dictionary)
    $services->set(
        MauticPlugin\SosCustomObjectsBundle\Segment\Query\Filter\CustomFieldFilterQueryBuilder::getServiceId(),
        MauticPlugin\SosCustomObjectsBundle\Segment\Query\Filter\CustomFieldFilterQueryBuilder::class
    );

    // JMS Serializer subscriber (API contact payload extension)
    $services->set(MauticPlugin\SosCustomObjectsBundle\EventListener\SerializerSubscriber::class)
        ->tag('jms_serializer.event_subscriber', ['event' => JmsEvents::POST_SERIALIZE]);
};
