<?php

declare(strict_types=1);

namespace MauticPlugin\SosCustomObjectsBundle\Repository;

use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;
use MauticPlugin\SosCustomObjectsBundle\Entity\CustomField;
use MauticPlugin\SosCustomObjectsBundle\Entity\CustomObject;

final class CustomFieldRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, CustomField::class);
    }

    /** @return CustomField[] */
    public function findByObject(CustomObject $object): array
    {
        return $this->createQueryBuilder('f')
            ->andWhere('f.object = :obj')->setParameter('obj', $object)
            ->orderBy('f.id', 'ASC')
            ->getQuery()
            ->getResult();
    }

    public function findOneByObjectAndAlias(CustomObject $object, string $alias): ?CustomField
    {
        return $this->findOneBy(['object' => $object, 'alias' => $alias]);
    }
}
