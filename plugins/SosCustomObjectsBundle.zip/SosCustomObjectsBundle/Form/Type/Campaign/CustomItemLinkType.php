<?php

declare(strict_types=1);

namespace MauticPlugin\SosCustomObjectsBundle\Form\Type\Campaign;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\FormBuilderInterface;

final class CustomItemLinkType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder
            ->add('mode', ChoiceType::class, [
                'label'   => 'Ação',
                'choices' => [
                    'Vincular' => 'link',
                    'Desvincular' => 'unlink',
                ],
                'required' => true,
            ])
            ->add('item_id', IntegerType::class, [
                'label'    => 'ID do Item',
                'required' => true,
            ]);
    }
}
