<?php

declare(strict_types=1);

namespace MauticPlugin\SosCustomObjectsBundle\EventListener;

use Mautic\CoreBundle\CoreEvents;
use Mautic\CoreBundle\Event\MenuEvent;
use MauticPlugin\SosCustomObjectsBundle\Service\CustomObjectService;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

final class MenuSubscriber implements EventSubscriberInterface
{
    public function __construct(
        private CustomObjectService $customObjectService,
    ) {
    }

    public static function getSubscribedEvents(): array
    {
        return [
            CoreEvents::BUILD_MENU => ['onBuildMenu', 9999],
        ];
    }

    public function onBuildMenu(MenuEvent $event): void
    {
        $children = [
            'sos.custom.objects.manage' => [
                'id'        => 'sos_custom_objects_list',
                'route'     => 'sos_custom_objects_list',
                'access'    => 'admin',
                'iconClass' => 'fa-cubes',
                'label'     => 'Gerenciar objetos',
                'priority'  => 100,
            ],
        ];

        try {
            foreach ($this->customObjectService->list() as $object) {
                $id = $object->getId();
                if (null === $id) {
                    continue;
                }

                $children['sos.custom.object.'.$id] = [
                    'id'              => 'sos_custom_items_list_'.$id,
                    'route'           => 'sos_custom_items_list',
                    'routeParameters' => ['objectId' => $id],
                    'access'          => 'admin',
                    'iconClass'       => 'fa-list',
                    'label'           => $object->getName(),
                    'priority'        => 90,
                ];
            }
        } catch (\Throwable) {
            // If database isn't ready yet, avoid breaking the whole menu.
        }

        if ('main' === $event->getType()) {
            $event->addMenuItems([
                'priority' => 61,
                'items' => [
                    'sos.custom.objects' => [
                        'id'        => 'sos_custom_objects_list',
                        'route'     => 'sos_custom_objects_list',
                        'access'    => 'admin',
                        'iconClass' => 'ri-box-3-line',
                        'label'     => 'Custom Objects',
                        'children'  => $children,
                    ],
                ],
            ]);
        }

        if ('admin' === $event->getType()) {
            $event->addMenuItems([
                'priority' => 61,
                'items' => [
                    'sos.custom.objects.admin' => [
                        'id'        => 'sos_custom_objects_list',
                        'route'     => 'sos_custom_objects_list',
                        'access'    => 'admin',
                        'iconClass' => 'ri-box-3-line',
                        'label'     => 'Custom Objects',
                        'children'  => $children,
                    ],
                ],
            ]);
        }
    }
}
