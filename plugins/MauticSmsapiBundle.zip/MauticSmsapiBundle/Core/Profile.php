<?php

namespace MauticPlugin\MauticSmsapiBundle\Core;

class Profile
{
    public float $points;

    public function __construct(float $points = 0.0)
    {
        $this->points = $points;
    }
}
