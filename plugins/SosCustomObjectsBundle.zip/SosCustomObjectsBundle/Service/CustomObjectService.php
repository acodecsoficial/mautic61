<?php

declare(strict_types=1);

namespace MauticPlugin\SosCustomObjectsBundle\Service;

use Doctrine\ORM\EntityManagerInterface;
use MauticPlugin\SosCustomObjectsBundle\Entity\CustomObject;
use MauticPlugin\SosCustomObjectsBundle\Repository\CustomObjectRepository;

final class CustomObjectService
{
    public function __construct(
        private EntityManagerInterface $em,
        private CustomObjectRepository $repo,
    ) {}

    /** @return CustomObject[] */
    public function list(): array
    {
        return $this->repo->findAllOrdered();
    }

    public function get(int $id): ?CustomObject
    {
        return $this->repo->find($id);
    }

    public function getByAlias(string $alias): ?CustomObject
    {
        return $this->repo->findOneByAlias(trim($alias));
    }

    public function create(string $name, string $alias, ?string $description): CustomObject
    {
        $alias = trim($alias);
        if ($alias === '') {
            throw new \InvalidArgumentException('Alias é obrigatório.');
        }

        $existing = $this->repo->findOneByAlias($alias);
        if ($existing) {
            throw new \InvalidArgumentException('Alias já existe: '.$alias);
        }

        $o = new CustomObject();
        $o->setName(trim($name) ?: $alias);
        $o->setAlias($alias);
        $o->setDescription($description);

        $this->em->persist($o);
        $this->em->flush();

        return $o;
    }

    public function update(CustomObject $o, string $name, string $alias, ?string $description): CustomObject
    {
        $alias = trim($alias);
        if ($alias === '') {
            throw new \InvalidArgumentException('Alias é obrigatório.');
        }

        $existing = $this->repo->findOneByAlias($alias);
        if ($existing && $existing->getId() !== $o->getId()) {
            throw new \InvalidArgumentException('Alias já existe: '.$alias);
        }

        $o->setName(trim($name) ?: $alias);
        $o->setAlias($alias);
        $o->setDescription($description);
        $o->touch();

        $this->em->flush();

        return $o;
    }

    public function delete(CustomObject $o): void
    {
        $this->em->remove($o);
        $this->em->flush();
    }
}
