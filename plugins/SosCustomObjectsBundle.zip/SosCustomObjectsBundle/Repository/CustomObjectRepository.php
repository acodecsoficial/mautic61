<?php

declare(strict_types=1);

namespace MauticPlugin\SosCustomObjectsBundle\Repository;

use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;
use MauticPlugin\SosCustomObjectsBundle\Entity\CustomObject;

final class CustomObjectRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, CustomObject::class);
    }

    /** @return CustomObject[] */
    public function findAllOrdered(): array
    {
        return $this->createQueryBuilder('o')
            ->orderBy('o.id', 'DESC')
            ->getQuery()
            ->getResult();
    }

    public function findOneByAlias(string $alias): ?CustomObject
    {
        return $this->findOneBy(['alias' => $alias]);
    }
}
