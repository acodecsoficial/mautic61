(function () {
    'use strict';

    window.Mautic = window.Mautic || {};

    function acdUpdateProfile(acdProfile) {
        var acdAuth = acdProfile.querySelector('select[name$="[auth_type]"]');
        var acdAdapter = acdProfile.querySelector('select[name$="[adapter]"]');
        if (!acdAuth || !acdAdapter) {
            return;
        }

        var acdMode = acdAuth.value;
        acdProfile.querySelectorAll('[data-acd-auth]').forEach(function (acdField) {
            acdField.hidden = acdField.getAttribute('data-acd-auth').split(' ').indexOf(acdMode) === -1;
        });

        var acdTokenLabel = acdProfile.querySelector('.acd-api-auth-token label');
        if (acdTokenLabel) {
            acdTokenLabel.textContent = acdMode === 'api_key' ? 'Chave de API' : 'Token Bearer';
        }

        acdProfile.querySelectorAll('[data-acd-generic]').forEach(function (acdField) {
            acdField.hidden = acdAdapter.value === 'sndr';
        });

        var acdWarning = acdProfile.querySelector('[data-acd-sndr-warning]');
        if (acdWarning) {
            acdWarning.hidden = acdAdapter.value !== 'sndr' || !acdMode || acdMode === 'bearer';
        }
    }

    function acdHandleChange(acdEvent) {
        var acdProfile = acdEvent.target.closest('.acd-api-config .acd-api-profile');
        if (acdProfile) {
            acdUpdateProfile(acdProfile);
        }
    }

    window.Mautic.acdApiMailerOnLoad = function () {
        document.querySelectorAll('.acd-api-config .acd-api-profile').forEach(acdUpdateProfile);
        document.removeEventListener('change', acdHandleChange);
        document.addEventListener('change', acdHandleChange);
        if (window.mQuery) {
            window.mQuery(document).off('change.acdApiMailer', '.acd-api-config select')
                .on('change.acdApiMailer', '.acd-api-config select', acdHandleChange);
        }
    };

    window.Mautic.acdApiMailerOnLoad();
}());
