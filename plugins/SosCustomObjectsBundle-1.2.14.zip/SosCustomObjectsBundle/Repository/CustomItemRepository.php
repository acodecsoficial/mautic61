<?php

declare(strict_types=1);

namespace MauticPlugin\SosCustomObjectsBundle\Repository;

use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;
use MauticPlugin\SosCustomObjectsBundle\Entity\CustomItem;
use MauticPlugin\SosCustomObjectsBundle\Entity\CustomObject;

final class CustomItemRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, CustomItem::class);
    }

    /** @return CustomItem[] */
    public function findByObject(CustomObject $object): array
    {
        return $this->createQueryBuilder('i')
            ->andWhere('i.object = :obj')->setParameter('obj', $object)
            ->orderBy('i.id', 'DESC')
            ->getQuery()
            ->getResult();
    }

    /** @return CustomItem[] */
    public function acdFindPageByObject(CustomObject $object, int $limit, int $offset): array
    {
        return $this->createQueryBuilder('i')
            ->andWhere('i.object = :obj')->setParameter('obj', $object)
            ->orderBy('i.id', 'DESC')
            ->setMaxResults(max(1, $limit))
            ->setFirstResult(max(0, $offset))
            ->getQuery()
            ->getResult();
    }

    public function acdCountByObject(CustomObject $object): int
    {
        return (int) $this->createQueryBuilder('i')
            ->select('COUNT(i.id)')
            ->andWhere('i.object = :obj')->setParameter('obj', $object)
            ->getQuery()
            ->getSingleScalarResult();
    }
}
