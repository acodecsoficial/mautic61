<?php

$view->extend('MauticCoreBundle:Default:content.html.php');

$mode = $view['data']->get('mode', 'new');
$item = $view['data']->get('item');

$title = $mode === 'edit' ? 'Editar Custom Object' : 'Novo Custom Object';
$view['slots']->set('headerTitle', $title);

$name = $item ? $item->getName() : '';
$alias = $item ? $item->getAlias() : '';
$description = $item ? (string) $item->getDescription() : '';
?>

<div class="box-layout">
  <div class="col-md-8">
    <div class="panel panel-default">
      <div class="panel-heading"><h4 class="panel-title"><?php echo $view->escape($title); ?></h4></div>
      <div class="panel-body">
        <form method="post">
          <div class="form-group">
            <label>Nome</label>
            <input class="form-control" name="name" value="<?php echo $view->escape($name); ?>" required />
          </div>

          <div class="form-group">
            <label>Alias (ex: invoice)</label>
            <input class="form-control" name="alias" value="<?php echo $view->escape($alias); ?>" required />
            <small class="text-muted">Use apenas letras, números e underline.</small>
          </div>

          <div class="form-group">
            <label>Descrição</label>
            <textarea class="form-control" name="description" rows="4"><?php echo $view->escape($description); ?></textarea>
          </div>

          <div class="form-group">
            <button class="btn btn-primary">
              <i class="fa fa-save"></i> Salvar
            </button>
            <a class="btn btn-default" href="<?php echo $view['router']->path('sos_custom_objects_list'); ?>">
              Cancelar
            </a>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
