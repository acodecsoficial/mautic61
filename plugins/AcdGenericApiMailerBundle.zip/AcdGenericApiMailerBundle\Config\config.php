<?php

declare(strict_types=1);

use MauticPlugin\AcdGenericApiMailerBundle\Integration\AcdGenericApiMailerIntegration;
use MauticPlugin\AcdGenericApiMailerBundle\Integration\Support\AcdGenericApiMailerConfigSupport;

return [
    'name' => 'Acd Generic API Mailer',
    'description' => 'Transporte de e-mail por APIs HTTP com perfis configuráveis.',
    'version' => '1.0.0',
    'author' => 'Acodecs Tech',
    'services' => [
        'integrations' => [
            'acd.generic_api_mailer.integration' => [
                'class' => AcdGenericApiMailerIntegration::class,
                'tags' => ['mautic.basic_integration'],
            ],
            'acd.generic_api_mailer.config' => [
                'class' => AcdGenericApiMailerConfigSupport::class,
                'tags' => ['mautic.config_integration'],
            ],
        ],
    ],
];