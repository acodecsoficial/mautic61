<?php

$view->extend('MauticCoreBundle:Default:content.html.php');
$view['slots']->set('headerTitle', 'SoSystems Custom Objects');

$items = $view['data']->get('items', []);
?>

<div class="box-layout">
  <div class="col-md-12">
    <div class="toolbar mb-md">
      <a class="btn btn-primary" href="<?php echo $view['router']->path('sos_custom_objects_new'); ?>">
        <i class="fa fa-plus"></i> Novo Custom Object
      </a>
    </div>

    <div class="panel panel-default">
      <div class="panel-heading"><h4 class="panel-title">Custom Objects</h4></div>
      <div class="panel-body">
        <?php if (!$items): ?>
          <p>Nenhum Custom Object cadastrado ainda.</p>
        <?php else: ?>
          <table class="table table-hover table-striped">
            <thead>
              <tr>
                <th>ID</th>
                <th>Nome</th>
                <th>Alias</th>
                <th>Descrição</th>
                <th style="width: 360px;">Ações</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($items as $o): ?>
                <tr>
                  <td><?php echo (int) $o->getId(); ?></td>
                  <td><?php echo $view->escape($o->getName()); ?></td>
                  <td><code><?php echo $view->escape($o->getAlias()); ?></code></td>
                  <td><?php echo $view->escape((string) $o->getDescription()); ?></td>
                  <td>
                    <a class="btn btn-default btn-sm" href="<?php echo $view['router']->path('sos_custom_fields_list', ['objectId' => $o->getId()]); ?>">
                      <i class="fa fa-list"></i> Campos
                    </a>
                    <a class="btn btn-default btn-sm" href="<?php echo $view['router']->path('sos_custom_items_list', ['objectId' => $o->getId()]); ?>">
                      <i class="fa fa-database"></i> Itens
                    </a>
                    <a class="btn btn-default btn-sm" href="<?php echo $view['router']->path('sos_custom_objects_edit', ['id' => $o->getId()]); ?>">
                      <i class="fa fa-pencil"></i> Editar
                    </a>
                    <form method="post" action="<?php echo $view['router']->path('sos_custom_objects_delete', ['id' => $o->getId()]); ?>" style="display:inline;">
                      <button class="btn btn-danger btn-sm" onclick="return confirm('Remover este Custom Object?');">
                        <i class="fa fa-trash"></i> Remover
                      </button>
                    </form>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>
