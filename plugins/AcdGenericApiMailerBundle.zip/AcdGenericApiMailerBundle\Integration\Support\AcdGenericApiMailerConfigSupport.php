<?php

declare(strict_types=1);

namespace MauticPlugin\AcdGenericApiMailerBundle\Integration\Support;

use Mautic\IntegrationsBundle\Integration\DefaultConfigFormTrait;
use Mautic\IntegrationsBundle\Integration\Interfaces\ConfigFormAuthInterface;
use Mautic\IntegrationsBundle\Integration\Interfaces\ConfigFormFeatureSettingsInterface;
use Mautic\IntegrationsBundle\Integration\Interfaces\ConfigFormInterface;
use MauticPlugin\AcdGenericApiMailerBundle\Form\Type\AcdApiAuthType;
use MauticPlugin\AcdGenericApiMailerBundle\Form\Type\AcdApiFeatureSettingsType;
use MauticPlugin\AcdGenericApiMailerBundle\Integration\AcdGenericApiMailerIntegration;

class AcdGenericApiMailerConfigSupport implements ConfigFormInterface, ConfigFormAuthInterface, ConfigFormFeatureSettingsInterface
{
    use DefaultConfigFormTrait;

    public function getName(): string
    {
        return AcdGenericApiMailerIntegration::NAME;
    }

    public function getDisplayName(): string
    {
        return 'Acodecs API Mailer';
    }

    public function getAuthConfigFormName(): string
    {
        return AcdApiAuthType::class;
    }

    public function getFeatureSettingsConfigFormName(): string
    {
        return AcdApiFeatureSettingsType::class;
    }
}