<?php

declare(strict_types=1);

namespace MauticPlugin\SosCustomObjectsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: \MauticPlugin\SosCustomObjectsBundle\Repository\CustomItemRepository::class)]
#[ORM\Table(name: 'sos_custom_item')]
class CustomItem
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private ?int $id = null;

    #[ORM\ManyToOne(targetEntity: CustomObject::class)]
    #[ORM\JoinColumn(name: 'custom_object_id', referencedColumnName: 'id', nullable: false, onDelete: 'CASCADE')]
    private CustomObject $object;

    // Optional human identifier (e.g. invoice number)
    #[ORM\Column(type: 'string', length: 191, nullable: true)]
    private ?string $label = null;

    #[ORM\Column(name: 'date_added', type: 'datetime_immutable')]
    private \DateTimeImmutable $dateAdded;

    #[ORM\Column(name: 'date_modified', type: 'datetime_immutable', nullable: true)]
    private ?\DateTimeImmutable $dateModified = null;

    public function __construct(CustomObject $object)
    {
        $this->object = $object;
        $this->dateAdded = new \DateTimeImmutable('now');
    }

    public function getId(): ?int { return $this->id; }
    public function getObject(): CustomObject { return $this->object; }

    public function getLabel(): ?string { return $this->label; }
    public function setLabel(?string $label): self { $this->label = $label; return $this; }

    public function getDateAdded(): \DateTimeImmutable { return $this->dateAdded; }
    public function touch(): void { $this->dateModified = new \DateTimeImmutable('now'); }
    public function getDateModified(): ?\DateTimeImmutable { return $this->dateModified; }
}
