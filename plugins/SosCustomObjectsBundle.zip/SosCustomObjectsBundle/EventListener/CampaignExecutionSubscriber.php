<?php

declare(strict_types=1);

namespace MauticPlugin\SosCustomObjectsBundle\EventListener;

use Mautic\CampaignBundle\Event\PendingEvent;
use Mautic\CampaignBundle\Event\ConditionEvent;
use MauticPlugin\SosCustomObjectsBundle\SosCustomObjectsEvents;
use MauticPlugin\SosCustomObjectsBundle\Service\CampaignCustomItemService;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

final class CampaignExecutionSubscriber implements EventSubscriberInterface
{
    public function __construct(
        private CampaignCustomItemService $service,
    ) {}

    public static function getSubscribedEvents(): array
    {
        return [
            SosCustomObjectsEvents::EXECUTE_CAMPAIGN_ACTION     => ['onAction', 0],
            SosCustomObjectsEvents::EVALUATE_CAMPAIGN_CONDITION => ['onCondition', 0],
        ];
    }

    public function onAction(PendingEvent $event): void
    {
        if (!$event->checkContext(CampaignSubscriber::ACTION_TYPE)) {
            return;
        }

        $config = $event->getEventConfig();
        $mode   = (string) $config->get('mode', 'link');
        $itemId = (int) $config->get('item_id', 0);

        if ($itemId <= 0) {
            $event->failAll('Item ID inválido.');
            return;
        }

        foreach ($event->getContacts() as $contact) {
            $log = $event->getLog($contact);
            try {
                if ('unlink' === $mode) {
                    $this->service->unlink((int)$contact['id'], $itemId);
                } else {
                    $this->service->link((int)$contact['id'], $itemId);
                }
                $event->pass($log);
            } catch (\Throwable $e) {
                $event->fail($log, $e->getMessage());
            }
        }
    }

    public function onCondition(ConditionEvent $event): void
    {
        if (!$event->checkContext(CampaignSubscriber::CONDITION_TYPE)) {
            return;
        }

        $cfg = $event->getEventConfig();
        $objectId = (int) $cfg->get('object_id', 0);
        $fieldAlias = (string) $cfg->get('field_alias', '');
        $operator = (string) $cfg->get('operator', '=');
        $value = (string) $cfg->get('value', '');

        try {
            $ok = $this->service->evaluateCondition(
                (int) $event->getLog()->getLead()->getId(),
                $objectId ?: null,
                $fieldAlias,
                $operator,
                $value
            );

            if ($ok) {
                $event->pass();
            } else {
                $event->fail();
            }
        } catch (\Throwable $e) {
            $event->fail();
        }
    }
}
