<?php

declare(strict_types=1);

namespace Symfony\Component\Mime {
    class Address
    {
        public function __construct(private string $address, private string $name = '')
        {
        }

        public function getAddress(): string
        {
            return $this->address;
        }

        public function __toString(): string
        {
            return '' === $this->name ? $this->address : '"'.$this->name.'" <'.$this->address.'>';
        }
    }

    class HeaderCollection
    {
        public function __construct(private array $headers = [])
        {
        }

        public function all(): array
        {
            return $this->headers;
        }
    }

    class Email
    {
        public function __construct(
            private array $from,
            private array $to,
            private array $cc = [],
            private array $bcc = [],
            private array $replyTo = [],
            private string $subject = 'Assunto de teste',
            private ?string $html = '<p>Olá</p>',
            private ?string $text = 'Olá',
            private array $headers = [],
            private array $attachments = [],
        ) {
        }

        public function getFrom(): array
        {
            return $this->from;
        }

        public function getTo(): array
        {
            return $this->to;
        }

        public function getCc(): array
        {
            return $this->cc;
        }

        public function getBcc(): array
        {
            return $this->bcc;
        }

        public function getReplyTo(): array
        {
            return $this->replyTo;
        }

        public function getSubject(): string
        {
            return $this->subject;
        }

        public function getHtmlBody(): ?string
        {
            return $this->html;
        }

        public function getTextBody(): ?string
        {
            return $this->text;
        }

        public function getHeaders(): HeaderCollection
        {
            return new HeaderCollection($this->headers);
        }

        public function getAttachments(): array
        {
            return $this->attachments;
        }
    }
}

namespace Symfony\Component\Mime\Header {
    class UnstructuredHeader
    {
        public function __construct(private string $name, private string $body)
        {
        }

        public function getName(): string
        {
            return $this->name;
        }

        public function getBody(): string
        {
            return $this->body;
        }
    }
}

namespace Symfony\Component\Mime\Part {
    class DataPart
    {
        public function __construct(private string $body, private ?string $filename, private string $contentType, private string $disposition = 'attachment')
        {
        }

        public function getBody(): string
        {
            return $this->body;
        }

        public function getFilename(): ?string
        {
            return $this->filename;
        }

        public function getContentType(): string
        {
            return $this->contentType;
        }

        public function getDisposition(): string
        {
            return $this->disposition;
        }
    }
}

namespace {
    require dirname(__DIR__).'/Exception/AcdGenericApiMailerConfigurationException.php';
    require dirname(__DIR__).'/Service/AcdPayloadMappingService.php';
    require dirname(__DIR__).'/Mailer/Transport/AcdMessagePayloadFactory.php';

    use MauticPlugin\AcdGenericApiMailerBundle\Exception\AcdGenericApiMailerConfigurationException;
    use MauticPlugin\AcdGenericApiMailerBundle\Mailer\Transport\AcdMessagePayloadFactory;
    use MauticPlugin\AcdGenericApiMailerBundle\Service\AcdPayloadMappingService;
    use Symfony\Component\Mime\Address;
    use Symfony\Component\Mime\Email;
    use Symfony\Component\Mime\Header\UnstructuredHeader;
    use Symfony\Component\Mime\Part\DataPart;

    function acdAssertSame(mixed $expected, mixed $actual, string $name): void
    {
        if ($expected !== $actual) {
            throw new RuntimeException($name.' falhou. Esperado: '.var_export($expected, true).'; recebido: '.var_export($actual, true));
        }
    }

    function acdAssertThrows(callable $callback, string $name): void
    {
        try {
            $callback();
        } catch (AcdGenericApiMailerConfigurationException) {
            return;
        }

        throw new RuntimeException($name.' deveria lançar AcdGenericApiMailerConfigurationException.');
    }

    $mappingService = new AcdPayloadMappingService();
    $payloadFactory = new AcdMessagePayloadFactory($mappingService);
    $email = new Email(
        [new Address('envio@exemplo.com', 'Acodecs')],
        [new Address('destino@exemplo.com'), new Address('outro@exemplo.com')],
        [new Address('copia@exemplo.com')],
        [new Address('oculta@exemplo.com')],
        [new Address('resposta@exemplo.com')],
        'Confirmação',
        '<p>Olá, <strong>cliente</strong>.</p>',
        'Olá, cliente.',
        [new UnstructuredHeader('X-Campaign', 'campanha-1'), new UnstructuredHeader('Subject', 'Assunto original')],
        [new DataPart('conteudo-binario', 'arquivo.txt', 'text/plain')],
    );

    $sndrPayload = $payloadFactory->acdBuildPayload($email, ['adapter' => 'sndr']);
    acdAssertSame('"Acodecs" <envio@exemplo.com>', $sndrPayload['from'], 'remetente SNDR');
    acdAssertSame(['destino@exemplo.com', 'outro@exemplo.com'], $sndrPayload['to'], 'destinatários SNDR');
    acdAssertSame(['copia@exemplo.com'], $sndrPayload['cc'], 'cópia SNDR');
    acdAssertSame(['oculta@exemplo.com'], $sndrPayload['bcc'], 'cópia oculta SNDR');
    acdAssertSame('Confirmação', $sndrPayload['subject'], 'assunto SNDR');
    acdAssertSame('<p>Olá, <strong>cliente</strong>.</p>', $sndrPayload['html'], 'corpo HTML SNDR');
    acdAssertSame('Olá, cliente.', $sndrPayload['text'], 'corpo texto SNDR');
    acdAssertSame(['X-Campaign' => 'campanha-1'], get_object_vars($sndrPayload['headers']), 'cabeçalhos SNDR');
    acdAssertSame(base64_encode('conteudo-binario'), $sndrPayload['attachments'][0]['content'], 'anexo SNDR');

    $genericMapping = '{"sender":"{{from}}","recipients":"{{to}}","subject":"{{subject}}","body":{"html":"{{html}}","text":"{{text}}"}}';
    $genericPayload = $payloadFactory->acdBuildPayload($email, ['adapter' => 'generic_json', 'payload_mapping_json' => $genericMapping]);
    acdAssertSame(['destino@exemplo.com', 'outro@exemplo.com'], $genericPayload['recipients'], 'mapeamento de lista genérico');
    acdAssertSame('<p>Olá, <strong>cliente</strong>.</p>', $genericPayload['body']['html'], 'mapeamento HTML genérico');
    acdAssertSame('Confirmação', $genericPayload['subject'], 'mapeamento de assunto genérico');

    acdAssertThrows(
        static fn () => $mappingService->acdMapPayload('{"to":"{{destinatario_inexistente}}"}', ['to' => []]),
        'placeholder desconhecido',
    );
    acdAssertThrows(
        static fn () => $mappingService->acdMapPayload('{invalid json}', ['to' => []]),
        'JSON inválido',
    );
    acdAssertThrows(
        static fn () => $payloadFactory->acdBuildPayload(
            new Email([new Address('envio@exemplo.com')], [new Address('destino@exemplo.com')], attachments: [new DataPart('imagem-inline', 'imagem.png', 'image/png', 'inline')]),
            ['adapter' => 'sndr'],
        ),
        'anexo inline não suportado',
    );
    acdAssertThrows(
        static fn () => $payloadFactory->acdBuildPayload(
            new Email([], [new Address('destino@exemplo.com')]),
            ['adapter' => 'sndr'],
        ),
        'remetente ausente',
    );
    acdAssertThrows(
        static fn () => $payloadFactory->acdBuildPayload(
            new Email(
                [new Address('envio@exemplo.com')],
                [new Address('destino@exemplo.com')],
                array_fill(0, 101, new Address('copia@exemplo.com')),
            ),
            ['adapter' => 'sndr'],
        ),
        'limite de endereços CC do SNDR',
    );

    fwrite(STDOUT, "7 verificações passaram.\n");
}
