<?php

$view->extend('MauticCoreBundle:Default:content.html.php');

$object = $view['data']->get('object');
$items  = $view['data']->get('items', []);
$fields = $view['data']->get('fields', []);

$view['slots']->set('headerTitle', 'Itens - '.$view->escape($object->getName()));
?>

<div class="box-layout">
  <div class="col-md-12">
    <div class="toolbar mb-md">
      <a class="btn btn-default" href="<?php echo $view['router']->path('sos_custom_objects_list'); ?>">
        <i class="fa fa-arrow-left"></i> Voltar
      </a>
      <a class="btn btn-default" href="<?php echo $view['router']->path('sos_custom_fields_list', ['objectId' => $object->getId()]); ?>">
        <i class="fa fa-list"></i> Campos
      </a>
      <a class="btn btn-primary" href="<?php echo $view['router']->path('sos_custom_items_new', ['objectId' => $object->getId()]); ?>">
        <i class="fa fa-plus"></i> Novo Item
      </a>
    </div>

    <div class="panel panel-default">
      <div class="panel-heading"><h4 class="panel-title">Itens</h4></div>
      <div class="panel-body">
        <?php if (!$items): ?>
          <p>Nenhum item cadastrado ainda.</p>
        <?php else: ?>
          <table class="table table-hover table-striped">
            <thead>
              <tr>
                <th>ID</th>
                <th>Label</th>
                <th>Data</th>
                <th style="width: 220px;">Ações</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($items as $it): ?>
                <tr>
                  <td><?php echo (int) $it->getId(); ?></td>
                  <td><?php echo $view->escape((string) $it->getLabel()); ?></td>
                  <td><?php echo $view->escape($it->getDateAdded()->format('Y-m-d H:i')); ?></td>
                  <td>
                    <a class="btn btn-default btn-sm" href="<?php echo $view['router']->path('sos_custom_items_edit', ['objectId' => $object->getId(), 'id' => $it->getId()]); ?>">
                      <i class="fa fa-pencil"></i> Editar
                    </a>
                    <form method="post" action="<?php echo $view['router']->path('sos_custom_items_delete', ['objectId' => $object->getId(), 'id' => $it->getId()]); ?>" style="display:inline;">
                      <button class="btn btn-danger btn-sm" onclick="return confirm('Remover este item?');">
                        <i class="fa fa-trash"></i> Remover
                      </button>
                    </form>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
          <p class="text-muted">Obs: os valores dos campos aparecem na tela de edição do item (v1.1.0).</p>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>
