<?php

declare(strict_types=1);

namespace MauticPlugin\SosCustomObjectsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: \MauticPlugin\SosCustomObjectsBundle\Repository\CustomItemValueRepository::class)]
#[ORM\Table(name: 'sos_custom_item_value')]
#[ORM\UniqueConstraint(name: 'uniq_sos_item_field', columns: ['custom_item_id','custom_field_id'])]
class CustomItemValue
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private ?int $id = null;

    #[ORM\ManyToOne(targetEntity: CustomItem::class)]
    #[ORM\JoinColumn(name: 'custom_item_id', referencedColumnName: 'id', nullable: false, onDelete: 'CASCADE')]
    private CustomItem $item;

    #[ORM\ManyToOne(targetEntity: CustomField::class)]
    #[ORM\JoinColumn(name: 'custom_field_id', referencedColumnName: 'id', nullable: false, onDelete: 'CASCADE')]
    private CustomField $field;

    // Store a normalized string (for text/select/date)
    #[ORM\Column(type: 'text', nullable: true)]
    private ?string $valueText = null;

    #[ORM\Column(type: 'float', nullable: true)]
    private ?float $valueNumber = null;

    #[ORM\Column(type: 'datetime', nullable: true)]
    private ?\DateTimeInterface $valueDate = null;

    #[ORM\Column(type: 'boolean', nullable: true)]
    private ?bool $valueBool = null;

    public function __construct(CustomItem $item, CustomField $field)
    {
        $this->item  = $item;
        $this->field = $field;
    }

    public function getId(): ?int { return $this->id; }
    public function getItem(): CustomItem { return $this->item; }
    public function getField(): CustomField { return $this->field; }

    public function setValueText(?string $v): self { $this->valueText = $v; return $this; }
    public function getValueText(): ?string { return $this->valueText; }

    public function setValueNumber(?float $v): self { $this->valueNumber = $v; return $this; }
    public function getValueNumber(): ?float { return $this->valueNumber; }

    public function setValueDate(?\DateTimeInterface $v): self { $this->valueDate = $v; return $this; }
    public function getValueDate(): ?\DateTimeInterface { return $this->valueDate; }

    public function setValueBool(?bool $v): self { $this->valueBool = $v; return $this; }
    public function getValueBool(): ?bool { return $this->valueBool; }
}
