<?php

use MauticPlugin\AcodecsWhitelabelBundle\EventListener\AcdBrandingSubscriber;

return [
    'name'        => 'Acodecs Whitelabel',
    'description' => 'Substitui a logo e branding do Mautic pela identidade visual da Acodecs.',
    'author'      => 'Acodecs',
    'version'     => '1.0.0',
    'services'    => [
        'events' => [
            'acd.whitelabel.branding_subscriber' => [
                'class' => AcdBrandingSubscriber::class,
                'tag'   => 'kernel.event_subscriber',
            ],
        ],
    ],
];
