<?php

declare(strict_types=1);

namespace MauticPlugin\SosCustomObjectsBundle\Controller\Api;

use MauticPlugin\SosCustomObjectsBundle\Service\CustomObjectService;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\RequestStack;
use Symfony\Component\HttpFoundation\Response;

final class CustomObjectApiController
{
    public function __construct(
        private CustomObjectService $customObjectService,
        private RequestStack $requestStack,
    ) {}

    public function listAction(): JsonResponse
    {
        $items = array_map(fn($o) => $this->serialize($o), $this->customObjectService->list());
        return new JsonResponse(['total' => count($items), 'items' => $items]);
    }

    public function getAction(int $id): JsonResponse
    {
        $o = $this->customObjectService->get($id);
        if (!$o) {
            return new JsonResponse(['error' => 'Not found'], Response::HTTP_NOT_FOUND);
        }
        return new JsonResponse($this->serialize($o));
    }

    public function createAction(): JsonResponse
    {
        $request = $this->getCurrentRequest();
        $data = json_decode((string) $request->getContent(), true) ?: [];

        try {
            $o = $this->customObjectService->create(
                (string)($data['name'] ?? ''),
                (string)($data['alias'] ?? ''),
                isset($data['description']) ? (string)$data['description'] : null
            );
            return new JsonResponse($this->serialize($o), Response::HTTP_CREATED);
        } catch (\Throwable $e) {
            return new JsonResponse(['error' => $e->getMessage()], Response::HTTP_BAD_REQUEST);
        }
    }

    public function updateAction(int $id): JsonResponse
    {
        $request = $this->getCurrentRequest();
        $data = json_decode((string) $request->getContent(), true) ?: [];

        $o = $this->customObjectService->get($id);
        if (!$o) {
            return new JsonResponse(['error' => 'Not found'], Response::HTTP_NOT_FOUND);
        }

        try {
            $o = $this->customObjectService->update(
                $o,
                (string)($data['name'] ?? $o->getName()),
                (string)($data['alias'] ?? $o->getAlias()),
                array_key_exists('description', $data) ? (string)$data['description'] : $o->getDescription()
            );
            return new JsonResponse($this->serialize($o));
        } catch (\Throwable $e) {
            return new JsonResponse(['error' => $e->getMessage()], Response::HTTP_BAD_REQUEST);
        }
    }

    public function deleteAction(int $id): JsonResponse
    {
        $o = $this->customObjectService->get($id);
        if (!$o) {
            return new JsonResponse(['error' => 'Not found'], Response::HTTP_NOT_FOUND);
        }

        $this->customObjectService->delete($o);
        return new JsonResponse(null, Response::HTTP_NO_CONTENT);
    }

    private function getCurrentRequest(): Request
    {
        $request = $this->requestStack->getCurrentRequest();
        if (null === $request) {
            throw new \RuntimeException('Request is not set.');
        }
        return $request;
    }

    private function serialize($o): array
    {
        return [
            'id' => $o->getId(),
            'name' => $o->getName(),
            'alias' => $o->getAlias(),
            'description' => $o->getDescription(),
            'dateAdded' => $o->getDateAdded()->format(DATE_ATOM),
            'dateModified' => $o->getDateModified()?->format(DATE_ATOM),
        ];
    }
}
