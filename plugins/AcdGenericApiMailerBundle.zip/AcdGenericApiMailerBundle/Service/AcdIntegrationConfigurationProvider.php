<?php

declare(strict_types=1);

namespace MauticPlugin\AcdGenericApiMailerBundle\Service;

use Doctrine\ORM\EntityManagerInterface;
use Mautic\IntegrationsBundle\Facade\EncryptionService;
use Mautic\PluginBundle\Entity\Integration;
use MauticPlugin\AcdGenericApiMailerBundle\Exception\AcdGenericApiMailerConfigurationException;
use MauticPlugin\AcdGenericApiMailerBundle\Integration\AcdGenericApiMailerIntegration;
use Throwable;

class AcdIntegrationConfigurationProvider
{
    public function __construct(
        private EntityManagerInterface $entityManager,
        private EncryptionService $encryptionService,
    ) {
    }

    public function acdGetActiveProfile(): array
    {
        $repository = $this->entityManager->getRepository(Integration::class);
        $integration = $repository->findOneBy(['name' => AcdGenericApiMailerIntegration::NAME]);

        if (!$integration instanceof Integration) {
            throw new AcdGenericApiMailerConfigurationException('A integração Acodecs API Mailer ainda não foi configurada no Mautic.');
        }

        $this->entityManager->refresh($integration);

        if (!$integration->isPublished()) {
            throw new AcdGenericApiMailerConfigurationException('Ative a integração Acodecs API Mailer antes de enviar e-mails.');
        }

        $allFeatureSettings = $integration->getFeatureSettings();
        $settings = is_array($allFeatureSettings) ? $allFeatureSettings : [];
        if (isset($settings['integration']) && is_array($settings['integration'])) {
            $settings = $settings['integration'];
        }
        if ([] === $settings) {
            throw new AcdGenericApiMailerConfigurationException('As configurações de envio da integração estão inválidas.');
        }

        $activeProfile = $settings['active_profile'] ?? 'profile_1';
        if (!in_array($activeProfile, ['profile_1', 'profile_2', 'profile_3'], true)) {
            throw new AcdGenericApiMailerConfigurationException('O perfil ativo selecionado não existe.');
        }

        $profile = $settings[$activeProfile] ?? null;
        if (!is_array($profile)) {
            throw new AcdGenericApiMailerConfigurationException('Configure o perfil ativo na tela Acodecs API Mailer.');
        }

        $profileName = trim((string) ($profile['name'] ?? ''));
        if ('' === $profileName || strlen($profileName) > 80 || preg_match('/[\r\n]/', $profileName)) {
            throw new AcdGenericApiMailerConfigurationException('Informe um nome válido para o perfil ativo.');
        }

        $adapter = (string) ($profile['adapter'] ?? '');
        if (!in_array($adapter, ['sndr', 'generic_json'], true)) {
            throw new AcdGenericApiMailerConfigurationException('Selecione SNDR ou HTTP JSON genérico no perfil ativo.');
        }

        $endpoint = trim((string) ($profile['endpoint'] ?? ''));
        if ('sndr' === $adapter && '' === $endpoint) {
            $endpoint = 'https://api.sndr.sh/v1/send';
        }
        $this->acdValidateEndpoint($endpoint, 'sndr' === $adapter);

        $authType = (string) ($profile['auth_type'] ?? '');
        if ('sndr' === $adapter && 'bearer' !== $authType) {
            throw new AcdGenericApiMailerConfigurationException('O adaptador SNDR exige autenticação Bearer.');
        }
        if (!in_array($authType, ['bearer', 'basic', 'api_key', 'none'], true)) {
            throw new AcdGenericApiMailerConfigurationException('Selecione um tipo de autenticação válido no perfil ativo.');
        }

        try {
            $encryptedApiKeys = $integration->getApiKeys();
            $apiKeys = is_array($encryptedApiKeys) ? $this->encryptionService->decrypt($encryptedApiKeys) : [];
        } catch (Throwable $exception) {
            throw new AcdGenericApiMailerConfigurationException('Não foi possível ler as credenciais criptografadas do perfil ativo.', 0, $exception);
        }
        if (!is_array($apiKeys)) {
            throw new AcdGenericApiMailerConfigurationException('As credenciais do perfil ativo estão inválidas.');
        }

        $token = (string) ($apiKeys[$activeProfile.'_token'] ?? '');
        $username = (string) ($apiKeys[$activeProfile.'_username'] ?? '');
        $password = (string) ($apiKeys[$activeProfile.'_password'] ?? '');

        if ('bearer' === $authType && '' === trim($token)) {
            throw new AcdGenericApiMailerConfigurationException('Informe o token Bearer no campo de credenciais do perfil ativo.');
        }
        if ('api_key' === $authType && '' === trim($token)) {
            throw new AcdGenericApiMailerConfigurationException('Informe a chave API no campo de credenciais do perfil ativo.');
        }
        if ('basic' === $authType && ('' === trim($username) || '' === trim($password))) {
            throw new AcdGenericApiMailerConfigurationException('Informe usuário e senha HTTP Basic nas credenciais do perfil ativo.');
        }
        if ('basic' === $authType && preg_match('/[:\x00-\x1F\x7F]/', $username)) {
            throw new AcdGenericApiMailerConfigurationException('O usuário HTTP Basic não pode conter dois-pontos ou caracteres de controle.');
        }

        $timeout = filter_var($profile['timeout'] ?? 30, FILTER_VALIDATE_INT);
        if (false === $timeout || $timeout < 1 || $timeout > 120) {
            throw new AcdGenericApiMailerConfigurationException('O timeout do perfil deve estar entre 1 e 120 segundos.');
        }

        $apiKeyHeader = trim((string) ($profile['api_key_header'] ?? 'X-API-Key'));
        $reservedApiKeyHeaders = ['accept', 'authorization', 'proxy-authorization', 'content-type', 'content-length', 'host', 'idempotency-key', 'transfer-encoding', 'connection'];
        if ('api_key' === $authType && (!preg_match('/^[A-Za-z0-9-]{1,80}$/D', $apiKeyHeader) || in_array(strtolower($apiKeyHeader), $reservedApiKeyHeaders, true))) {
            throw new AcdGenericApiMailerConfigurationException('Informe um nome válido para o cabeçalho da chave API.');
        }

        return [
            'name' => $profileName,
            'slot' => $activeProfile,
            'adapter' => $adapter,
            'endpoint' => $endpoint,
            'auth_type' => $authType,
            'token' => $token,
            'username' => $username,
            'password' => $password,
            'api_key_header' => $apiKeyHeader,
            'timeout' => $timeout,
            'headers_json' => (string) ($profile['headers_json'] ?? '{}'),
            'payload_mapping_json' => (string) ($profile['payload_mapping_json'] ?? ''),
        ];
    }

    private function acdValidateEndpoint(string $endpoint, bool $isSndr): void
    {
        $parts = parse_url($endpoint);
        if (false === $parts || !filter_var($endpoint, FILTER_VALIDATE_URL) || 'https' !== strtolower((string) ($parts['scheme'] ?? '')) || empty($parts['host'])) {
            throw new AcdGenericApiMailerConfigurationException('O endpoint precisa ser uma URL HTTPS válida.');
        }

        if (isset($parts['user']) || isset($parts['pass']) || isset($parts['query']) || isset($parts['fragment'])) {
            throw new AcdGenericApiMailerConfigurationException('Não coloque usuário, senha, parâmetros secretos ou fragmentos na URL do endpoint.');
        }

        if (isset($parts['port']) && 443 !== (int) $parts['port']) {
            throw new AcdGenericApiMailerConfigurationException('O endpoint HTTPS deve usar a porta padrão 443.');
        }

        $host = strtolower(rtrim((string) $parts['host'], '.'));
        if ('localhost' === $host || str_ends_with($host, '.localhost') || str_ends_with($host, '.local') || str_ends_with($host, '.internal')) {
            throw new AcdGenericApiMailerConfigurationException('O endpoint não pode apontar para um host local ou interno.');
        }

        if (filter_var($host, FILTER_VALIDATE_IP) && !filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
            throw new AcdGenericApiMailerConfigurationException('O endpoint não pode apontar para um endereço IP privado ou reservado.');
        }

        if ($isSndr && ('api.sndr.sh' !== $host || '/v1/send' !== (string) ($parts['path'] ?? ''))) {
            throw new AcdGenericApiMailerConfigurationException('O perfil SNDR deve usar https://api.sndr.sh/v1/send.');
        }
    }
}
