<?php

declare(strict_types=1);

namespace MauticPlugin\AcdGenericApiMailerBundle\Exception;

use RuntimeException;

class AcdGenericApiMailerConfigurationException extends RuntimeException
{
}