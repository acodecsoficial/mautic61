<?php

declare(strict_types=1);

namespace MauticPlugin\SosCustomObjectsBundle\Controller;

use Doctrine\Persistence\ManagerRegistry;
use Mautic\CoreBundle\Controller\CommonController;
use Mautic\CoreBundle\Factory\ModelFactory;
use Mautic\CoreBundle\Helper\CoreParametersHelper;
use Mautic\CoreBundle\Helper\InputHelper;
use Mautic\CoreBundle\Helper\UserHelper;
use Mautic\CoreBundle\Security\Permissions\CorePermissions;
use Mautic\CoreBundle\Service\FlashBag;
use Mautic\CoreBundle\Translation\Translator;
use MauticPlugin\SosCustomObjectsBundle\Service\CustomItemContactUiService;
use Symfony\Component\EventDispatcher\EventDispatcherInterface;
use Symfony\Component\HttpFoundation\RequestStack;
use Symfony\Component\HttpFoundation\Response;

final class ContactCustomItemController extends CommonController
{
    public function __construct(
        ManagerRegistry $doctrine,
        ModelFactory $modelFactory,
        UserHelper $userHelper,
        CoreParametersHelper $coreParametersHelper,
        EventDispatcherInterface $dispatcher,
        Translator $translator,
        FlashBag $flashBag,
        RequestStack $requestStack,
        CorePermissions $security,
        private CustomItemContactUiService $ui,
    ) {
        parent::__construct(
            $doctrine,
            $modelFactory,
            $userHelper,
            $coreParametersHelper,
            $dispatcher,
            $translator,
            $flashBag,
            $requestStack,
            $security
        );
    }

    public function manageAction(int $leadId): Response
    {
        $request = $this->getCurrentRequest();

        // Permission: view items + link
        if (!$this->security->isGranted('plugin:sosCustomObjects:customItems:view')) {
            return $this->accessDenied();
        }

        if ($request->isMethod('POST')) {
            if (!$this->security->isGranted('plugin:sosCustomObjects:customItems:edit')) {
                return $this->accessDenied();
            }

            $action = InputHelper::clean($request->request->get('action', ''));
            $itemId  = (int) $request->request->get('item_id', 0);

            try {
                if ('link' === $action && $itemId > 0) {
                    $this->ui->link($leadId, $itemId);
                    $this->addFlashMessage('Item vinculado ao contato.');
                } elseif ('unlink' === $action && $itemId > 0) {
                    $this->ui->unlink($leadId, $itemId);
                    $this->addFlashMessage('Vínculo removido.');
                }
            } catch (\Throwable $e) {
                $this->addFlashMessage('Erro: '.$e->getMessage(), [], FlashBag::LEVEL_ERROR);
            }

            return $this->redirectToRoute('sos_contact_custom_items_manage', ['leadId' => $leadId]);
        }

        return $this->delegateView([
            'viewParameters' => [
                'leadId'        => $leadId,
                'linkedByObject'=> $this->ui->getLinkedItemsGrouped($leadId),
                'objects'       => $this->ui->getObjects(),
                'itemsByObject' => $this->ui->getItemsByObject(),
            ],
            'contentTemplate' => '@SosCustomObjectsBundle/ContactCustomItem/manage.html.twig',
            'passthroughVars' => [
                'mauticContent' => 'contactCustomItems',
                'route'         => $this->generateUrl('sos_contact_custom_items_manage', ['leadId' => $leadId]),
            ],
        ]);
    }
}
