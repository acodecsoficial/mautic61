<?php

declare(strict_types=1);

namespace MauticPlugin\SosCustomObjectsBundle\Migrations;

use Doctrine\DBAL\Schema\Schema;
use Mautic\IntegrationsBundle\Migration\AbstractMigration;

final class Version_1_0_0 extends AbstractMigration
{
    protected function isApplicable(Schema $schema): bool
    {
        return !$schema->hasTable($this->concatPrefix('sos_custom_object'));
    }

    protected function up(): void
    {
        $table = $this->concatPrefix('sos_custom_object');

        $this->addSql("
            CREATE TABLE `$table` (
              `id` INT AUTO_INCREMENT NOT NULL,
              `name` VARCHAR(191) NOT NULL,
              `alias` VARCHAR(191) NOT NULL,
              `description` LONGTEXT DEFAULT NULL,
              `date_added` DATETIME NOT NULL,
              `date_modified` DATETIME DEFAULT NULL,
              UNIQUE KEY `uniq_sos_custom_object_alias` (`alias`),
              PRIMARY KEY(`id`)
            ) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB
        ");
    }
}
