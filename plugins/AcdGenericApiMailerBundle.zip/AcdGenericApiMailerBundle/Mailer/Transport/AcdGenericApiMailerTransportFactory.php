<?php

declare(strict_types=1);

namespace MauticPlugin\AcdGenericApiMailerBundle\Mailer\Transport;

use InvalidArgumentException;
use MauticPlugin\AcdGenericApiMailerBundle\Service\AcdIntegrationConfigurationProvider;
use MauticPlugin\AcdGenericApiMailerBundle\Service\AcdPayloadMappingService;
use Psr\Log\LoggerInterface;
use Symfony\Component\EventDispatcher\EventDispatcherInterface;
use Symfony\Component\Mailer\Transport\AbstractTransportFactory;
use Symfony\Component\Mailer\Transport\Dsn;
use Symfony\Component\Mailer\Transport\TransportInterface;
use Symfony\Contracts\HttpClient\HttpClientInterface;

class AcdGenericApiMailerTransportFactory extends AbstractTransportFactory
{
    public function __construct(
        EventDispatcherInterface $dispatcher,
        HttpClientInterface $client,
        private AcdIntegrationConfigurationProvider $configurationProvider,
        private AcdMessagePayloadFactory $payloadFactory,
        private AcdPayloadMappingService $payloadMappingService,
        private LoggerInterface $logger,
    ) {
        parent::__construct($dispatcher, $client);
    }

    public function create(Dsn $dsn): TransportInterface
    {
        if ('generic-api' !== $dsn->getScheme() || 'default' !== $dsn->getHost() || null !== $dsn->getUser() || null !== $dsn->getPassword() || [] !== $dsn->getOptions()) {
            throw new InvalidArgumentException('Configure o Email DSN como generic-api://default.');
        }

        return new AcdGenericApiMailerTransport(
            $this->dispatcher,
            $this->client,
            $this->configurationProvider,
            $this->payloadFactory,
            $this->payloadMappingService,
            $this->logger,
        );
    }

    protected function getSupportedSchemes(): array
    {
        return ['generic-api'];
    }
}