<?php

declare(strict_types=1);

use MauticPlugin\AcdGenericApiMailerBundle\Mailer\Transport\AcdMessagePayloadFactory;
use MauticPlugin\AcdGenericApiMailerBundle\Service\AcdIntegrationConfigurationProvider;
use MauticPlugin\AcdGenericApiMailerBundle\Service\AcdPayloadMappingService;
use MauticPlugin\AcdGenericApiMailerBundle\Mailer\Transport\AcdGenericApiMailerTransportFactory;
use Symfony\Component\DependencyInjection\Loader\Configurator\ContainerConfigurator;

return function (ContainerConfigurator $configurator): void {
    $services = $configurator->services()
        ->defaults()
        ->autowire()
        ->autoconfigure()
        ->public();

    $services->set(AcdIntegrationConfigurationProvider::class);
    $services->set(AcdPayloadMappingService::class);
    $services->set(AcdMessagePayloadFactory::class);

    $services->set(AcdGenericApiMailerTransportFactory::class)
        ->tag('mailer.transport_factory');
};
