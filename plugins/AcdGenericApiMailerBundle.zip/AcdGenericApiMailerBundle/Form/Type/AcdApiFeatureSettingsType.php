<?php

declare(strict_types=1);

namespace MauticPlugin\AcdGenericApiMailerBundle\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class AcdApiFeatureSettingsType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder->add('active_profile', ChoiceType::class, [
            'label' => 'Perfil de envio ativo',
            'choices' => [
                'Perfil 1' => 'profile_1',
                'Perfil 2' => 'profile_2',
                'Perfil 3' => 'profile_3',
            ],
            'placeholder' => 'Selecione um perfil',
            'required' => false,
            'empty_data' => 'profile_1',
            'help' => 'Apenas o perfil selecionado será usado pelo DSN fixo do Mautic.',
        ]);

        foreach ([1, 2, 3] as $slot) {
            $builder->add('profile_'.$slot, AcdApiProfileType::class, [
                'label' => 'Perfil '.$slot,
                'required' => false,
            ]);
        }
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'label' => false,
        ]);
    }
}