<?php

declare(strict_types=1);

namespace MauticPlugin\SosCustomObjectsBundle\Controller;

use Doctrine\Persistence\ManagerRegistry;
use Mautic\CoreBundle\Controller\CommonController;
use Mautic\CoreBundle\Factory\ModelFactory;
use Mautic\CoreBundle\Helper\CoreParametersHelper;
use Mautic\CoreBundle\Helper\InputHelper;
use Mautic\CoreBundle\Helper\UserHelper;
use Mautic\CoreBundle\Security\Permissions\CorePermissions;
use Mautic\CoreBundle\Service\FlashBag;
use Mautic\CoreBundle\Translation\Translator;
use MauticPlugin\SosCustomObjectsBundle\Service\CustomItemService;
use MauticPlugin\SosCustomObjectsBundle\Service\CustomObjectService;
use Psr\Log\LoggerInterface;
use Symfony\Component\EventDispatcher\EventDispatcherInterface;
use Symfony\Component\HttpFoundation\RequestStack;
use Symfony\Component\HttpFoundation\Response;

final class CustomItemController extends CommonController
{
    public function __construct(
        ManagerRegistry $doctrine,
        ModelFactory $modelFactory,
        UserHelper $userHelper,
        CoreParametersHelper $coreParametersHelper,
        EventDispatcherInterface $dispatcher,
        Translator $translator,
        FlashBag $flashBag,
        RequestStack $requestStack,
        CorePermissions $security,
        private CustomObjectService $objectService,
        private CustomItemService $itemService,
        private LoggerInterface $logger,
    ) {
        parent::__construct(
            $doctrine,
            $modelFactory,
            $userHelper,
            $coreParametersHelper,
            $dispatcher,
            $translator,
            $flashBag,
            $requestStack,
            $security
        );
    }

    public function listAction(int $objectId): Response
    {
        $object = $this->objectService->get($objectId);
        if (!$object) {
            return $this->notFound('Custom Object não encontrado.');
        }

        $fields = $this->itemService->fields($object);

        return $this->delegateView([
            'viewParameters' => [
                'object' => $object,
                'fields' => $fields,
                'items'  => $this->itemService->list($object),
            ],
            'contentTemplate' => '@SosCustomObjectsBundle/CustomItem/list.html.twig',
            'passthroughVars' => [
                'mauticContent' => 'sosCustomItems',
                'route'         => $this->generateUrl('sos_custom_items_list', ['objectId' => $objectId]),
            ],
        ]);
    }

    public function newAction(int $objectId): Response
    {
        $request = $this->getCurrentRequest();
        $object = $this->objectService->get($objectId);
        if (!$object) {
            return $this->notFound('Custom Object não encontrado.');
        }

        $fields = $this->itemService->fields($object);

        if ($request->isMethod('POST')) {
            $label = InputHelper::clean($request->request->get('label', ''));
            $values = (array) $request->request->all('values');

            try {
                $this->itemService->create($object, $label ?: null, $values);
                $this->addFlashMessage('Item criado com sucesso.');
                return $this->redirectToRoute('sos_custom_items_list', ['objectId' => $objectId]);
            } catch (\Throwable $e) {
                $this->addFlashMessage('Erro: '.$e->getMessage(), [], FlashBag::LEVEL_ERROR);
            }
        }

        return $this->delegateView([
            'viewParameters' => [
                'mode'   => 'new',
                'object' => $object,
                'fields' => $fields,
                'item'   => null,
                'values' => [],
            ],
            'contentTemplate' => '@SosCustomObjectsBundle/CustomItem/form.html.twig',
            'passthroughVars' => [
                'mauticContent' => 'sosCustomItems',
                'route'         => $this->generateUrl('sos_custom_items_new', ['objectId' => $objectId]),
            ],
        ]);
    }

    public function newForContactAction(int $objectId, int $contactId): Response
    {
        $request = $this->getCurrentRequest();
        $this->logger->debug('SosCustomObjects: newForContactAction', [
            'uri'       => $request->getUri(),
            'route'     => (string) $request->attributes->get('_route', ''),
            'objectId'  => $objectId,
            'contactId' => $contactId,
        ]);

        $object  = $this->objectService->get($objectId);
        if (!$object) {
            return $this->notFound('Custom Object nÃ£o encontrado.');
        }

        $fields = $this->itemService->fields($object);

        if ($request->isMethod('POST')) {
            $label  = InputHelper::clean($request->request->get('label', ''));
            $values = (array) $request->request->all('values');

            $this->logger->debug('SosCustomObjects: newForContactAction POST', [
                'objectId'   => $objectId,
                'contactId'  => $contactId,
                'hasLabel'   => '' !== $label,
                'valueKeys'  => array_keys($values),
            ]);

            try {
                $item = $this->itemService->create($object, $label ?: null, $values);
                $this->logger->debug('SosCustomObjects: item created for contact', [
                    'objectId'  => $objectId,
                    'contactId' => $contactId,
                    'itemId'    => $item->getId(),
                ]);
                $this->itemService->linkContact($item, $contactId);
                $this->logger->debug('SosCustomObjects: item linked to contact', [
                    'contactId' => $contactId,
                    'itemId'    => $item->getId(),
                ]);
                $this->addFlashMessage('Item criado e vinculado ao contato.');

                return $this->redirectToRoute('mautic_contact_action', [
                    'objectAction' => 'view',
                    'objectId'     => $contactId,
                ]);
            } catch (\Throwable $e) {
                $this->logger->error('SosCustomObjects: newForContactAction failed', [
                    'objectId'  => $objectId,
                    'contactId' => $contactId,
                    'message'   => $e->getMessage(),
                ]);
                $this->addFlashMessage('Erro: '.$e->getMessage(), [], FlashBag::LEVEL_ERROR);
            }
        }

        return $this->delegateView([
            'viewParameters' => [
                'mode'      => 'new',
                'object'    => $object,
                'fields'    => $fields,
                'item'      => null,
                'values'    => [],
                'contactId' => $contactId,
            ],
            'contentTemplate' => '@SosCustomObjectsBundle/CustomItem/form.html.twig',
            'passthroughVars' => [
                'mauticContent' => 'sosCustomItems',
                // Must be a URL (not a route name) or Mautic will update the browser URL incorrectly,
                // causing subsequent POSTs to be sent to `/contacts/view/<routeName>`.
                'route'         => $this->generateUrl('sos_custom_items_new_for_contact', ['objectId' => $objectId, 'contactId' => $contactId]),
            ],
        ]);
    }

    public function editAction(int $objectId, int $id): Response
    {
        $request = $this->getCurrentRequest();
        $object = $this->objectService->get($objectId);
        if (!$object) {
            return $this->notFound('Custom Object não encontrado.');
        }

        $item = $this->itemService->get($id);
        if (!$item || $item->getObject()->getId() !== $objectId) {
            return $this->notFound('Item não encontrado.');
        }

        $fields = $this->itemService->fields($object);
        $values = $this->itemService->getItemValues($item);

        if ($request->isMethod('POST')) {
            $label = InputHelper::clean($request->request->get('label', ''));
            $input = (array) $request->request->all('values');

            try {
                $this->itemService->update($item, $label ?: null, $input);
                $this->addFlashMessage('Item atualizado com sucesso.');
                return $this->redirectToRoute('sos_custom_items_list', ['objectId' => $objectId]);
            } catch (\Throwable $e) {
                $this->addFlashMessage('Erro: '.$e->getMessage(), [], FlashBag::LEVEL_ERROR);
            }
        }

        return $this->delegateView([
            'viewParameters' => [
                'mode'   => 'edit',
                'object' => $object,
                'fields' => $fields,
                'item'   => $item,
                'values' => $values,
            ],
            'contentTemplate' => '@SosCustomObjectsBundle/CustomItem/form.html.twig',
            'passthroughVars' => [
                'mauticContent' => 'sosCustomItems',
                'route'         => $this->generateUrl('sos_custom_items_edit', ['objectId' => $objectId, 'id' => $id]),
            ],
        ]);
    }

    public function deleteAction(int $objectId, int $id): Response
    {
        $request = $this->getCurrentRequest();
        if (!$request->isMethod('POST')) {
            return $this->accessDenied();
        }

        $object = $this->objectService->get($objectId);
        if (!$object) {
            return $this->notFound('Custom Object não encontrado.');
        }

        $item = $this->itemService->get($id);
        if (!$item || $item->getObject()->getId() !== $objectId) {
            return $this->notFound('Item não encontrado.');
        }

        $this->itemService->delete($item);
        $this->addFlashMessage('Item removido.');
        return $this->redirectToRoute('sos_custom_items_list', ['objectId' => $objectId]);
    }
}
