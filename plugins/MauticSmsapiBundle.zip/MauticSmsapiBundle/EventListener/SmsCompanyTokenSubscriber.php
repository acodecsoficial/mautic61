<?php

namespace MauticPlugin\MauticSmsapiBundle\EventListener;

use Doctrine\ORM\EntityManagerInterface;
use Mautic\CoreBundle\Event\TokenReplacementEvent;
use Mautic\LeadBundle\Entity\Lead;
use Mautic\SmsBundle\SmsEvents;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
 * Substitui tokens {contactfield=*} que sejam campos de empresa (object='company'),
 * buscando os valores diretamente da empresa primária do contato.
 * Roda com prioridade 10 (antes do SmsSubscriber padrão com prioridade 0).
 */
class SmsCompanyTokenSubscriber implements EventSubscriberInterface
{
    public function __construct(
        private EntityManagerInterface $em
    ) {
    }

    public static function getSubscribedEvents(): array
    {
        return [
            SmsEvents::TOKEN_REPLACEMENT => ['onTokenReplacement', 10],
        ];
    }

    public function onTokenReplacement(TokenReplacementEvent $event): void
    {
        /** @var Lead $lead */
        $lead    = $event->getLead();
        $content = $event->getContent();

        if (!$content || !$lead) {
            return;
        }

        if (!preg_match('/\{contactfield=/i', $content)) {
            return;
        }

        // Busca aliases de todos os campos de empresa cadastrados no Mautic
        $companyAliases = $this->getCompanyFieldAliases();
        if (empty($companyAliases)) {
            return;
        }

        // Verifica se o conteúdo tem algum token de campo de empresa
        $pattern = '/\{contactfield=(' . implode('|', array_map('preg_quote', $companyAliases)) . ')(?:\|[^}]*)?\}/i';
        if (!preg_match($pattern, $content)) {
            return;
        }

        // Busca os dados da empresa primária do contato
        $company = $this->getPrimaryCompanyFields($lead);
        if (empty($company)) {
            return;
        }

        // Substitui todos os tokens de campos de empresa com os valores reais
        $content = preg_replace_callback(
            $pattern,
            function (array $m) use ($company): string {
                $alias = strtolower($m[1]);
                return array_key_exists($alias, $company) ? (string) ($company[$alias] ?? '') : '';
            },
            $content
        );

        $event->setContent($content);
    }

    private function getCompanyFieldAliases(): array
    {
        try {
            $conn = $this->em->getConnection();
            $rows = $conn->fetchAllAssociative(
                "SELECT alias FROM lead_fields WHERE object = 'company' AND is_published = 1"
            );
            return array_column($rows, 'alias');
        } catch (\Throwable $e) {
            return [];
        }
    }

    private function getPrimaryCompanyFields(Lead $lead): array
    {
        try {
            $conn = $this->em->getConnection();
            $row  = $conn->fetchAssociative(
                'SELECT comp.*
                 FROM companies comp
                 INNER JOIN companies_leads cl ON cl.company_id = comp.id
                 WHERE cl.lead_id = ? AND cl.is_primary = 1
                 LIMIT 1',
                [$lead->getId()]
            );

            return $row ?: [];
        } catch (\Throwable $e) {
            return [];
        }
    }
}
