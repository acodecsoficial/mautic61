<?php

declare(strict_types=1);

namespace MauticPlugin\SosCustomObjectsBundle\EventListener;

use Mautic\LeadBundle\Event\SegmentDictionaryGenerationEvent;
use Mautic\LeadBundle\LeadEvents;
use MauticPlugin\SosCustomObjectsBundle\Repository\CustomFieldRepository;
use MauticPlugin\SosCustomObjectsBundle\Segment\Query\Filter\CustomFieldFilterQueryBuilder;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

final class SegmentFiltersDictionarySubscriber implements EventSubscriberInterface
{
    public function __construct(
        private CustomFieldRepository $customFieldRepository,
    ) {
    }

    public static function getSubscribedEvents(): array
    {
        return [LeadEvents::SEGMENT_DICTIONARY_ON_GENERATE => 'onGenerateSegmentDictionary'];
    }

    public function onGenerateSegmentDictionary(SegmentDictionaryGenerationEvent $event): void
    {
        foreach ($this->customFieldRepository->findAll() as $customField) {
            $id = $customField->getId();
            if (null === $id) {
                continue;
            }

            $key = 'sos_cmf_'.$id;
            if ($event->hasTranslation($key)) {
                continue;
            }

            // We use a real table/field pair so schema validation won't break if invoked.
            $event->addTranslation($key, [
                'type'               => CustomFieldFilterQueryBuilder::getServiceId(),
                'foreign_table'      => 'sos_custom_item_contact',
                'foreign_table_field'=> 'contact_id',
                'field'              => 'contact_id',
            ]);
        }
    }
}

