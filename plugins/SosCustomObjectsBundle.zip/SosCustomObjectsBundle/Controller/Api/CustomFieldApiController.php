<?php

declare(strict_types=1);

namespace MauticPlugin\SosCustomObjectsBundle\Controller\Api;

use MauticPlugin\SosCustomObjectsBundle\Entity\CustomField;
use MauticPlugin\SosCustomObjectsBundle\Service\CustomFieldService;
use MauticPlugin\SosCustomObjectsBundle\Service\CustomObjectService;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\RequestStack;
use Symfony\Component\HttpFoundation\Response;

final class CustomFieldApiController
{
    public function __construct(
        private CustomObjectService $objectService,
        private CustomFieldService $fieldService,
        private RequestStack $requestStack,
    ) {}

    public function listAction(int $objectId): JsonResponse
    {
        $object = $this->objectService->get($objectId);
        if (!$object) {
            return new JsonResponse(['error' => 'Custom object not found'], Response::HTTP_NOT_FOUND);
        }

        $items = array_map(fn($f) => $this->serialize($f), $this->fieldService->list($object));
        return new JsonResponse(['total' => count($items), 'items' => $items]);
    }

    public function createAction(int $objectId): JsonResponse
    {
        $object = $this->objectService->get($objectId);
        if (!$object) {
            return new JsonResponse(['error' => 'Custom object not found'], Response::HTTP_NOT_FOUND);
        }

        $data = json_decode((string) $this->getCurrentRequest()->getContent(), true) ?: [];

        try {
            $opts = $data['options'] ?? null;
            if (is_string($opts)) {
                $opts = array_values(array_filter(array_map('trim', preg_split('/\r?\n/', $opts))));
            }

            $f = $this->fieldService->create(
                $object,
                (string)($data['label'] ?? ''),
                (string)($data['alias'] ?? ''),
                (string)($data['type'] ?? CustomField::TYPE_TEXT),
                (bool)($data['isRequired'] ?? false),
                is_array($opts) ? $opts : null
            );

            return new JsonResponse($this->serialize($f), Response::HTTP_CREATED);
        } catch (\Throwable $e) {
            return new JsonResponse(['error' => $e->getMessage()], Response::HTTP_BAD_REQUEST);
        }
    }

    public function updateAction(int $objectId, int $id): JsonResponse
    {
        $object = $this->objectService->get($objectId);
        if (!$object) {
            return new JsonResponse(['error' => 'Custom object not found'], Response::HTTP_NOT_FOUND);
        }

        $field = $this->fieldService->get($id);
        if (!$field || $field->getObject()->getId() !== $objectId) {
            return new JsonResponse(['error' => 'Field not found'], Response::HTTP_NOT_FOUND);
        }

        $data = json_decode((string) $this->getCurrentRequest()->getContent(), true) ?: [];

        try {
            $opts = $data['options'] ?? $field->getOptions();
            if (is_string($opts)) {
                $opts = array_values(array_filter(array_map('trim', preg_split('/\r?\n/', $opts))));
            }

            $field = $this->fieldService->update(
                $field,
                (string)($data['label'] ?? $field->getLabel()),
                (string)($data['alias'] ?? $field->getAlias()),
                (string)($data['type'] ?? $field->getType()),
                (bool)($data['isRequired'] ?? $field->isRequired()),
                is_array($opts) ? $opts : null
            );

            return new JsonResponse($this->serialize($field));
        } catch (\Throwable $e) {
            return new JsonResponse(['error' => $e->getMessage()], Response::HTTP_BAD_REQUEST);
        }
    }

    public function deleteAction(int $objectId, int $id): JsonResponse
    {
        $object = $this->objectService->get($objectId);
        if (!$object) {
            return new JsonResponse(['error' => 'Custom object not found'], Response::HTTP_NOT_FOUND);
        }

        $field = $this->fieldService->get($id);
        if (!$field || $field->getObject()->getId() !== $objectId) {
            return new JsonResponse(['error' => 'Field not found'], Response::HTTP_NOT_FOUND);
        }

        $this->fieldService->delete($field);
        return new JsonResponse(null, Response::HTTP_NO_CONTENT);
    }

    private function getCurrentRequest(): Request
    {
        $request = $this->requestStack->getCurrentRequest();
        if (null === $request) {
            throw new \RuntimeException('Request is not set.');
        }
        return $request;
    }

    private function serialize($f): array
    {
        return [
            'id' => $f->getId(),
            'customObjectId' => $f->getObject()->getId(),
            'label' => $f->getLabel(),
            'alias' => $f->getAlias(),
            'type' => $f->getType(),
            'isRequired' => $f->isRequired(),
            'options' => $f->getOptions(),
        ];
    }
}
