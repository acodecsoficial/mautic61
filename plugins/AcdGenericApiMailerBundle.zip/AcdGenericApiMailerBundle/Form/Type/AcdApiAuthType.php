<?php

declare(strict_types=1);

namespace MauticPlugin\AcdGenericApiMailerBundle\Form\Type;

use Mautic\IntegrationsBundle\Integration\Interfaces\IntegrationInterface;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class AcdApiAuthType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        foreach ([1, 2, 3] as $slot) {
            $tokenName = 'profile_'.$slot.'_token';
            $usernameName = 'profile_'.$slot.'_username';
            $passwordName = 'profile_'.$slot.'_password';

            $builder->add($tokenName, PasswordType::class, [
                'label' => 'Perfil '.$slot.': token Bearer ou chave de API',
                'required' => false,
                'always_empty' => true,
                'empty_data' => self::acdPreserveSecret(...),
                'attr' => ['autocomplete' => 'new-password'],
            ]);
            $builder->add($usernameName, PasswordType::class, [
                'label' => 'Perfil '.$slot.': usuário para autenticação básica HTTP',
                'required' => false,
                'always_empty' => true,
                'empty_data' => self::acdPreserveSecret(...),
                'attr' => ['autocomplete' => 'new-password'],
            ]);
            $builder->add($passwordName, PasswordType::class, [
                'label' => 'Perfil '.$slot.': senha para autenticação básica HTTP',
                'required' => false,
                'always_empty' => true,
                'empty_data' => self::acdPreserveSecret(...),
                'attr' => ['autocomplete' => 'new-password'],
            ]);
            $builder->add('profile_'.$slot.'_remove', CheckboxType::class, [
                'label' => 'Remover as credenciais do perfil '.$slot,
                'required' => false,
            ]);
        }

        $builder->addEventListener(FormEvents::SUBMIT, static function (FormEvent $event): void {
            $data = $event->getData();
            if (!is_array($data)) {
                return;
            }

            foreach ([1, 2, 3] as $slot) {
                $removeName = 'profile_'.$slot.'_remove';
                if (!empty($data[$removeName])) {
                    $data['profile_'.$slot.'_token'] = '';
                    $data['profile_'.$slot.'_username'] = '';
                    $data['profile_'.$slot.'_password'] = '';
                }
                unset($data[$removeName]);
            }

            $event->setData($data);
        });
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setRequired('integration');
        $resolver->setAllowedTypes('integration', IntegrationInterface::class);

        $resolver->setDefaults([
            'label' => false,
        ]);
    }

    private static function acdPreserveSecret(FormInterface $form): string
    {
        $name = $form->getName();
        $parentData = $form->getParent()?->getData();

        if (is_array($parentData) && array_key_exists($name, $parentData)) {
            return (string) $parentData[$name];
        }

        return '';
    }
}
