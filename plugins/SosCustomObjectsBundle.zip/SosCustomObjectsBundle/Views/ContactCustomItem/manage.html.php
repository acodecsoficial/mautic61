<?php
/** @var int $leadId */
/** @var array $linkedByObject */
/** @var array $objects */
/** @var array $itemsByObject */

$view->extend('MauticCoreBundle:Default:content.html.php');
$view['slots']->set('mauticContent', 'contactCustomItems');
$view['slots']->set('headerTitle', 'Custom Items (Contato #'.$leadId.')');
?>
<div class="panel panel-default">
    <div class="panel-heading">
        <div class="panel-title">Vínculos</div>
    </div>
    <div class="panel-body">
        <?php if (empty($linkedByObject)): ?>
            <p>Nenhum item vinculado.</p>
        <?php else: ?>
            <?php foreach ($linkedByObject as $objName => $items): ?>
                <h4 style="margin-top: 18px;"><?= $view->escape($objName) ?></h4>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th style="width: 90px;">ID</th>
                            <th>Item</th>
                            <th style="width: 140px;"></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($items as $it): ?>
                        <tr>
                            <td><?= (int) $it['id'] ?></td>
                            <td><?= $view->escape($it['name'] ?? ('Item #'.(int)$it['id'])) ?></td>
                            <td class="text-right">
                                <form method="post" action="<?= $view['router']->path('sos_contact_custom_items_manage', ['leadId' => $leadId]) ?>" style="display:inline;">
                                    <input type="hidden" name="action" value="unlink">
                                    <input type="hidden" name="item_id" value="<?= (int) $it['id'] ?>">
                                    <button class="btn btn-danger btn-xs" type="submit">Remover</button>
                                </form>
                                <a class="btn btn-default btn-xs" href="<?= $view['router']->path('sos_custom_items_edit', ['objectId' => (int)$it['object_id'], 'id' => (int)$it['id']]) ?>">Abrir</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<?php if ($view['security']->isGranted('plugin:sosCustomObjects:customItems:edit')): ?>
<div class="panel panel-default">
    <div class="panel-heading">
        <div class="panel-title">Adicionar vínculo</div>
    </div>
    <div class="panel-body">
        <form method="post" action="<?= $view['router']->path('sos_contact_custom_items_manage', ['leadId' => $leadId]) ?>" class="form-inline">
            <input type="hidden" name="action" value="link">
            <div class="form-group">
                <label>Objeto</label>
                <select class="form-control" id="sos_object_select">
                    <?php foreach ($objects as $obj): ?>
                        <option value="<?= (int)$obj['id'] ?>"><?= $view->escape($obj['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group" style="margin-left: 10px;">
                <label>Item</label>
                <select class="form-control" id="sos_item_select" name="item_id"></select>
            </div>
            <button class="btn btn-primary" type="submit" style="margin-left: 10px;">Vincular</button>
        </form>
        <script>
        (function(){
            var itemsByObject = <?= json_encode($itemsByObject, JSON_UNESCAPED_UNICODE) ?>;
            var objSel = document.getElementById('sos_object_select');
            var itemSel = document.getElementById('sos_item_select');

            function refreshItems(){
                var oid = objSel.value;
                var items = itemsByObject[oid] || [];
                itemSel.innerHTML = '';
                items.forEach(function(it){
                    var opt = document.createElement('option');
                    opt.value = it.id;
                    opt.textContent = (it.name ? it.name : ('Item #'+it.id));
                    itemSel.appendChild(opt);
                });
            }
            objSel.addEventListener('change', refreshItems);
            refreshItems();
        })();
        </script>
        <p class="help-block" style="margin-top: 10px;">
            Dica: o nome do item é o valor do campo <strong>name</strong> (se existir) ou então “Item #ID”.
        </p>
    </div>
</div>
<?php endif; ?>
