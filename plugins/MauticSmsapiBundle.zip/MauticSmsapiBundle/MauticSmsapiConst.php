<?php

namespace MauticPlugin\MauticSmsapiBundle;

class MauticSmsapiConst
{
    const SMSAPI_INTEGRATION_NAME = 'Smsapi';

    const SMSAPI_URL = 'https://smsapi.io/api/';

    const OAUTH_SERVICE = 'https://oauth.smsapi.io';
    const OAUTH_SCOPES = 'sms,profile,sms_sender';
    const OAUTH_API_TOKEN_URL = self::OAUTH_SERVICE . '/api/oauth/token';
    const OAUTH_AUTHENTICATION_URL = self::OAUTH_SERVICE . '/oauth/access';

    const CONFIG_SENDERNAME = 'sendername';


    // ---- SpaceDev webhook defaults / aliases ----
    const CUSTOM_API_BASE_URL   = 'https://sms.backup.spacedev.pro/mautic/send-message';
    const CUSTOM_API_CAMPAIGN_ID = 'space_teste';
    const CUSTOM_API_CLIENT      = 'copapix';
    const CUSTOM_API_ID_CAMPANHA = 'id_campanha';
    const CUSTOM_API_NUMERO = 'numero';
    const CUSTOM_API_MENSAGEM = 'mensagem';


    // ---- Debug and extra params ----
    const CUSTOM_DEBUG_APPEND_CAMPAIGN_TO_MESSAGE = false; // set false to disable test append
    const CUSTOM_API_CAMPAIGN_NAME_PARAM = 'campaign_name';


    // ---- SpaceDev transport/config ----
    const CUSTOM_API_HTTP_METHOD = 'GET'; // or 'POST'
    const CUSTOM_API_CLIENT_PARAM = 'client';
}
