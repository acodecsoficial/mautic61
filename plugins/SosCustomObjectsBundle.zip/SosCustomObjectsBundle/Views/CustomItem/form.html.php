<?php

use MauticPlugin\SosCustomObjectsBundle\Entity\CustomField;

$view->extend('MauticCoreBundle:Default:content.html.php');

$mode   = $view['data']->get('mode', 'new');
$object = $view['data']->get('object');
$fields = $view['data']->get('fields', []);
$item   = $view['data']->get('item');
$values = $view['data']->get('values', []);

$title = $mode === 'edit' ? 'Editar Item' : 'Novo Item';
$view['slots']->set('headerTitle', $title.' - '.$view->escape($object->getName()));

$label = $item ? (string)$item->getLabel() : '';

function v($values, $fieldId) {
  return $values[$fieldId] ?? '';
}
?>

<div class="box-layout">
  <div class="col-md-8">
    <div class="toolbar mb-md">
      <a class="btn btn-default" href="<?php echo $view['router']->path('sos_custom_items_list', ['objectId' => $object->getId()]); ?>">
        <i class="fa fa-arrow-left"></i> Voltar
      </a>
      <a class="btn btn-default" href="<?php echo $view['router']->path('sos_custom_fields_list', ['objectId' => $object->getId()]); ?>">
        <i class="fa fa-list"></i> Campos
      </a>
    </div>

    <div class="panel panel-default">
      <div class="panel-heading"><h4 class="panel-title"><?php echo $view->escape($title); ?></h4></div>
      <div class="panel-body">
        <form method="post">
          <div class="form-group">
            <label>Label (opcional)</label>
            <input class="form-control" name="label" value="<?php echo $view->escape($label); ?>" />
          </div>

          <hr/>

          <?php if (!$fields): ?>
            <p>Nenhum campo cadastrado. Crie campos primeiro.</p>
          <?php endif; ?>

          <?php foreach ($fields as $f): ?>
            <?php $fid = (int) $f->getId(); $val = v($values, $fid); ?>
            <div class="form-group">
              <label><?php echo $view->escape($f->getLabel()); ?> <?php echo $f->isRequired() ? '<span class="text-danger">*</span>' : ''; ?></label>

              <?php if ($f->getType() === CustomField::TYPE_SELECT): ?>
                <select class="form-control" name="values[<?php echo $view->escape($f->getAlias()); ?>]" <?php echo $f->isRequired() ? 'required' : ''; ?>>
                  <option value="">-- selecione --</option>
                  <?php foreach (($f->getOptions() ?: []) as $opt): ?>
                    <option value="<?php echo $view->escape($opt); ?>" <?php echo ((string)$opt === (string)$val) ? 'selected' : ''; ?>>
                      <?php echo $view->escape($opt); ?>
                    </option>
                  <?php endforeach; ?>
                </select>

              <?php elseif ($f->getType() === CustomField::TYPE_BOOL): ?>
                <label style="display:block;">
                  <input type="checkbox" name="values[<?php echo $view->escape($f->getAlias()); ?>]" value="1" <?php echo ($val === true || $val === '1' || $val === 1) ? 'checked' : ''; ?> />
                  Sim
                </label>

              <?php elseif ($f->getType() === CustomField::TYPE_NUMBER): ?>
                <input type="number" step="any" class="form-control" name="values[<?php echo $view->escape($f->getAlias()); ?>]" value="<?php echo $view->escape((string)$val); ?>" <?php echo $f->isRequired() ? 'required' : ''; ?> />

              <?php elseif ($f->getType() === CustomField::TYPE_DATE): ?>
                <input type="date" class="form-control" name="values[<?php echo $view->escape($f->getAlias()); ?>]" value="<?php echo $view->escape(is_string($val) ? substr($val, 0, 10) : ''); ?>" <?php echo $f->isRequired() ? 'required' : ''; ?> />

              <?php else: ?>
                <input class="form-control" name="values[<?php echo $view->escape($f->getAlias()); ?>]" value="<?php echo $view->escape((string)$val); ?>" <?php echo $f->isRequired() ? 'required' : ''; ?> />
              <?php endif; ?>

              <small class="text-muted"><code><?php echo $view->escape($f->getAlias()); ?></code> (<?php echo $view->escape($f->getType()); ?>)</small>
            </div>
          <?php endforeach; ?>

          <div class="form-group">
            <button class="btn btn-primary"><i class="fa fa-save"></i> Salvar</button>
            <a class="btn btn-default" href="<?php echo $view['router']->path('sos_custom_items_list', ['objectId' => $object->getId()]); ?>">Cancelar</a>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
