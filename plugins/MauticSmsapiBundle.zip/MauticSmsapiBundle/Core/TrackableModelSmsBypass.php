<?php

namespace MauticPlugin\MauticSmsapiBundle\Core;

use Mautic\PageBundle\Model\TrackableModel;

class TrackableModelSmsBypass
{
    private $inner;

    public function __construct(TrackableModel $inner)
    {
        $this->inner = $inner;
    }

    public function parseContentForTrackables($content, $channel = null, array $utmTags = [], array $options = [])
    {
        if ($channel === 'sms') {
            return $content; // não reescreve links nos SMS
        }

        return $this->inner->parseContentForTrackables($content, $channel, $utmTags, $options);
    }

    public function __call($name, $arguments)
    {
        return $this->inner->$name(...$arguments);
    }
}
