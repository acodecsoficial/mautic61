<?php

declare(strict_types=1);

namespace MauticPlugin\AcdGenericApiMailerBundle\Service;

use JsonException;
use MauticPlugin\AcdGenericApiMailerBundle\Exception\AcdGenericApiMailerConfigurationException;

class AcdPayloadMappingService
{
    public function acdMapPayload(string $mappingJson, array $context): array
    {
        try {
            $mapping = json_decode($mappingJson, true, 512, JSON_THROW_ON_ERROR);
        } catch (JsonException $exception) {
            throw new AcdGenericApiMailerConfigurationException('O mapeamento do payload precisa conter JSON válido.', 0, $exception);
        }

        if (!is_array($mapping) || [] === $mapping || array_is_list($mapping)) {
            throw new AcdGenericApiMailerConfigurationException('O mapeamento do payload precisa ser um objeto JSON com campos.');
        }

        $mapped = $this->acdResolveValue($mapping, $context);
        if (!is_array($mapped) || [] === $mapped || array_is_list($mapped)) {
            throw new AcdGenericApiMailerConfigurationException('O mapeamento do payload não produziu um objeto JSON válido.');
        }

        return $this->acdRemoveNullValues($mapped);
    }

    private function acdResolveValue(mixed $value, array $context): mixed
    {
        if (is_array($value)) {
            $resolved = [];
            foreach ($value as $key => $item) {
                $resolved[$key] = $this->acdResolveValue($item, $context);
            }

            return $resolved;
        }

        if (!is_string($value)) {
            return $value;
        }

        if (preg_match('/^\{\{\s*([a-z_]+)\s*\}\}$/D', $value, $matches)) {
            return $this->acdGetContextValue($matches[1], $context);
        }

        return preg_replace_callback('/\{\{\s*([a-z_]+)\s*\}\}/', function (array $matches) use ($context): string {
            $replacement = $this->acdGetContextValue($matches[1], $context);
            if (is_array($replacement) || is_object($replacement)) {
                throw new AcdGenericApiMailerConfigurationException('Placeholders com listas ou objetos devem ocupar o valor JSON inteiro.');
            }

            return null === $replacement ? '' : (string) $replacement;
        }, $value);
    }

    private function acdGetContextValue(string $name, array $context): mixed
    {
        if (!array_key_exists($name, $context)) {
            throw new AcdGenericApiMailerConfigurationException('O mapeamento usa um placeholder desconhecido: '.$name.'.');
        }

        return $context[$name];
    }

    private function acdRemoveNullValues(array $values): array
    {
        foreach ($values as $key => $value) {
            if (null === $value) {
                unset($values[$key]);
                continue;
            }
            if (is_array($value) && !array_is_list($value)) {
                $values[$key] = $this->acdRemoveNullValues($value);
            }
        }

        return $values;
    }
}