<?php

declare(strict_types=1);

namespace MauticPlugin\SosCustomObjectsBundle\Security\Permissions;

use Mautic\CoreBundle\Security\Permissions\AbstractPermissions;

final class SosCustomObjectsPermissions extends AbstractPermissions
{
    public function __construct(array $params = [])
    {
        parent::__construct($params);

        $this->addStandardPermissions('customObjects');
        $this->addStandardPermissions('customItems');
    }

    public function getName(): string
    {
        // Used in permission strings: plugin:sosCustomObjects:...
        return 'sosCustomObjects';
    }
}
