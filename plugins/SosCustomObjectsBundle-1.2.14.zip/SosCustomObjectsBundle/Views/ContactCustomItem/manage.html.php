<?php
/** @var int $leadId */
/** @var array $linkedByObject */
/** @var array $objects */
/** @var array $pagination */

$view->extend('MauticCoreBundle:Default:content.html.php');
$view['slots']->set('mauticContent', 'contactCustomItems');
$view['slots']->set('headerTitle', 'Custom Items (Contato #'.$leadId.')');
?>
<div class="panel panel-default">
    <div class="panel-heading">
        <div class="panel-title">Vínculos</div>
    </div>
    <div class="panel-body">
        <?php if (empty($linkedByObject)): ?>
            <p>Nenhum item vinculado.</p>
        <?php else: ?>
            <?php foreach ($linkedByObject as $objName => $items): ?>
                <h4 style="margin-top: 18px;"><?= $view->escape($objName) ?></h4>
                <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th style="width: 90px;">ID</th>
                            <th>Item</th>
                            <th style="width: 140px;"></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($items as $it): ?>
                        <tr>
                            <td><?= (int) $it['id'] ?></td>
                            <td><?= $view->escape($it['name'] ?? ('Item #'.(int)$it['id'])) ?></td>
                            <td class="text-right">
                                <form method="post" action="<?= $view['router']->path('sos_contact_custom_items_manage', ['leadId' => $leadId]) ?>" style="display:inline;">
                                    <input type="hidden" name="action" value="unlink">
                                    <input type="hidden" name="item_id" value="<?= (int) $it['id'] ?>">
                                    <button class="btn btn-danger btn-xs" type="submit">Remover</button>
                                </form>
                                <a class="btn btn-default btn-xs" href="<?= $view['router']->path('sos_custom_items_edit', ['objectId' => (int)$it['object_id'], 'id' => (int)$it['id']]) ?>">Abrir</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
        <?php if (($pagination['totalItems'] ?? 0) > 0): ?>
            <div class="row">
                <div class="col-sm-6"><p class="text-muted">Exibindo <?= (int) $pagination['firstItem'] ?> a <?= (int) $pagination['lastItem'] ?> de <?= (int) $pagination['totalItems'] ?> registros</p></div>
                <?php if ($pagination['totalPages'] > 1): ?>
                    <div class="col-sm-6 text-right"><nav aria-label="Paginacao"><ul class="pagination pagination-sm">
                        <?php $previousPage = $pagination['currentPage'] - 1; ?>
                        <li class="<?= $pagination['currentPage'] <= 1 ? 'disabled' : '' ?>"><?php if ($pagination['currentPage'] > 1): ?><a href="<?= $view['router']->path('sos_contact_custom_items_manage', ['leadId' => $leadId, 'page' => $previousPage]) ?>">Anterior</a><?php else: ?><span>Anterior</span><?php endif; ?></li>
                        <?php foreach ($pagination['pages'] as $pageNumber): ?>
                            <li class="<?= $pageNumber === $pagination['currentPage'] ? 'active' : '' ?>"><?php if ($pageNumber === $pagination['currentPage']): ?><span aria-current="page"><?= (int) $pageNumber ?></span><?php else: ?><a href="<?= $view['router']->path('sos_contact_custom_items_manage', ['leadId' => $leadId, 'page' => $pageNumber]) ?>"><?= (int) $pageNumber ?></a><?php endif; ?></li>
                        <?php endforeach; ?>
                        <?php $nextPage = $pagination['currentPage'] + 1; ?>
                        <li class="<?= $pagination['currentPage'] >= $pagination['totalPages'] ? 'disabled' : '' ?>"><?php if ($pagination['currentPage'] < $pagination['totalPages']): ?><a href="<?= $view['router']->path('sos_contact_custom_items_manage', ['leadId' => $leadId, 'page' => $nextPage]) ?>">Proxima</a><?php else: ?><span>Proxima</span><?php endif; ?></li>
                    </ul></nav></div>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <p class="text-muted">Nenhum registro para exibir.</p>
        <?php endif; ?>
    </div>
</div>

<?php if ($view['security']->isGranted('plugin:sosCustomObjects:customItems:edit')): ?>
<div class="panel panel-default">
    <div class="panel-heading">
        <div class="panel-title">Adicionar vínculo</div>
    </div>
    <div class="panel-body">
        <form method="post" action="<?= $view['router']->path('sos_contact_custom_items_manage', ['leadId' => $leadId]) ?>" class="form-inline">
            <input type="hidden" name="action" value="link">
            <div class="form-group">
                <label>Objeto</label>
                <select class="form-control" id="sos_object_select">
                    <?php foreach ($objects as $obj): ?>
                        <option value="<?= (int)$obj['id'] ?>"><?= $view->escape($obj['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group" style="margin-left: 10px;">
                <label>Item</label>
                <select class="form-control" id="sos_item_select" name="item_id" disabled></select>
            </div>
            <button class="btn btn-primary" id="sos_link_item_submit" type="submit" style="margin-left: 10px;" disabled>Vincular</button>
        </form>
        <div class="mt-sm">
            <button class="btn btn-default btn-xs" id="sos_item_page_previous" type="button" disabled>Anterior</button>
            <span id="sos_item_page_status" class="text-muted" aria-live="polite"></span>
            <button class="btn btn-default btn-xs" id="sos_item_page_next" type="button" disabled>Proxima</button>
            <span id="sos_item_options_error" class="text-danger" role="alert"></span>
        </div>
        <script>
        (function(){
            var itemOptionsUrlTemplate = <?= json_encode($view['router']->path('sos_custom_items_options', ['objectId' => 0])) ?>;
            var objSel = document.getElementById('sos_object_select');
            var itemSel = document.getElementById('sos_item_select');
            var submitButton = document.getElementById('sos_link_item_submit');
            var previousButton = document.getElementById('sos_item_page_previous');
            var nextButton = document.getElementById('sos_item_page_next');
            var pageStatus = document.getElementById('sos_item_page_status');
            var errorStatus = document.getElementById('sos_item_options_error');
            var activePage = 1;
            var requestNumber = 0;

            function refreshItems(page, resetSelection){
                var oid = objSel.value;
                var currentRequest = ++requestNumber;
                var selectedValue = resetSelection ? '' : itemSel.value;
                var selectedText = resetSelection || !itemSel.selectedOptions.length ? '' : itemSel.selectedOptions[0].textContent;
                itemSel.innerHTML = '';
                itemSel.disabled = true;
                submitButton.disabled = true;
                previousButton.disabled = true;
                nextButton.disabled = true;
                errorStatus.textContent = '';
                pageStatus.textContent = 'Carregando...';
                if (!oid) {
                    pageStatus.textContent = '';
                    errorStatus.textContent = 'Selecione um objeto.';
                    return;
                }

                var url = itemOptionsUrlTemplate.replace(/\/0$/, '/' + encodeURIComponent(oid));
                url += (url.indexOf('?') === -1 ? '?' : '&') + 'page=' + encodeURIComponent(page);
                fetch(url, {credentials: 'same-origin', headers: {'Accept': 'application/json'}})
                    .then(function(response){
                        if (!response.ok) { throw new Error('Falha ao carregar os itens (' + response.status + ').'); }
                        return response.json();
                    })
                    .then(function(payload){
                        if (currentRequest !== requestNumber) { return; }
                        activePage = payload.currentPage;
                        (payload.items || []).forEach(function(it){
                            var opt = document.createElement('option');
                            opt.value = it.id;
                            opt.textContent = (it.name ? it.name : ('Item #' + it.id));
                            itemSel.appendChild(opt);
                        });
                        if (selectedValue && !Array.from(itemSel.options).some(function(option){ return option.value === selectedValue; })) {
                            var selectedOption = document.createElement('option');
                            selectedOption.value = selectedValue;
                            selectedOption.textContent = selectedText;
                            itemSel.appendChild(selectedOption);
                        }
                        if (selectedValue) { itemSel.value = selectedValue; }
                        itemSel.disabled = itemSel.options.length === 0;
                        submitButton.disabled = itemSel.disabled;
                        previousButton.disabled = payload.currentPage <= 1;
                        nextButton.disabled = payload.currentPage >= payload.totalPages;
                        pageStatus.textContent = payload.totalItems ? 'Pagina ' + payload.currentPage + ' de ' + payload.totalPages : 'Nenhum item cadastrado.';
                    })
                    .catch(function(error){
                        if (currentRequest !== requestNumber) { return; }
                        pageStatus.textContent = '';
                        errorStatus.textContent = error.message || 'Nao foi possivel carregar os itens.';
                    });
            }
            objSel.addEventListener('change', function(){ refreshItems(1, true); });
            previousButton.addEventListener('click', function(){ refreshItems(activePage - 1, false); });
            nextButton.addEventListener('click', function(){ refreshItems(activePage + 1, false); });
            refreshItems(1, true);
        })();
        </script>
        <p class="help-block" style="margin-top: 10px;">
            Dica: o nome do item é o valor do campo <strong>name</strong> (se existir) ou então “Item #ID”.
        </p>
    </div>
</div>
<?php endif; ?>
