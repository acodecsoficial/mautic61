<?php

namespace MauticPlugin\MauticSmsapiBundle\Core;

class SmsapiGatewayDecorator implements SmsapiGateway
{
    private $gateway;
    private $plugin;

    public function __construct(SmsapiGatewayImpl $gatewayImpl, SmsapiPluginInterface $plugin)
    {
        $this->gateway = $gatewayImpl;
        $this->plugin = $plugin;
    }

    public function isConnected(): bool
    {
        if (!$this->plugin->getBearerToken()) {
            return false;
        }

        return $this->gateway->isConnected();
    }

    public function getSendernames(): array
    {
        return $this->gateway->getSendernames();
    }

    public function sendSms(string $phoneNumber, string $content, string $sendername, array $meta = [])
    {
        $this->gateway->sendSms($phoneNumber, $content, $sendername, $meta);
    }

    public function getProfile(): Profile
    {
        return $this->gateway->getProfile();
    }
}
