<?php

declare(strict_types=1);

namespace MauticPlugin\SosCustomObjectsBundle\EventListener;

use Mautic\CoreBundle\CoreEvents;
use Mautic\CoreBundle\Event\CustomButtonEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

final class ContactViewInjectSubscriber implements EventSubscriberInterface
{
    public static function getSubscribedEvents(): array
    {
        return [
            // Inject buttons
            CoreEvents::VIEW_INJECT_CUSTOM_BUTTONS => ['injectButtons', 0],
        ];
    }

    public function injectButtons(CustomButtonEvent $event): void
    {
        /**
         * IMPORTANT:
         * Some Mautic 6 builds don't have CustomButtonEvent::getViewName(), so calling it breaks rendering.
         * We ONLY inject buttons if the methods we rely on exist.
         */
        if (!method_exists($event, 'getViewName') || !method_exists($event, 'getLocation') || !method_exists($event, 'addButton')) {
            return;
        }

        $viewName = $event->getViewName();
        $location = $event->getLocation();

        $targets = [
            'MauticLeadBundle:Lead:lead.html.php',
            'MauticLeadBundle:Lead:detail.html.php',
        ];
        if (!in_array($viewName, $targets, true)) {
            return;
        }

        // Location varies - we register for common ones. If none match, ignore.
        if (!in_array($location, ['lead.actions', 'actions', 'toolbar', 'page.actions'], true)) {
            return;
        }

        $event->addButton([
            'text'       => 'Custom Items',
            'btnClass'   => 'btn btn-default btn-sm',
            'iconClass'  => 'ri-links-line',
            'url'        => 'javascript:void(0)',
            'attr'       => [
                'data-toggle' => 'modal',
                'data-target' => '#sos-custom-items-modal',
            ],
            'priority'   => 0,
        ]);
    }
}
