<?php

namespace MauticPlugin\AcodecsWhitelabelBundle\EventListener;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpKernel\Event\ResponseEvent;
use Symfony\Component\HttpKernel\KernelEvents;

class AcdBrandingSubscriber implements EventSubscriberInterface
{
    public static function getSubscribedEvents(): array
    {
        return [
            KernelEvents::RESPONSE => ['onKernelResponse', 0],
        ];
    }

    public function onKernelResponse(ResponseEvent $event): void
    {
        if (!$event->isMainRequest()) {
            return;
        }

        $response    = $event->getResponse();
        $contentType = $response->headers->get('Content-Type', '');

        if (!str_contains($contentType, 'text/html')) {
            return;
        }

        $content = $response->getContent();

        if (!str_contains($content, 'mautic-logo')) {
            return;
        }

        $logoUrl = '/plugins/AcodecsWhitelabelBundle/Assets/img/logo.png';

        $css = <<<CSS
<style id="acd-whitelabel">
/* ── Navbar ── */
.mautic-logo-figure,
.mautic-logo-text {
    display: none !important;
}
.mautic-brand {
    display: inline-flex !important;
    align-items: center;
    background-image: url('{$logoUrl}');
    background-repeat: no-repeat;
    background-size: contain;
    background-position: center left;
    min-width: 160px;
    height: 45px;
}

/* ── Login ── */
.mautic-logo.img-circle .mautic-logo-figure {
    display: none !important;
}
.mautic-logo.img-circle {
    background-image: url('{$logoUrl}');
    background-repeat: no-repeat;
    background-size: contain;
    background-position: center;
    width: 200px;
    height: 80px;
    border-radius: 0 !important;
    box-shadow: none !important;
    margin: 0 auto 20px;
}
</style>
CSS;

        $content = str_replace('</head>', $css . '</head>', $content);
        $response->setContent($content);
    }
}
