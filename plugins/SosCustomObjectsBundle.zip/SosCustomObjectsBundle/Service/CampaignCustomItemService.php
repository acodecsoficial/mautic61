<?php

declare(strict_types=1);

namespace MauticPlugin\SosCustomObjectsBundle\Service;

use Doctrine\DBAL\Connection;
use MauticPlugin\SosCustomObjectsBundle\Repository\CustomItemRepository;

final class CampaignCustomItemService
{
    public function __construct(
        private Connection $db,
        private CustomItemRepository $itemRepo,
        private CustomItemService $itemService,
    ) {}

    public function link(int $contactId, int $itemId): void
    {
        $item = $this->itemRepo->find($itemId);
        if (!$item) {
            throw new \RuntimeException('Item não encontrado.');
        }
        $this->itemService->linkContact($item, $contactId);
    }

    public function unlink(int $contactId, int $itemId): void
    {
        $item = $this->itemRepo->find($itemId);
        if (!$item) {
            throw new \RuntimeException('Item não encontrado.');
        }
        $this->itemService->unlinkContact($item, $contactId);
    }

    public function evaluateCondition(
        int $contactId,
        ?int $objectId,
        string $fieldAlias,
        string $operator,
        string $value
    ): bool {
        if ('' === trim($fieldAlias)) {
            throw new \RuntimeException('Alias do campo obrigatório.');
        }

        $params = $this->db->getParams();
        $prefix = $params['table_prefix'] ?? '';

        // find field id by alias (and object if provided)
        $sqlField = "SELECT f.id
                     FROM {$prefix}sos_custom_field f
                     WHERE f.alias = :alias".
                     ($objectId ? " AND f.custom_object_id = :oid" : "").
                     " LIMIT 1";

        $field = $this->db->fetchAssociative($sqlField, array_filter([
            'alias' => $fieldAlias,
            'oid'   => $objectId,
        ], fn($v) => $v !== null));

        if (!$field || !isset($field['id'])) {
            throw new \RuntimeException('Campo não encontrado.');
        }

        $fid = (int) $field['id'];

        $allowedOps = ['=','!=','>','>=','<','<=','LIKE'];
        if (!in_array($operator, $allowedOps, true)) {
            $operator = '=';
        }

        $sql = "SELECT 1
                FROM {$prefix}sos_custom_item_contact c
                INNER JOIN {$prefix}sos_custom_item i ON i.id = c.custom_item_id
                INNER JOIN {$prefix}sos_custom_item_value v ON v.custom_item_id = i.id AND v.custom_field_id = :fid
                WHERE c.contact_id = :cid".
                ($objectId ? " AND i.custom_object_id = :oid" : "").
                " AND ".
                ($operator === 'LIKE' ? "v.value LIKE :val" : "CAST(v.value AS DECIMAL(20,6)) {$operator} CAST(:val AS DECIMAL(20,6))").
                " LIMIT 1";

        $val = $operator === 'LIKE' ? ("%".$value."%") : $value;

        $args = [
            'fid' => $fid,
            'cid' => $contactId,
            'val' => $val,
        ];
        if ($objectId) {
            $args['oid'] = $objectId;
        }

        return (bool) $this->db->fetchOne($sql, $args);
    }
}
