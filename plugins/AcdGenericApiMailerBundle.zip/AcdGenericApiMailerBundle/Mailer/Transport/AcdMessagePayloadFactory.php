<?php

declare(strict_types=1);

namespace MauticPlugin\AcdGenericApiMailerBundle\Mailer\Transport;

use MauticPlugin\AcdGenericApiMailerBundle\Exception\AcdGenericApiMailerConfigurationException;
use MauticPlugin\AcdGenericApiMailerBundle\Service\AcdPayloadMappingService;
use Symfony\Component\Mime\Email;
use Symfony\Component\Mime\Header\UnstructuredHeader;
use Symfony\Component\Mime\Part\DataPart;

class AcdMessagePayloadFactory
{
    private const MAX_RECIPIENTS = 1000;
    private const MAX_ATTACHMENTS = 10;
    private const MAX_ATTACHMENT_BYTES = 10485760;

    public function __construct(
        private AcdPayloadMappingService $payloadMappingService,
    ) {
    }

    public function acdBuildPayload(Email $email, array $profile): array
    {
        $context = $this->acdBuildContext($email, 'sndr' === ($profile['adapter'] ?? null));

        if ('sndr' === $profile['adapter']) {
            return $this->acdBuildSndrPayload($context);
        }

        if ('generic_json' === $profile['adapter']) {
            return $this->payloadMappingService->acdMapPayload((string) $profile['payload_mapping_json'], $context);
        }

        throw new AcdGenericApiMailerConfigurationException('O adaptador ativo não é reconhecido.');
    }

    private function acdBuildContext(Email $email, bool $isSndr): array
    {
        $from = $this->acdAddressList($email->getFrom(), true);
        $to = $this->acdAddressList($email->getTo());
        $cc = $this->acdAddressList($email->getCc());
        $bcc = $this->acdAddressList($email->getBcc());
        $replyTo = $this->acdAddressList($email->getReplyTo());
        $subject = (string) ($email->getSubject() ?? '');
        $html = $email->getHtmlBody();
        $text = $email->getTextBody();

        if ($isSndr && '' === trim($subject)) {
            throw new AcdGenericApiMailerConfigurationException('A mensagem não contém assunto.');
        }
        if ($isSndr && strlen($subject) > 998) {
            throw new AcdGenericApiMailerConfigurationException('O assunto excede o limite de 998 bytes aceito pelo SNDR.');
        }
        if ([] === $from || '' === trim($from[0]) || [] === $to) {
            throw new AcdGenericApiMailerConfigurationException('A mensagem precisa conter remetente e destinatário.');
        }
        if (count($from) > 1) {
            throw new AcdGenericApiMailerConfigurationException('O adaptador HTTP aceita apenas um remetente por mensagem.');
        }
        if ($isSndr && (int) (count($to) + count($cc) + count($bcc)) > self::MAX_RECIPIENTS) {
            throw new AcdGenericApiMailerConfigurationException('A mensagem excede o limite de 1000 destinatários aceito pelo SNDR.');
        }
        if ($isSndr && (count($cc) > 100 || count($bcc) > 100)) {
            throw new AcdGenericApiMailerConfigurationException('O SNDR aceita no máximo 100 endereços em cada campo CC e BCC.');
        }
        if ((null === $html || '' === $html) && (null === $text || '' === $text)) {
            throw new AcdGenericApiMailerConfigurationException('A mensagem precisa conter corpo HTML ou texto.');
        }

        return [
            'from' => $from[0],
            'to' => $to,
            'cc' => $cc,
            'bcc' => $bcc,
            'reply_to' => $replyTo[0] ?? null,
            'subject' => $subject,
            'html' => $html,
            'text' => $text,
            'headers' => (object) $this->acdExtractHeaders($email),
            'attachments' => $this->acdExtractAttachments($email),
        ];
    }

    private function acdBuildSndrPayload(array $context): array
    {
        $payload = [
            'from' => $context['from'],
            'to' => $context['to'],
            'subject' => $context['subject'],
        ];

        foreach (['cc', 'bcc', 'reply_to', 'html', 'text', 'headers', 'attachments'] as $key) {
            $value = $context[$key];
            if (is_array($value) && [] === $value) {
                continue;
            }
            if (is_object($value) && [] === get_object_vars($value)) {
                continue;
            }
            if (null === $value || '' === $value) {
                continue;
            }
            $payload[$key] = $value;
        }

        return $payload;
    }

    private function acdAddressList(array $addresses, bool $includeName = false): array
    {
        $formatted = [];
        foreach ($addresses as $address) {
            $formatted[] = $includeName ? (string) $address : $address->getAddress();
        }

        return $formatted;
    }

    private function acdExtractHeaders(Email $email): array
    {
        $excluded = [
            'from',
            'to',
            'cc',
            'bcc',
            'reply-to',
            'subject',
            'date',
            'message-id',
            'mime-version',
            'content-type',
            'content-transfer-encoding',
            'list-unsubscribe',
            'list-unsubscribe-post',
        ];
        $headers = [];

        foreach ($email->getHeaders()->all() as $header) {
            if (!$header instanceof UnstructuredHeader) {
                continue;
            }

            $name = trim($header->getName());
            $value = trim($header->getBody());
            $normalizedName = strtolower($name);
            if (in_array($normalizedName, $excluded, true) || '' === $value || preg_match('/[\r\n]/', $value)) {
                continue;
            }
            if (!preg_match('/^[A-Za-z0-9-]{1,80}$/D', $name)) {
                continue;
            }

            $headers[$name] = $value;
        }

        return $headers;
    }

    private function acdExtractAttachments(Email $email): array
    {
        $parts = $email->getAttachments();
        if (count($parts) > self::MAX_ATTACHMENTS) {
            throw new AcdGenericApiMailerConfigurationException('O SNDR aceita no máximo 10 anexos por mensagem.');
        }

        $attachments = [];
        $totalBytes = 0;
        foreach ($parts as $index => $part) {
            if (!$part instanceof DataPart) {
                throw new AcdGenericApiMailerConfigurationException('Um anexo da mensagem usa um formato que não é aceito pelo adaptador HTTP.');
            }
            if ('attachment' !== $part->getDisposition()) {
                throw new AcdGenericApiMailerConfigurationException('O adaptador HTTP aceita anexos comuns; imagens inline referenciadas por cid: não são suportadas.');
            }

            $content = $part->getBody();
            $totalBytes += strlen($content);
            if ($totalBytes > self::MAX_ATTACHMENT_BYTES) {
                throw new AcdGenericApiMailerConfigurationException('Os anexos excedem o limite total de 10 MiB aceito pelo SNDR.');
            }

            $attachments[] = [
                'filename' => $part->getFilename() ?: 'anexo-'.($index + 1).'.bin',
                'content' => base64_encode($content),
                'content_type' => $part->getContentType(),
            ];
        }

        return $attachments;
    }
}
